/**
 * MailCountServiceFetchCustomFoldersImpl.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.infosys.ebanking.mails.service;
import com.infosys.ebanking.common.EBIncidenceCodes;
import com.infosys.ebanking.common.EBankingErrorCodes;
import com.infosys.ebanking.core.cache.AppDataConstants;
import com.infosys.ebanking.mails.MailConstants;
import com.infosys.ebanking.types.TypesCatalogueConstants;
import com.infosys.ebanking.types.entityreferences.FolderIDER;
import com.infosys.ebanking.types.primitives.FolderDescription;
import com.infosys.ebanking.types.primitives.FolderId;import com.infosys.ebanking.types.valueobjects.ICommonCodeVO;import com.infosys.ebanking.types.valueobjects.IMailCountEnquiryVO;import com.infosys.feba.framework.cache.AppDataManager;import com.infosys.feba.framework.common.ErrorCodes;import com.infosys.feba.framework.common.exception.BusinessConfirmation;import com.infosys.feba.framework.common.exception.BusinessException;import com.infosys.feba.framework.common.exception.CriticalException;import com.infosys.feba.framework.commontran.context.FEBATransactionContext;import com.infosys.feba.framework.transaction.pattern.AbstractHostInquiryTran;import com.infosys.feba.framework.types.lists.FEBAArrayList;import com.infosys.feba.framework.types.valueobjects.FEBAAVOFactory;import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;import com.infosys.feba.framework.valengine.FEBAValItem;
import com.infosys.ebanking.mails.hif.requests.MailCountForFolderInvoker;

/**
 * Fetches the totalCount and unreadCount for folders.
 *
 * @author Pramodha_T
 * @exrends AbstractHostInquiryTran
 */
public final class MailCountServiceFetchCustomFoldersImpl extends
        AbstractHostInquiryTran {

	/**
	 * Default Constructor
	 */
	public MailCountServiceFetchCustomFoldersImpl(){

	}
    /**
     * Does not do any validation since no inputs are used.
     *
     * @see com.infosys.feba.framework.transaction.pattern.AbstractHostInquiryTran#prepareValidationsList(com.infosys.feba.framework.commontran.context.FEBATransactionContext,
     *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject,
     *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject)
     */
    public FEBAValItem[] prepareValidationsList(
            FEBATransactionContext objContext, IFEBAValueObject objInputOutput,
            IFEBAValueObject objTxnWM) {
        return null;
    }
    /**
     * Creates a list of custom folders and invokes the host to fetch the count
     * of mails in custom folders
     *
     * @see com.infosys.feba.framework.transaction.pattern.AbstractHostInquiryTran#processHostData(com.infosys.feba.framework.commontran.context.FEBATransactionContext,
     *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject,
     *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject)
     */
    protected void processHostData(FEBATransactionContext objContext,
            IFEBAValueObject objInputOutput, IFEBAValueObject objTxnWM)
            throws BusinessException, BusinessConfirmation, CriticalException {
        final FEBAArrayList appList = new FEBAArrayList();
        try {
            appList.addAll((FEBAArrayList) AppDataManager.getList(objContext,
                    AppDataConstants.COMMONCODE_CACHE, "CODE_TYPE="
                            + MailConstants.CUSTOM_FOLDERS));        }
        catch (CriticalException be) {
            if (be.getErrorCode() ==ErrorCodes.RETRIEVE_LIST) {
                throw new BusinessException(objContext, be.getIncidenceCode(),
                        EBankingErrorCodes.NO_CUSTOM_FOLDERS_AVAILABLE);
            }

        }
        final FEBAArrayList folderIDList = new FEBAArrayList();
        for (int i = 0; i < appList.size(); i++) {
            final FolderIDER folderIDER = (FolderIDER) FEBAAVOFactory
                    .createInstance(TypesCatalogueConstants.FolderIDER);
            final ICommonCodeVO commonCode = (ICommonCodeVO) appList.get(i);
            folderIDER.setFolderId(new FolderId(commonCode.getCommonCode()
                    .getValue()));
            folderIDER.setFolderDescription(new FolderDescription(commonCode
                    .getCodeDescription().getValue()));
            folderIDList.add(folderIDER);
        }
        final IMailCountEnquiryVO countVO = (IMailCountEnquiryVO) objInputOutput;
        countVO.getCriteria().setFolderIDERList(folderIDList);
        final MailCountForFolderInvoker requestInvoker = new MailCountForFolderInvoker();
        requestInvoker.processRequest(objContext,
                objInputOutput, objTxnWM);
    }
    /**
     * @see com.infosys.feba.framework.transaction.pattern.AbstractHostInquiryTran#processLocalData(com.infosys.feba.framework.commontran.context.FEBATransactionContext,
     *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject,
     *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject)
     */
    protected void processLocalData(
            FEBATransactionContext objContext,
            IFEBAValueObject objInputOutput,
            IFEBAValueObject objTxnWM) throws BusinessException {
        throw new BusinessException(
                true,
                objContext,
                EBIncidenceCodes.ACCOUNT_ACCESS_FLAG_NOT_RETREIVED,
                "IN MAIL FETCH FOR FOLDERS",
                null,
                EBankingErrorCodes.NO_RECORDS_FETCHED,
                null,
                null);

    }
}