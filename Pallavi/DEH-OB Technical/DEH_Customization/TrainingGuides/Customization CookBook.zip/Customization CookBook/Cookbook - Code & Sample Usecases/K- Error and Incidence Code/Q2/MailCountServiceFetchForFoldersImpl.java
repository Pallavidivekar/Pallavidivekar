/**
 * MailCountServiceFetchForFoldersImpl.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.infosys.ebanking.mails.service;

import com.infosys.ebanking.common.EBIncidenceCodes;
import com.infosys.ebanking.common.EBankingErrorCodes;
import com.infosys.ebanking.common.validators.ListNotEmptyValidator;
import com.infosys.ebanking.mails.MailConstants;
import com.infosys.ebanking.mails.hif.requests.MailCountForFolderInvoker;
import com.infosys.ebanking.mails.validators.FolderIDERVal;
import com.infosys.ebanking.types.primitives.CommonCode;
import com.infosys.ebanking.types.valueobjects.MailCountCritVO;
import com.infosys.ebanking.types.valueobjects.MailCountEnquiryVO;
import com.infosys.feba.framework.common.exception.BusinessConfirmation;
import com.infosys.feba.framework.common.exception.BusinessException;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.transaction.pattern.AbstractHostInquiryTran;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.feba.framework.valengine.FEBAValEngineConstants;
import com.infosys.feba.framework.valengine.FEBAValItem;

/**
 * Implementation class to fetch the count of mails in specified folders
 * 
 * @author Pramodha_T
 * 
 */
public final class MailCountServiceFetchForFoldersImpl extends
		AbstractHostInquiryTran {

	/**
	 * Default Constructor
	 */
	public MailCountServiceFetchForFoldersImpl() {

	}

	/**
	 * Validates that at least one folder ID is passed in the list and that
	 * every folder ID passed is valid
	 * 
	 * @see com.infosys.feba.framework.transaction.pattern.AbstractHostInquiryTran#prepareValidationsList(com.infosys.feba.framework.commontran.context.FEBATransactionContext,
	 *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject,
	 *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject)
	 */
	public FEBAValItem[] prepareValidationsList(
			FEBATransactionContext objContext, IFEBAValueObject objInputOutput,
			IFEBAValueObject objTxnWM) throws BusinessException,
			BusinessConfirmation, CriticalException {
		final MailCountEnquiryVO mailCountEnquiryVO = (MailCountEnquiryVO) objInputOutput;
		final MailCountCritVO mailCountCritVO = mailCountEnquiryVO
				.getCriteria();

		final FEBAValItem vls[] = new FEBAValItem[] {
				new FEBAValItem("criteria.folderIDERList", mailCountCritVO
						.getFolderIDERList(), new ListNotEmptyValidator(),
						FEBAValEngineConstants.INDEPENDENT),
				new FEBAValItem("criteria.folderIDERList", mailCountCritVO
						.getFolderIDERList(), new FolderIDERVal(),
						FEBAValEngineConstants.DEPENDENT, new CommonCode(
								MailConstants.ALL_FOLDER)), };
		return vls;
	}

	/**
	 * Invokes a host to get the count of mails in the specified folders
	 * 
	 * @see com.infosys.feba.framework.transaction.pattern.AbstractHostInquiryTran#processHostData(com.infosys.feba.framework.commontran.context.FEBATransactionContext,
	 *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject,
	 *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject)
	 */
	protected void processHostData(FEBATransactionContext objContext,
			IFEBAValueObject objInputOutput, IFEBAValueObject objTxnWM)
			throws BusinessException, BusinessConfirmation, CriticalException {
		new MailCountForFolderInvoker().processRequest(objContext,
				objInputOutput, objTxnWM);
	}

	/**
	 * NOT implemented
	 * @throws BusinessException 
	 * 
	 * @see com.infosys.feba.framework.transaction.pattern.AbstractHostInquiryTran#processLocalData(com.infosys.feba.framework.commontran.context.FEBATransactionContext,
	 *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject,
	 *      com.infosys.feba.framework.types.valueobjects.IFEBAValueObject)
	 */
	protected void processLocalData(
            FEBATransactionContext objContext,
            IFEBAValueObject objInputOutput,
            IFEBAValueObject objTxnWM) throws BusinessException {
        throw new BusinessException(
                false,
                objContext,
                EBIncidenceCodes.ACCOUNT_ACCESS_FLAG_NOT_RETREIVED,
                "IN MAIL FETCH FOR FOLDERS",
                null,
                EBankingErrorCodes.NO_RECORDS_FETCHED,
                null,
                null);

    }

}