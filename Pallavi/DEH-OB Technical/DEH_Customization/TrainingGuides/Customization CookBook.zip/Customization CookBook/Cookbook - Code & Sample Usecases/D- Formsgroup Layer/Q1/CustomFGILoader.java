/*
 * Created on Nov 07, 2008
 * COPYRIGHT NOTICE:
 * Copyright (c) 2004 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */

package com.futurebank.feba.framework.formsgroup.interpretor.fgi;

import java.util.Map;

import com.futurebank.feba.common.formsgroup.fgi.CustomFGIConstants;
import com.infosys.feba.framework.formsgroup.interpretor.IFGILoader;
import com.infosys.feba.framework.formsgroup.interpretor.IFGIStepInterpreter;
import com.infosys.feba.framework.formsgroup.interpretor.fgi.SOPInterpreter;


/**
 * CustomFGILoader
 * @author Jagmeet_Sandhu
 * @version 1.0
 * @since FEBA 2.0
 */
public class CustomFGILoader implements IFGILoader {


	/**
	 * load() in CustomFGILoader
	 * <BR>
	 * @param fgiInterpreterMap
	 * @author Jagmeet_Sandhu
	 * @see com.infosys.feba.framework.formsgroup.interpretor.IFGILoader#load(java.util.Map)
	 * 
	 */
	public void load(Map<String, IFGIStepInterpreter> fgiInterpreterMap) {

	fgiInterpreterMap.put(CustomFGIConstants.SOP , 			new SOPInterpreter());
	}

}
