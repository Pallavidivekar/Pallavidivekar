package com.futurebank.feba.common.formsgroup.fgi;


/**
 * This is a Constants file and it contains the list of
 * CustomFGIs supported in the FEBA.
 * @author Jagmeet_Sandhu
 * @version 1.0
 * @since FEBA 2.0
 */
public class CustomFGIConstants {

 
    public static final String SOP 			= "SOP";
    
    
    //make private constructor
    private CustomFGIConstants(){}
}

