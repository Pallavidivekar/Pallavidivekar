/**
 * TranCatListServiceFetchImpl.java
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */

package com.futurebank.ebanking.service;

import com.infosys.ebanking.common.EBTransactionContext;
import com.futurebank.ebanking.types.valueobjects.CustomTranCatInqCritVO;
import com.infosys.feba.framework.common.exception.BusinessConfirmation;
import com.infosys.feba.framework.common.exception.BusinessException;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.dal.QueryOperator;
import com.infosys.feba.framework.transaction.pattern.AbstractLocalListInquiryTran;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.feba.framework.valengine.FEBAValItem;

/**
 * Method				Fetch
 * Description			This is the implementation class for the fetch method of the
 * 						TranCatListService.It is used to fetch the list of Transaction
 * 						Categories for a user.
 * Input				TranCatCritVO
 * Output				TranCatInqVO
 * Transaction Pattern 	AbstractLocalListInquiryTran
 * Host Calls
 *
 * @author nishant_sharma
 * @version 1.0
 * @since
 */

public class CustomTranCatListServiceFetchImpl extends AbstractLocalListInquiryTran {

	/**
	 * Method		prepareValidationList(FEBATransactionContext pobjContext,
	 * 				IFEBAValueObject pobjInputOutput,IFEBAValueObject pobjTxnWM)
	 * Description	No validations neecded
	 * Input		pobjContext, pobjInputOutput, pobjTxnWM.
	 * Output		Val Item Array
	 */
	
	public FEBAValItem[] prepareValidationsList(FEBATransactionContext objContext
													, IFEBAValueObject objInputOutput
													, IFEBAValueObject objTxnWM) 
						throws BusinessException,BusinessConfirmation, CriticalException {

		return null;
	}
   /**
    * Method getQueryIdentifier(FEBATransactionContext pObjContext,
    * IFEBAValueObject objInputOutput,IFEBAValueObject objTxnWM)
    * Description Gets the name of the query to be called
    * Input pObjContext, objInputOutput, objTxnWM.
    * Output String
    */

   public String getQueryIdentifier(FEBATransactionContext pObjContext
		   							, IFEBAValueObject objInputOutput
		   							, IFEBAValueObject objTxnWM) {
	   return "TranCatListQuery";
   }

	
  /**
   * Method associateQueryParameters( FEBATransactionContext txnContext,
   * IFEBAValueObject objQueryCrit, IFEBAValueObject objTxnWM,
   * QueryOperator queryOperator)
   * Description Associates the query parameters with the fields received
   * Input txnContext,objQueryCrit,objTxnWM,queryOperator
   * Output NA
   *
   */

	protected void associateQueryParameters(FEBATransactionContext txnContext
											, IFEBAValueObject objQueryCrit
											, IFEBAValueObject objTxnWM
											, QueryOperator queryOperator) throws CriticalException {
		
		EBTransactionContext objEBTxnContext = (EBTransactionContext) txnContext;
		CustomTranCatInqCritVO crit = (CustomTranCatInqCritVO)objQueryCrit;
		
		queryOperator.associate("bank_id", objEBTxnContext.getBankId());
		queryOperator.associate("user_id", objEBTxnContext.getRecordUserId());
	}
}
