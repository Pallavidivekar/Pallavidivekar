
package com.futurebank.feba.framework.cache;

import com.infosys.ebanking.core.cache.AppDataConstants;
import com.futurebank.feba.framework.cache.CommonCodeCache;
import com.infosys.feba.framework.cache.AppCacheRegistryManager;
import com.infosys.feba.framework.common.FEBAIncidenceCodes;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.common.logging.LogManager;



public class CustomAppCacheLoader {

static {
		try {
			AppCacheRegistryManager.registerCache(
			AppDataConstants.COMMONCODE_CACHE, CommonCodeCache
			.getInstance());
			} catch (CriticalException e) {

			LogManager.logDebug(null, FEBAIncidenceCodes.LOAD_FOR_CACHE);

		}
	}
}