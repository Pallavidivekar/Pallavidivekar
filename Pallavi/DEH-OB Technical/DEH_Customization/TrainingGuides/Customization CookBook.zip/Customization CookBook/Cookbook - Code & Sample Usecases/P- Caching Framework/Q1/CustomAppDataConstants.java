
package com.futurebank.ebanking.common;

public class CustomAppDataConstants {



	public static final String CUSTOM_COMMON_CODE_CACHE        = "CommonCodeCache";

}
