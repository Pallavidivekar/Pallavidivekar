package com.futurebank.ebanking;

import com.futurebank.ebanking.types.valueobjects.CustomStateCodeVO;
import com.infosys.ebanking.types.valueobjects.StateCodeVO;
import com.infosys.feba.framework.common.exception.BusinessConfirmation;
import com.infosys.feba.framework.common.exception.BusinessException;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.dal.QueryOperator;
import com.infosys.feba.framework.dal.QueryRecord;
import com.infosys.feba.framework.transaction.common.DefaultCustomQuery;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;

public class CustomStateCodeAssociateQuery extends DefaultCustomQuery{
    public void associateCustomQueryParameters(
            FEBATransactionContext objContext,
            IFEBAValueObject objQueryCrit,
            QueryOperator queryOperator,
            IFEBAValueObject objTxnWM)
            throws BusinessException,
                BusinessConfirmation,
                CriticalException {
        
        
        StateCodeVO codeVO = (StateCodeVO)objQueryCrit;
        final CustomStateCodeVO customCriteriaVO = (CustomStateCodeVO) codeVO.getExtensionVO();
        if (customCriteriaVO!=null){
            customCriteriaVO.getStateDescriptionCustom();
            queryOperator.associate("stateDescriptionCustom", customCriteriaVO.getStateDescriptionCustom());
        }
        
        
           
        
        
        
        
        
        
    }
}
