
package com.futurebank.ebanking.filter;



public class CustomFilterConstants {




		public static final String ENTITY_SKINCODES= "SkinType";



    private CustomFilterConstants(){
    }



}
