/*
 * CommonCodesFilterHelper.java
 * @since Jan 14, 2009 - 5:25:18 PM
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.futurebank.ebanking.filter.helper;

import com.infosys.ebanking.filter.AbstractEBFilterHelper;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.commonweb.context.OpContext;
import com.infosys.feba.framework.types.IFEBAType;
import com.infosys.feba.framework.types.primitives.AttributeName;
import com.infosys.feba.framework.types.primitives.FEBAUnboundString;
import com.infosys.feba.framework.types.primitives.IFEBAPrimitive;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;

/**
 * Helper class for CountryCode entity.
 * 
 * @author saptarshi_chatterjee
 * @version 1.0
 * @since FEBA 2.0
 */
public class SkinFilterHelper extends AbstractEBFilterHelper {

    /**
     * CM_CODE description.
     */
    private static final String CM_CODE = "CM_CODE";
    /**
     * CODE_DESC description.
     */
    private static final String CODE_DESC = "CM_DESC";

    /**
     * Method getFilterAttributeValueInOpCtx returns the value of the given
     * filter attribute in Op context. <BR>
     * 
     * @param pOpCtx
     * @param pEntity
     * @param pScenario
     * @param pEntityValue
     * @param pAttributeName
     * @return IFEBAPrimitive
     * @throws CriticalException
     * @author saptarshi_chatterjee
     * @see com.infosys.feba.framework.filter.AbstractFEBAFilterHelper#getFilterAttributeValueInOpCtx(com.infosys.feba.framework.commonweb.context.OpContext,
     *      com.infosys.feba.framework.types.primitives.FEBAUnboundString,
     *      com.infosys.feba.framework.types.primitives.FEBAUnboundString,
     *      com.infosys.feba.framework.types.IFEBAType,
     *      com.infosys.feba.framework.types.primitives.AttributeName)
     * @since Feb 11, 2009 - 4:26:07 PM
     */
    protected IFEBAPrimitive getFilterAttributeValueInOpCtx(
            OpContext pOpCtx,
            FEBAUnboundString pEntity,
            FEBAUnboundString pScenario,
            IFEBAType pEntityValue,
            AttributeName pAttributeName) throws CriticalException {
        IFEBAPrimitive attribValue = null;

        if (pAttributeName.getValue().equals(CM_CODE)) {
            attribValue = (IFEBAPrimitive) ((IFEBAValueObject) pEntityValue)
                    .getFieldByName("commonCode");
        } else if (pAttributeName.getValue().equals(CODE_DESC)) {
            attribValue = (IFEBAPrimitive) ((IFEBAValueObject) pEntityValue)
                    .getFieldByName("codeDescription");
        }

        return attribValue;
        /**
         * Method getFilterAttributeValueInTxnCtx returns the value of the given
         * filter attribute in Txn context. <BR>
         * 
         * @param pTxnCtx
         * @param pEntity
         * @param pScenario
         * @param pEntityValue
         * @param pAttributeName
         * @return
         * @throws CriticalException
         * @author saptarshi_chatterjee
         * @see com.infosys.feba.framework.filter.AbstractFEBAFilterHelper#getFilterAttributeValueInTxnCtx(com.infosys.feba.framework.commontran.context.FEBATransactionContext,
         *      com.infosys.feba.framework.types.primitives.FEBAUnboundString,
         *      com.infosys.feba.framework.types.primitives.FEBAUnboundString,
         *      com.infosys.feba.framework.types.IFEBAType,
         *      com.infosys.feba.framework.types.primitives.AttributeName)
         * @since Feb 11, 2009 - 4:32:45 PM
         */
    }

    protected IFEBAPrimitive getFilterAttributeValueInTxnCtx(
            FEBATransactionContext pTxnCtx,
            FEBAUnboundString pEntity,
            FEBAUnboundString pScenario,
            IFEBAType pEntityValue,
            AttributeName pAttributeName) throws CriticalException {
        IFEBAPrimitive attribValue = null;

        if (pAttributeName.getValue().equals(CM_CODE)) {
            attribValue = (IFEBAPrimitive) ((IFEBAValueObject) pEntityValue)
                    .getFieldByName("commonCode");
        } else if (pAttributeName.getValue().equals(CODE_DESC)) {
            attribValue = (IFEBAPrimitive) ((IFEBAValueObject) pEntityValue)
                    .getFieldByName("codeDescription");
        }

        return attribValue;
    }

}
