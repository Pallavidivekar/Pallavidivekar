/*
 * EBFilterHelperLoader.java
 * @since Jan 14, 2009 - 5:21:19 PM
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.futurebank.ebanking.filter;

import java.util.Map;

import com.futurebank.ebanking.filter.helper.SkinFilterHelper;
import com.infosys.ebanking.filter.EBFilterConstants;
import com.infosys.feba.framework.filter.IFilterHelper;
import com.infosys.feba.framework.filter.IFilterHelperLoader;

/**
 * EB implementation to load filter helper classes.
 *
 * @author saptarshi_chatterjee
 * @version 1.0
 * @since FEBA 2.0
 */

public class CustomFilterHelperLoader implements IFilterHelperLoader {

    /**
     * It loads the helper objects in given registry map. <BR>
     *
     * @param pRegistryMap
     * @author saptarshi_chatterjee
     * @see com.infosys.feba.framework.filter.IFilterHelperLoader#loadHelpers(java.util.Map)
     * @since Jan 14, 2009 - 5:21:20 PM
     */
    public void loadHelpers(Map<String, IFilterHelper> pRegistryMap) {
        pRegistryMap.put(
                "SkinType",
                new SkinFilterHelper());


    }
}
