/*
 * XPIConstants.java
 * @since Feb 18, 2009 - 4:47:17 PM
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.futurebank.feba.framework.hif.meta;


/**
 * TODO Class Description comment
 * @author Vibhor
 * @version 1.0
 * @since FEBA 2.0
 */

public class CustomXPIConstants {

    public static final String CUSTOMSOP                          = "CUSTOMSOP";

}
