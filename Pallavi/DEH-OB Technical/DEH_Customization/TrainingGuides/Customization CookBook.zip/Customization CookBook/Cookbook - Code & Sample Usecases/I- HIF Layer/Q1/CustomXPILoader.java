/**
 * <B>FEBA 2.0</B><br>
 * <b>COPYRIGHT NOTICE:</b><br>
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys. <br>
 * <B>Description:</B><br>
 *
 * <br>
 * @author Vibhor
 * @since Apr 13, 2010 3:36:57 PM
 * @version 1.00
 * <br>
 */
package com.infosys.ebanking.hif.interpreter.xpi;

import java.util.Map;

import com.futurebank.feba.framework.hif.meta.CustomXPIConstants;
import com.infosys.feba.framework.hif.processor.interpreter.IXPILoader;
import com.futurebank.feba.framework.hif.processor.interpreter.xpi.CustomHIFSOPInterpreter;

/**
 *
 * This class loads customization XPIs
 * @author Sundarapetchinathan
 * @since FEBA 2.0
 */
public class CustomXPILoader implements IXPILoader {

    public void load(Map pXPIInterpreterMap) {
        pXPIInterpreterMap.put(CustomXPIConstants.CUSTOMSOP, new CustomHIFSOPInterpreter());
       // pXPIInterpreterMap.put(XPIConstants.CUSTOMDIVISION, new CustomCUSTOMDIVISION());
    }




}

