/*
 * HIFSOPInterpreter.java
 * @since Apr 13, 2010 - 4:27:09 PM
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.futurebank.feba.framework.hif.processor.interpreter.xpi;

import java.util.List;

import com.infosys.feba.framework.common.FEBAConstants;
import com.infosys.feba.framework.common.exception.BusinessConfirmation;
import com.infosys.feba.framework.common.exception.BusinessException;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.common.util.StandardMessagePrinter;
import com.infosys.feba.framework.hif.meta.GenericXPIStepComponent;
import com.infosys.feba.framework.hif.meta.HIFStep;
import com.infosys.feba.framework.hif.meta.IHIFMetaData;
import com.infosys.feba.framework.hif.meta.IStepOperand;
import com.infosys.feba.framework.hif.meta.ProcessingBlock;
import com.infosys.feba.framework.hif.processor.IWorkingMemory;
import com.infosys.feba.framework.hif.processor.interpreter.AbstractXPIStepInterpreter;
import com.infosys.feba.framework.types.IFEBAType;

/**
 * CUSTOMSOP Equivalent to SOP in JAVA.. It is a very powerful
 * debugging tool. It comes from java's SOP in short. It
 * can be used for printing any of the HIF's variable and the number of
 * parameters that can be given is unlimited.
 *
 * Syntax: XPI::CUSTOMSOP("value = ",a,b,c) where "value =" is a literal parameter and
 * a,b,c can be local or global variables.
 *
 * Usage Sample:
 * XPI::CUSTOMSOP("Payee Name = ", NAME);
 *
 * @author Vibhor
 * @version 1.0
 * @since FEBA 2.0
 */

public class CustomHIFSOPInterpreter extends AbstractXPIStepInterpreter {
    private static final int MIN_NO_OF_OPERANDS = 1;

    /**
     * This overriding method validates number of operands
     *
     * @author Vibhor
     * @param pWorkingMemory
     * @param pMeta
     * @param pProcessingBlock
     * @param pStep
     * @throws BusinessException
     * @throws BusinessConfirmation
     * @throws CriticalException
     * @since FEBA 2.0
     */
    protected void validateXPIOperands(
            IWorkingMemory pWorkingMemory,
            IHIFMetaData pMeta,
            ProcessingBlock pProcessingBlock,
            HIFStep pStep)
            throws BusinessException,
                BusinessConfirmation,
                CriticalException {
        super.validateNoOfOperands(pWorkingMemory, pStep, MIN_NO_OF_OPERANDS, ANY_NO_OF_OPERANDS);
    }

    /**
     * This overriding method interprets the given step
     *
     * @param pWorkingMemory
     * @param pMeta
     * @param pProcessingBlock
     * @param pStep
     * @author Vibhor
     * @since FEBA 2.0
     */
    protected void interpret(
            IWorkingMemory pWorkingMemory,
            IHIFMetaData pMeta,
            ProcessingBlock pProcessingBlock,
            HIFStep pStep)
            throws BusinessException,
                BusinessConfirmation,
                CriticalException {

        GenericXPIStepComponent xpi = (GenericXPIStepComponent) pStep
                .getStepComponent();
        List operandList = xpi.getOperands();

        StringBuffer outputStr = new StringBuffer(FEBAConstants.BLANK);
        // Read all the operands and append to outputStr
        for (int i = 0; i < operandList.size(); i++) {
            IStepOperand operand = (IStepOperand)operandList.get(i);

            IFEBAType operandValue = super.readOperandValue(pWorkingMemory,
                    pStep, i);

                if (operand.getOperandType().equals(IStepOperand.KEYWORD)) {
                if (pWorkingMemory.getImplicitFieldByName(operand
                        .getOperandName()) != null)
                        outputStr.append(pWorkingMemory
                            .getImplicitFieldByName(operand.getOperandName()));
                } else {
                if (operandValue != null) {
                    outputStr.append(operandValue.toString());
            }else{
                outputStr.append("null");
                }
            }
        }
        StandardMessagePrinter.printOnStdOut(outputStr.toString());
    }

    /**
     *
     * This overriding method provides access control
     *
     * @author Vibhor
     * @return
     * @since FEBA 2.0
     */
    public String[] getNamespaces() {
        return new String[] { IHIFMetaData.NAMESPACE_ALL };
    }

}
