/**
 * UCDTDAO.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2008 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */    
package com.infosys.ebanking.tao.dao;

import java.sql.*;
import com.infosys.feba.framework.audit.engine.IAudit;
import com.infosys.feba.framework.audit.FEBAAuditConstants;
import com.infosys.feba.framework.common.FEBAIncidenceCodes;
import com.infosys.feba.framework.common.ErrorCodes;
import com.infosys.feba.framework.common.FEBAConstants;
import com.infosys.feba.framework.common.ApplicationConfig;
import com.infosys.feba.framework.common.FormattedString;
import com.infosys.feba.framework.common.exception.FatalException;
import com.infosys.feba.framework.common.exception.RACException;
import com.infosys.feba.framework.common.RACExceptionHelper;
import com.infosys.feba.framework.common.util.DateUtil;
import com.infosys.feba.framework.common.util.resource.PropertyUtil;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.tao.FEBATableOperatorException;
import com.infosys.feba.framework.tao.FEBAAInfo;
import com.infosys.feba.framework.tao.FEBAADAO;
import com.infosys.feba.framework.tao.FEBAAInfoKey;
import com.infosys.feba.framework.types.FEBATypesUtility;
import com.infosys.feba.framework.types.primitives.FEBATableName;
import com.infosys.feba.framework.types.primitives.FEBAUnboundString;
import com.infosys.feba.framework.types.valueobjects.FEBACookie;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.sql.DBLargeObjectUtil;
import com.infosys.feba.framework.common.logging.LogManager;

import com.infosys.ebanking.tao.infokey.UCDTInfoKey;
import com.infosys.ebanking.tao.info.UCDTInfo;

/**
 * This class is an implementation of FEBAAInfo.
 * 
 * 
 * @author TAOGenerator
 * @version 1.0,Mon Mar 18 16:46:46 IST 2019
 * @see com.infosys.feba.framework.tao.FEBAAInfo
 * @since FEBA 2.0
 */
public class UCDTDAO extends FEBAADAO {

    /** This variable holds the singleton instance of this FEBAADAO implementation.*/ 
	private static UCDTDAO dao;

	private UCDTDAO() {
		super(new FEBATableName("UCDT"), 50);
    }

    /**
     * This method returns the singleton instance of the this class.
     * 
     * @return an instance of this FEBAADAO implementation class.
     */
	public static FEBAADAO getInstance() {
        if (dao == null) {
            dao = new UCDTDAO();
        }

        return dao;
    }

    /**
     * This method returns true if 'del_Flg' column is available in the table.
     * else returns false.
     */
    public boolean isDeleteFlagAvailable(){
        
              return false;
                      
    }
    
    /**
     * This method returns true if all cookie columns are available in the table.
     * else returns false.
     */
    public boolean isCompleteCookieAvailable(){
        
              return false;
                      
    }
    
    /**
     * This method executes select statement on the table
     * corresponding to this FEBAADAO implementation. It uses the members of FEBAAInfoKey
     * object 'febaInfoKey' provided as parameter and return an FEBAAInfo object
     * with values of all the fields of the table record.
     * 
     * @param tc - FEBATransactionContext object.
     * @param febaInfoKey - key of the table record to be fetched.
     * @return an FEBAAInfo object
     * @throws FEBATableOperatorException
     * @throws FatalException     
     */
     public FEBAAInfo select(FEBATransactionContext tc, 
                            FEBAAInfoKey febaInfoKey) throws FEBATableOperatorException,
                            FatalException {
		                           
		UCDTInfoKey infoKey = (UCDTInfoKey)febaInfoKey;
            
		if (!infoKey.isValid()){
			LogManager.log(tc, "Invalid Key ["+infoKey.getKeyString()+"] in TAO select for table [" + tableName+"]",LogManager.MESSAGE );

		    throw new FEBATableOperatorException("Invalid Key ["+infoKey.getKeyString()+"] in TAO select for table [" + tableName+"]");
		}
            
		PreparedStatement preparedStatement = null;    
		try	{
			Connection dbConnection = tc.getConnection().getSqlConnection();

			preparedStatement = dbConnection.prepareStatement("SELECT USER_ID , MOB_NUM , EMAIL_ID FROM UCDT WHERE USER_ID = ? ");
          
 			if(infoKey.getUserId().getValue().trim().length() == 0){
				throwInvalidKeyException(tc,new FEBAUnboundString("UserId"));
			}else{
				preparedStatement.setString(1, new FormattedString(infoKey.getUserId().getValue(), infoKey.getUserId().getMaxLength()  ).value ) ;
			}


			ResultSet resultset = preparedStatement.executeQuery();
          
			if ( resultset.next() == false )
			{
				LogManager.log(tc, "Record Does not Exists in [" + tableName.getValue() + "] for key [" + infoKey.getKeyString() + "]",LogManager.MESSAGE);

				throw new FEBATableOperatorException("Record Does not Exists in [" + tableName.getValue() + "] for key [" + infoKey.getKeyString() + "]",ErrorCodes.RECORD_DOES_NOT_EXIST);
			}
	
			UCDTInfo info = new UCDTInfo();
          
 			String UserIdString = resultset.getString(1);
			if(UserIdString == null)
			{
				info.setUserId( new com.infosys.feba.framework.types.primitives.FEBAUnboundString(""));
			} else {
				info.setUserId( new com.infosys.feba.framework.types.primitives.FEBAUnboundString(FormattedString.rightTrim(UserIdString)));
			}
			String MobNumString = resultset.getString(2);
			if(MobNumString == null)
			{
				info.setMobNum( new com.infosys.feba.framework.types.primitives.FEBAUnboundString(""));
			} else {
				info.setMobNum( new com.infosys.feba.framework.types.primitives.FEBAUnboundString(FormattedString.rightTrim(MobNumString)));
			}
			String EmailIdString = resultset.getString(3);
			if(EmailIdString == null)
			{
				info.setEmailId( new com.infosys.feba.framework.types.primitives.FEBAUnboundString(""));
			} else {
				info.setEmailId( new com.infosys.feba.framework.types.primitives.FEBAUnboundString(FormattedString.rightTrim(EmailIdString)));
			}


			if ( resultset.next() == true )
			{
				throw new FatalException(tc, "More than one record found in [" + tableName.getValue() + "] for key [" + infoKey.getKeyString() + "]");
			}

			return info;
		} catch ( SQLException e){
		
			if(RACExceptionHelper.checkRACSuspect(e))
			{
				throw new RACException(false, null,FEBAIncidenceCodes.RAC_EXCEPTION_SELECT,
				"RAC Error Occurred. Message:"
				+ e.getMessage() + " SQLState :[" + e.getSQLState()
				+ "] ErrorCode : [" + ErrorCodes.RAC_ERROR_OCCURRED + "]", 0, e, null);
			}
		
		
			throw new FatalException(tc, FEBAIncidenceCodes.GENERIC_SQL_EXCEPTION,e);
		} finally {
			if ( preparedStatement != null ) {
				try	{
					preparedStatement.close();					
			} catch ( SQLException e) {
				
				if(RACExceptionHelper.checkRACSuspect(e))
				{
					throw new RACException(false, null,FEBAIncidenceCodes.RAC_EXCEPTION_CLOSE_PREPARED_STATEMENT,
					"RAC Error Occurred. Message:"
					+ e.getMessage() + " SQLState :[" + e.getSQLState()
					+ "] ErrorCode : [" + ErrorCodes.RAC_ERROR_OCCURRED + "]", 0, e, null);
        			}
				
					throw new FatalException(tc, FEBAIncidenceCodes.COULD_NOT_CLOSE_PREPARED_STATEMENT,e);
				}
			}
		}
	}
  	
	 /**
     * This method executes selectforupdate statement for ORACLEDB and select followed by dummy update statement for NON-ORACLE DBs on the table
     * corresponding to this FEBAADAO implementation. It uses the members of FEBAAInfoKey
     * object 'febaInfoKey' provided as parameter and return an FEBAAInfo object
     * with values of all the fields of the table record.
     * 
     * @param tc - FEBATransactionContext object.
     * @param febaInfoKey - key of the table record to be fetched.
     * @return an FEBAAInfo object
     * @throws FEBATableOperatorException
     * @throws FatalException     
     */
         
     
    
    /**
     * This method executes insert statement on the table
     * corresponding to this FEBAADAO implementation. It should use the members of FEBAAInfo
     * object 'febaInfo' provided as parameter.
     * 
     * @param tc - FEBATransactionContext object.
     * @param febaInfo - table record to be inserted.
     * @return info - table record updated with FEBACookie details. 
     * @throws FEBATableOperatorException
     * @throws FatalException      
     */
    public FEBAAInfo insert(FEBATransactionContext tc, 
			FEBAAInfo febaInfo) throws FEBATableOperatorException,
			FatalException {
		UCDTInfo info = (UCDTInfo)febaInfo;
		UCDTInfoKey infoKey = (UCDTInfoKey)febaInfo.getInfoKey();
            	final int DUPLICATE_KEY_EXCEPTION = 1; 
            	final int MSSQL_DUPLICATE_KEY_EXCEPTION = 2601; 
		if (!infoKey.isValid()){
			LogManager.log(tc, "Invalid Key ["+infoKey.getKeyString()+"] in TAO insert for table [" + tableName+"]" ,LogManager.MESSAGE);			 

			throw new FEBATableOperatorException("Invalid Key ["+infoKey.getKeyString()+"] in TAO insert for table [" + tableName+"]");
		}

		String dbName = null ; 		
		PreparedStatement preparedStatement = null;
		Timestamp currentTimeStamp = DateUtil.currentDate(tc);
		try {
			Connection dbConnection = tc.getConnection().getSqlConnection();
	            
			
			preparedStatement = dbConnection.prepareStatement("INSERT INTO UCDT ( USER_ID,MOB_NUM,EMAIL_ID ) VALUES (  ? ,  ? ,  ?  ) ");
			
			if(info.getUserId().getValue().trim().length() == 0){
				throwInvalidKeyException(tc,new FEBAUnboundString("UserId"));
			}else{
				preparedStatement.setString(1 , info.getUserId().toString());
			}
				if(info.getMobNum() == null || info.getMobNum().getValue().trim().length() == 0){
				preparedStatement.setString(2 , null);
			}else{
				preparedStatement.setString(2 , info.getMobNum().toString());
			}
				if(info.getEmailId() == null || info.getEmailId().getValue().trim().length() == 0){
				preparedStatement.setString(3 , null);
			}else{
				preparedStatement.setString(3 , info.getEmailId().toString());
			}


			
			int rowsAffected = preparedStatement.executeUpdate();
            	
            	
            	if(rowsAffected != 0){
            	/**
            	* DBAudit hook. 
            	* CADT insert from Audit Framework
            	*/
            		String keyString =infoKey.getAuditInfo();
            		
            		String dataString =info.getAuditInfo();
            		IAudit iAudit = (IAudit)ApplicationConfig.getInstance(FEBAAuditConstants.AUDIT_INSTANCE_CLASS);
            		iAudit.doAudit(tc,keyString,dataString,"UCDT","USER_CONTACT_DETAILS_TABLE",FEBAConstants.AUDIT_FUNC_CODE_INSERT);
				}
				info.getCookie().setDbTs(new com.infosys.feba.framework.types.primitives.FEBADatabaseTimeStamp(1));
			com.infosys.feba.framework.types.primitives.FEBADate rmdate = new com.infosys.feba.framework.types.primitives.FEBADate();rmdate.setValue(currentTimeStamp);info.getCookie().setRModTime(rmdate);
			com.infosys.feba.framework.types.primitives.FEBADate rcdate = new com.infosys.feba.framework.types.primitives.FEBADate();rcdate.setValue(currentTimeStamp);info.getCookie().setRCreTime(rcdate);

			return info;            	            	
            }
			catch(CriticalException e1){
            	throw new FatalException(tc, FEBAIncidenceCodes.COULD_NOT_INSERT_AUDIT_RECORD,e1);
				}
    		
			catch ( SQLException e2){
			
			if(RACExceptionHelper.checkRACSuspect(e2))
			{
				throw new RACException(false, null,FEBAIncidenceCodes.RAC_EXCEPTION_INSERT,
				"RAC Error Occurred. Message:"
				+ e2.getMessage() + " SQLState :[" + e2.getSQLState()
				+ "] ErrorCode : [" + ErrorCodes.RAC_ERROR_OCCURRED + "]", 0, e2, null);
        		}
        		if((e2.getErrorCode() == DUPLICATE_KEY_EXCEPTION)||(e2.getErrorCode() == MSSQL_DUPLICATE_KEY_EXCEPTION)){
			    	throw new FEBATableOperatorException(FEBAConstants.UNIQUE_CONSTRAINT_VIOLATION,ErrorCodes.ANOTHER_RECORD_EXISTS,e2);
    			}
			throw new FatalException(tc, FEBAIncidenceCodes.GENERIC_SQL_EXCEPTION,e2);
		} finally {
			if ( preparedStatement != null ) {
				try {
					preparedStatement.close();					
					} catch ( SQLException e3) {
					
						if(RACExceptionHelper.checkRACSuspect(e3))
						{
							throw new RACException(false, null,FEBAIncidenceCodes.RAC_EXCEPTION_CLOSE_PREPARED_STATEMENT,
							"RAC Error Occurred. Message:"
							+ e3.getMessage() + " SQLState :[" + e3.getSQLState()
							+ "] ErrorCode : [" + ErrorCodes.RAC_ERROR_OCCURRED + "]", 0, e3, null);
						}
					throw new FatalException(tc, FEBAIncidenceCodes.COULD_NOT_CLOSE_PREPARED_STATEMENT,e3);
				}
			}
		}
	}
    
    /**
     * This method executes update statement on 
     * the table corresponding to this FEBAADAO implementation.
     * It should use the members of FEBAAInfo object 'febaInfo' provided as
     * parameter.
     * 
     * @param tc - FEBATransactionContext object.
     * @param febaInfo - comprises of updated values of all the fields in the table record.
     * @return info - table record updated with FEBACookie details.     
     * @throws FEBATableOperatorException
     * @throws FatalException      
     */
    public FEBAAInfo update(FEBATransactionContext tc, 
                       FEBAAInfo febaInfo) throws FEBATableOperatorException,
                       FatalException {

            UCDTInfo info = (UCDTInfo)febaInfo;
            UCDTInfoKey infoKey = (UCDTInfoKey)info.getInfoKey();
            
		if (!infoKey.isValid()){
			LogManager.log(tc, "Invalid Key ["+infoKey.getKeyString()+"] in TAO update for table [" + tableName+"]" ,LogManager.MESSAGE);

			throw new FEBATableOperatorException("Invalid Key ["+infoKey.getKeyString()+"] in TAO update for table [" + tableName+"]");
		}

		PreparedStatement preparedStatement = null;
		Timestamp currentTimeStamp = DateUtil.currentDate(tc);
		try
		{
			Connection dbConnection = tc.getConnection().getSqlConnection();
			preparedStatement = dbConnection.prepareStatement("UPDATE UCDT SET MOB_NUM = ? ,EMAIL_ID = ?  WHERE USER_ID = ? ");
				
						if(info.getMobNum() == null || info.getMobNum().getValue().trim().length() == 0){
				preparedStatement.setString(1 , null);
			}else{
				preparedStatement.setString(1 , info.getMobNum().toString());
			}
			if(info.getEmailId() == null || info.getEmailId().getValue().trim().length() == 0){
				preparedStatement.setString(2 , null);
			}else{
				preparedStatement.setString(2 , info.getEmailId().toString());
			}
			if(infoKey.getUserId().getValue().trim().length() == 0){
				throwInvalidKeyException(tc,new FEBAUnboundString("UserId"));
			}else{
				preparedStatement.setString(3 , new FormattedString(infoKey.getUserId().getValue(), infoKey.getUserId().getMaxLength()  ).value);
			}


			int rowsAffected = preparedStatement.executeUpdate();
				
						if(rowsAffected == 1){
		            		String keyString =infoKey.getAuditInfo();
		            		
		            		String dataString =info.getAuditInfo();
		            		/**
			            	* DBAudit hook. 
            				* CADT insert from Audit Framework
            				*/
		            		IAudit iAudit = (IAudit)ApplicationConfig.getInstance(FEBAAuditConstants.AUDIT_INSTANCE_CLASS);
            				iAudit.doAudit(tc,keyString,dataString,"UCDT","USER_CONTACT_DETAILS_TABLE",FEBAConstants.AUDIT_FUNC_CODE_MODIFY);
								
		            	}
						
			if ( rowsAffected != 1 )
			{
				LogManager.log(tc, "Unexpected result from Update query for keyString ["+infoKey.getKeyString()+"] in table [" + tableName+"] . Rows Affected:" + rowsAffected , LogManager.MESSAGE);
				throw new FEBATableOperatorException("Unexpected result from Update query for keyString ["+infoKey.getKeyString()+"] in table [" + tableName+"] . Rows Affected:" + rowsAffected);

			}

			info.getCookie().setDbTs(new com.infosys.feba.framework.types.primitives.FEBADatabaseTimeStamp(info.getCookie().getDbTs().getValue()+1));
			com.infosys.feba.framework.types.primitives.FEBADate rmdate = new com.infosys.feba.framework.types.primitives.FEBADate();rmdate.setValue(currentTimeStamp);info.getCookie().setRModTime(rmdate);

								
			return info;  
              }
			catch(CriticalException e1){
            	throw new FatalException(tc, FEBAIncidenceCodes.COULD_NOT_INSERT_AUDIT_RECORD,e1);
				}
    		
			catch ( SQLException e2){
			
				if(RACExceptionHelper.checkRACSuspect(e2))
				{
					throw new RACException(false, null,FEBAIncidenceCodes.RAC_EXCEPTION_UPDATE,
					"RAC Error Occurred. Message:"
					+ e2.getMessage() + " SQLState :[" + e2.getSQLState()
					+ "] ErrorCode : [" + ErrorCodes.RAC_ERROR_OCCURRED + "]", 0, e2, null);
				}
			throw new FatalException(tc, FEBAIncidenceCodes.GENERIC_SQL_EXCEPTION,e2);
		} finally {
			if ( preparedStatement != null ) {
				try	{
					preparedStatement.close();					
					} catch ( SQLException e3) {
						if(RACExceptionHelper.checkRACSuspect(e3))
						{
							throw new RACException(false, null,FEBAIncidenceCodes.RAC_EXCEPTION_CLOSE_PREPARED_STATEMENT,
							"RAC Error Occurred. Message:"
							+ e3.getMessage() + " SQLState :[" + e3.getSQLState()
							+ "] ErrorCode : [" + ErrorCodes.RAC_ERROR_OCCURRED + "]", 0, e3, null);
        					}
					throw new FatalException(tc, FEBAIncidenceCodes.COULD_NOT_CLOSE_PREPARED_STATEMENT,e3);
				}
			}
		}
    }

    /**
     * This method should executes actual delete statement on 
     * the table corresponding to this FEBAADAO implementation.Physical delete is a delete
     * operation that deletes the record under consideration from the table.It 
     * should use the members of FEBAAInfoKey object 'febaInfoKey' provided as
     * parameter.
     * 
     * @param tc - FEBATransactionContext object.
     * @param febaInfoKey - key of the table record to be deleted.
     * @param cookie - FEBACookie object.    
     * @throws FEBATableOperatorException
     * @throws FatalException      
     */
    public void physicalDelete(FEBATransactionContext tc, 
                               FEBAAInfoKey febaInfoKey, 
                               FEBACookie cookie) throws FEBATableOperatorException,
                               FatalException {
       
		UCDTInfoKey infoKey = (UCDTInfoKey)febaInfoKey;

		if (!infoKey.isValid()){
			LogManager.log(tc, "Invalid Key ["+infoKey.getKeyString()+"] in TAO physicalDelete for table [" + tableName+"]",LogManager.MESSAGE );

			throw new FEBATableOperatorException("Invalid Key ["+infoKey.getKeyString()+"] in TAO physicalDelete for table [" + tableName+"]");
		}
		PreparedStatement preparedStatement = null;
		try
		{
			Connection dbConnection = tc.getConnection().getSqlConnection();

			if ((int)cookie.getDbTs().getValue() != 0)
			{					
				preparedStatement = dbConnection.prepareStatement("DELETE FROM UCDT WHERE USER_ID = ? ");
			}
			else
			{ 					
				preparedStatement = dbConnection.prepareStatement("DELETE FROM UCDT WHERE USER_ID = ? ");
			}

			if ((int)cookie.getDbTs().getValue() != 0)
			{					
				if(infoKey.getUserId().getValue().trim().length() == 0){
					throwInvalidKeyException(tc,new FEBAUnboundString("UserId"));
				}else{
					preparedStatement.setString(1, new FormattedString(infoKey.getUserId().getValue(), infoKey.getUserId().getMaxLength()  ).value );
				}


			}
			else
			{					
				if(infoKey.getUserId().getValue().trim().length() == 0){
					throwInvalidKeyException(tc,new FEBAUnboundString("UserId"));
				}else{
					preparedStatement.setString(1, new FormattedString(infoKey.getUserId().getValue(), infoKey.getUserId().getMaxLength()  ).value );
				}


			}	
			int rowsAffected = preparedStatement.executeUpdate();

			if ( rowsAffected == 0 )
			{
				LogManager.log(tc, "Unexpected result from Delete query for keyString ["+infoKey.getKeyString()+"] in table [" + tableName+"] . Rows Affected:" + rowsAffected , LogManager.MESSAGE);

				throw new FEBATableOperatorException("Unexpected result from Delete query for keyString ["+infoKey.getKeyString()+"] in table [" + tableName+"] . Rows Affected:" + rowsAffected, ErrorCodes.RECORD_COULD_NOT_BE_DELETED);
			}
				
					if( rowsAffected != 0){
	            		String keyString =infoKey.getAuditInfo();
	            		/**
			            * DBAudit hook. 
            			* CADT insert from Audit Framework
            			*/	
	            		IAudit iAudit = (IAudit)ApplicationConfig.getInstance(FEBAAuditConstants.AUDIT_INSTANCE_CLASS);
                        iAudit.doAudit(tc,keyString,keyString,"UCDT","USER_CONTACT_DETAILS_TABLE",FEBAConstants.AUDIT_FUNC_CODE_DELETE);
					}
						}catch(CriticalException e){
			            	throw new FatalException(tc, FEBAIncidenceCodes.COULD_NOT_INSERT_AUDIT_RECORD,e);
						}	
            	
			catch ( SQLException e){
				if(RACExceptionHelper.checkRACSuspect(e))
				{
					throw new RACException(false, null,FEBAIncidenceCodes.RAC_EXCEPTION_DELETE,
					"RAC Error Occurred. Message:"
					+ e.getMessage() + " SQLState :[" + e.getSQLState()
					+ "] ErrorCode : [" + ErrorCodes.RAC_ERROR_OCCURRED + "]", 0, e, null);
        			}
			throw new FatalException(tc, FEBAIncidenceCodes.GENERIC_SQL_EXCEPTION,e);
		} finally {
			if ( preparedStatement != null ) {
				try	{
					preparedStatement.close();					
				} catch ( SQLException e) {
				
					if(RACExceptionHelper.checkRACSuspect(e))
					{
						throw new RACException(false, null,FEBAIncidenceCodes.RAC_EXCEPTION_CLOSE_PREPARED_STATEMENT,
						"RAC Error Occurred. Message:"
						+ e.getMessage() + " SQLState :[" + e.getSQLState()
						+ "] ErrorCode : [" + ErrorCodes.RAC_ERROR_OCCURRED + "]", 0, e, null);
        				}
					throw new FatalException(tc, FEBAIncidenceCodes.COULD_NOT_CLOSE_PREPARED_STATEMENT,e);
				}
			}
		}
	}
    
     /**
     * This utility method is called to throw FEBATableOperatorException 
     * when the value of key fields is passed as null or blank for DB operations  
     * 
     * @param tc - FEBATransactionContext object.
     * @param keyFieldName - The name of the Key field
     * @throws FEBATableOperatorException
     */
    private void throwInvalidKeyException(FEBATransactionContext tc, 
                               FEBAUnboundString keyFieldName) throws FEBATableOperatorException{
          throw new FEBATableOperatorException("The key field ["+keyFieldName+"] should not be passed as null or blank",
          			ErrorCodes.TAO_INVALID_KEY_FIELD_VALUE);
    }    
}
