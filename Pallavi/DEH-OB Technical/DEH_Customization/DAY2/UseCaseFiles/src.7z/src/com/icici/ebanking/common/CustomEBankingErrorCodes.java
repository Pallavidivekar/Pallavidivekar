	package com.icici.ebanking.common;

/*
 * CustomEBankingErrorCodes.java
 * @author
 * @since Feb 2012
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
import com.infosys.feba.framework.common.exception.IErrorCodes;

public class CustomEBankingErrorCodes implements IErrorCodes {
	/**
	 * Class containing all custom error code constants
	 *
	 * @author
	 * @version 1.0
	 * @since FEBA 2.0
	 */
	public CustomEBankingErrorCodes() {

	}

	public int getHighestErrorCode() {
		return HIGHEST_ERROR_CODE;
	}

public static final int MINIMUM_AMOUNT_VOID = 99568;
public static final int MAXIMUM_AMOUNT_VOID = 99569;
public static final int MIN_MAX_DIFFERENCE = 99578;
public static final int QUIPAYEE_LIST_NOT_AVAILABLE = 12116;
public static final int TRANSACTION_LIMIT = 995682;
private static final int HIGHEST_ERROR_CODE = 990102;
public static final int  VIEW_AMORT_FLAG = 995503;
public static final int TEST = 1;
public static final int ACCOUNT_NUMBER_LENGTH = 2;
public static final int ACCOUNT_NUM_NOT_MATCHING = 3;
public static final int ACCT_NAME_NOT_MATCHING = 4;
public static final int MANDATORY_FIELDS_CANNOT_BE_BLANK_RE_ACCT_NUM = 5;
public static final int CONTACT_UPDATE_SUCCESS = 7;
public static final int ACCOUNT_CONTACT_UPDATE_SUCCESS = 8;
public static final int EMAILID_LENGTH_EXCEEDED = 9;
public static final int CUSR_LOGIN_ATTEMPTS_UPDATE_FAILED = 10;
public static final int RESET_NUM_OF_LOGINS_SUCCESSFUL = 11;
public static final int NUM_OF_LOGINS_MANDATORY = 12;

//Added for CUSRUPDT batch
public static final int PROCESSING_FAILED_FOR_CUSRUPDT_BATCH = 13;
public static final int CULN_DATA_FETCH_HAS_FAILED = 14;
public static final int NO_RECORDS_FOUND_IN_CLOC_FOR_GIVEN_INPUT = 15;
public static final int CUSR_UPDATE_HAS_FAILED_FOR_CUSRUPDT_BATCH = 16;

//Added for ATMUPLD batch
public static final int BILLER_ID_REQUIRED = 111140;
public static final int BILLER_NAME_REQUIRED = 111141;
public static final int BILLER_CATEGORY_REQUIRED = 111142;
public static final int AUTHENTICATOR_ONE_REQUIRED = 111143;
public static final int MIN_LEGNTH_REQUIRED = 111144;
public static final int MAX_LEGNTH_REQUIRED = 111145;
public static final int LABLE_REQUIRED = 111146;
public static final int PATTERN_REQUIRED = 111147;
public static final int MINIMU_VALUE_EXCEEDS = 12102;
public static final int MINIMU_VALUE_NUMBERS = 12102;
public static final int INVALID_ADMIN_ID_PASSED_ATMUPLD = 17;
public static final int INVALID_PRIMARY_ACCOUNT_ID_PASSED_ATMUPLD = 18;
public static final int INVALID_MENU_PROFILE_CODE_PASSED_ATMUPLD = 19;
public static final int INSERTION_INTO_IUSR_HAS_FAILED_ATMUPLD = 20;
public static final int INSERTION_INTO_CSIP_HAS_FAILED_ATMUPLD = 21;
public static final int INSERTION_INTO_CUSR_HAS_FAILED_ATMUPLD = 22;
public static final int INSERTION_INTO_CULN_HAS_FAILED_ATMUPLD = 23;
public static final int INSERTION_INTO_UART_HAS_FAILED_ATMUPLD = 207;
public static final int PROCESSING_FAILED_IN_ATMUPLD_BATCH = 24;
public static final int INSERTION_INTO_UADT_HAS_FAILED_ATMUPLD = 351;
public static final int INSERTION_INTO_SIDT_HAS_FAILED_ATMUPLD = 352;

//Added for BulkPwd batch
public static final int PROCESSING_FAILED_IN_BULKPWD_BATCH = 331;
public static final int PWD_RESET_DONE_RECENTLY = 995412;

//Added for ChannelUserId Validation
public static final int FIRST_TWO_LETTERS_MUST_BE_ALPHABETS = 25;
public static final int SPECIAL_CHARACTERS_NOT_ALLOWED = 26;

//Added for channelUserId validation
public static final int INTERUPT_CAR_USER_ID = 995657;

//Added for Service request
public static final int IMPROPER_MOBILE_LENGTH = 27;
public static final int TELEPHONE_NUMBER_LENGTH_EXCEEDED = 28;
public static final int INVALID_TELEPHONE_NUMBER = 29;
public static final int MAX_CUSTID_LENGTH_EXCEEDED = 30;
public static final int CUSTID_CONTAINS_SPECIAL_CHARS = 31;
public static final int IMPROPER_LENGTH_FOR_NAME_TO_BE_PRINTED_ON_CARD = 32;
public static final int FROM_DATE_INVALID = 33;
public static final int PAN_IS_REQD = 34;
public static final int EMAILID_UPDATED = 35;
public static final int CONTACT_UPDATED = 36;
public static final int INVALID_PAST_DATE = 37;
public static final int EXISTING_NEW_MOBILE_NO_CANNOT_BE_SAME = 38;
public static final int EXISTING_NEW_EMAIL_ID_CANNOT_BE_SAME = 39;
public static final int INVALID_SERVICE_REQUEST_NUMBER = 40;
public static final int INVALID_TELEPHONE_NUMBER_MIN_LENGTH = 41;
public static final int ATM_BANK_NAME_INVALID_LENGTH = 42;
public static final int TXN_ID_DISPUTED_INVALID_LENGTH = 43;
public static final int SUBMISSION_DATE_IS_ONE_YEAR_OLD = 44;
public static final int INVALID_PAST_DATE_3MONTHS = 45;
public static final int INVALID_PAST_DATE_7DAYS = 46;
public static final int INVALID_PAST_DATE_9DAYS = 47;
public static final int INVALID_PAST_DATE_15DAYS = 48;
public static final int IMPROPER_CHEQUE_LENGTH = 49;
public static final int LANDLINE_NUMBER_LENGTH_EXCEEDED = 50;
public static final int LANDLINE_NUMBER_MIN_LENGTH = 51;
public static final int INVALID_LANDLINE_NUMBER = 52;
public static final int INVALID_PIN_LENGTH = 53;
public static final int INVALID_DESCRIPTION = 54;

public static final int INVALID_PRIOR_DATE = 56;
public static final int ONLY_ALPHABETS_ALLOWED = 57;
public static final int ONLY_ALPHABETS_SPACE_ALLOWED = 58;
public static final int REASON_WITHDRAWAL_INVALID_LENGTH = 59;
public static final int MERCHANT_NAME_INVALID_LENGTH = 60;
public static final int TXN_AMOUNT_INVALID_LENGTH_MAX = 61;
public static final int TXN_AMOUNT_INVALID_LENGTH_MIN = 62;
public static final int ATMID_INVALID_LENGTH = 63;
public static final int TXNID_INVALID_LENGTH = 64;
public static final int PREVIOUS_REQUEST_NUMBER_INVALID_LENGTH = 65;
public static final int ONLY_ALPHANUMERIC_ALLOWED = 66;
public static final int ONLY_ALPHANUMERIC_SPACE_ALLOWED = 67;
public static final int FROM_DATE_SHOULD_BE_FIRST_DAY = 68;
public static final int FROM_DATE_SHUD_BE_PRIOR_TO_CURRENT_MONTH = 69;
public static final int TO_DATE_SHUD_BE_PRIOR_TO_CURRENT_MONTH = 70;
public static final int FROM_DATE_INVALID_RDS = 71;
public static final int TO_DATE_SHOULD_BE_LAST_DAY = 72;
public static final int IMPROPER_AMT_FOR_TITANIUM_CC_FD = 73;
public static final int IMPROPER_TENURE_FOR_TITANIUM_CC_FD = 74;
public static final int IMPROPER_AMT_FOR_PLATINUM_CC_FD = 75;
public static final int IMPROPER_TENURE_FOR_PLATINUM_CC_FD = 76;
public static final int INCORRECT_PAN_NUMBER = 77;
public static final int DOB_NOT_UPDATED_IN_SYSTEM = 78;
public static final int ACCT_BAL_INSUFFICIENT_FOR_FD = 79;
public static final int ACCT_BAL_INSUFFICIENT_FOR_RD = 80;
public static final int INVALID_RD_AMOUNT = 81;
public static final int MAX_TENURE_FOR_RD = 82;
public static final int MIN_TENURE_FOR_RD = 83;
public static final int INVALID_DAY_FOR_RD_SELECTED = 84;
public static final int INVALID_STD_LENGTH = 85;
public static final int INCORRECT_TENURE_FOR_SPECIAL_FD = 86;
public static final int INCORRECT_TENURE_FOR_NORMAL_FD = 87;
public static final int INCORRECT_TENURE_FOR_PERIODIC_FD = 88;
public static final int MIN_TENURE_FOR_FD = 89;
public static final int MAX_TENURE_FOR_FD = 90;
public static final int MERCHANT_ID_INVALID_LENGTH_MIN = 91;
public static final int MERCHANT_ID_INVALID_LENGTH_MAX = 92;
public static final int CME_EMI_AMOUNT_INVALID = 93;
public static final int IMPROPER_BALANCETRANSFERDDNO_LENGTH = 95;
public static final int IMPROPER_FDACCOUNTNO_LENGTH = 96;
public static final int IMPROPER_AMOUNT_VALUE = 97;
public static final int IMPROPER_MAX_AMOUNT_VALUE = 98;
public static final int IMPROPER_DATE_OF_BIRTH = 99;
public static final int IMPROPER_CASEID_LENGTH = 100;
public static final int IMPROPER_CUSTOMERNAME_LENGTH = 101;
public static final int IMPROPER_ADDRESS_WHERE_RQST_SUBMITTED_LENGTH = 102;
public static final int INVALID_CARD_NUM_LENGTH = 103;
public static final int IMPROPER_COURIER_NAME_LENGTH = 104;
public static final int IMPROPER_NAME_TO_BE_ADDED_LENGTH = 105;
public static final int IMPROPER_AIRWAY_BILL_NO_LENGTH = 106;
public static final int INVALID_DATE = 107;
public static final int INVALID_PAST_DATE_3DAYS = 108;
public static final int INVALID_CHECKBOX = 110;
public static final int INVALID_PAST_DATE_2DAYS = 114;
public static final int MAINTAIN_QUARTERLY_AVG = 115;
public static final int HOLD_NRE_SAVINGS_ACCOUNT = 116;
public static final int INVALID_CONTACT_NUM = 117;
public static final int INVALID_MIN_AMOUNT_UNE = 118;
public static final int AMT_LESS_THAN_100000 = 119;
public static final int TIME_OF_SUBMISSION_LIMIT = 141;
public static final int INVALID_PAST_DATE_4DAYS = 271;
public static final int IMPROPER_LENGTH_FOR_ATM_ID = 197;
public static final int IMPROPER_LENGTH_FOR_TRAN_NO = 198;
public static final int FIELDVALUE_SHOULD_NOT_BE_ZERO = 275;
public static final int IMPROPER_AMT_FOR_PLATINUM_CHIP_CC_FD = 995031; //Added for CR231


//Added for ULDT table
public final static int ULDT_LICENCE_INSERTION_FAILED = 51001;
public final static int ULDT_DUPLICATE_LICENCE_INSERTION_FAILED = 51002;
public final static int ULDT_LICENCE_UPDATE_FAILED = 51003;
public final static int ULDT_MAX_ACTIVE_DEVICES = 51004;
public final static int ULDT_STATUS_DEACTIVATED = 51006;
public final static int ULDT_STATUS_STOLEN = 51007;
public final static int ULDT_STATUS_AUTODEACTIVATE = 51008;
public final static int ULDT_NO_RECORDS_FETCHED = 51010;



//Added for BULKMAILER batch
public static final int USER_ID_CANNOT_BE_BLANK = 111;
//public static final int ALIAS_ID_IS_INVALID = 112;
public static final int RECORD_NOT_FOUND_IN_CUSR = 113;
public static final int PROCESSING_FAILED_IN_BULKMAILERUPLD_BATCH = 122;
public static final int SUBJECT_CANNOT_BE_BLANK = 124;
public static final int MAILBODY_CANNOT_BE_BLANK = 125;
public static final int INVALID_QUERY_DESCRIPTION_LENGTH = 123;
public static final int INVALID_REASON = 126;
public static final int INVALID_CARDNUMBER = 127;
public static final int INVALID_ADDONCARD = 128;
public static final int INVALID_CONTACTNUMBER = 129;
public static final int IMPROPER_DOB = 130;
public static final int ONLY_ALPHABETS_ALLOWED_FOR_NAME = 131;
public static final int IMPROPER_PRESET_LENGTH = 132;
public static final int INVALID_CHEQUE_NO_LENGTH = 134;
public static final int INVALID_DRAWEE_BANK_NAME_LENGTH = 135;
public static final int INVALID_EARLIER_SR_OR_CASE_ID_NO_LENGTH = 136;
public static final int CITY_IS_MANDATORY_IF_PLACE_OF_DEPOSIT_IS_BRANCH = 137;
public static final int INVALID_PAST_DATE_3DAYS_FROM_DEPOSIT = 138;
public static final int INVALID_PAST_DATE_5DAYS_FROM_DEPOSIT = 139;
public static final int IMPROPER_ACCOUNT_NUMBER = 140;
public static final int EMI_AMOUNT_INVALID = 142;
public static final int AMOUNT_INVALID = 143;
public static final int PAYMENT_BILLER_NOT_MODIFY = 145;
public static final int LENGTH_LESS_THAN_MINIMUM_LENGTH_NOT_ALLOWED_IN_FIELD_NAME = 147;
public static final int FIELD_SHOULD_CONTAIN_ONLY_NUMBERS = 148;
public static final int FIELD_SHOULD_CONTAIN_ONLY_ALPHABETS = 149;
public static final int FIELD_SHOULD_CONTAIN_ONLY_ALPHANUMERIC = 150;
public static final int FIELD_SHOULD_CONTAIN_ONLY_ALPHABETS_OR_SPECIAL_CHARS = 151;
public static final int STARTING_CHARACTER_SET_NOT_VALID = 152;
public static final int INDEX_DIGIT_NOT_VALID = 153;

//added for demat validations
public static final int SPECIAL_CHAR_NOT_ALLOWED_FOR_CMBC = 154;
public static final int SPECIAL_CHAR_NOT_ALLOWED_FOR_SETLMNTAMT = 155;

//added for biller specific validation
public static final int IMPROPER_ACCOUNT_NUMBER_LENGTH = 156;
public static final int INVALID_ACCOUNT_NUMBER_MTNL = 157;
public static final int INVALID_FIELD_VALUE_ONLY_ALPHABET_HYPHEN = 158;
public static final int INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_SPACE_HYPHEN = 159;
public static final int INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_HYPHEN = 160;
public static final int INVALID_CONSUMER_NUMBER_LENGTH = 161;
public static final int CREDIT_CARD_NUMBER_INVALID = 162;
public static final int CUST_NO_SHOULD_START_WITH_619 = 163;
public static final int CUST_NO_FOURTH_CHAR_SHOULD_BE_NOB = 164;
public static final int UNIQUE_REG_NUM_BILLER = 165;
public static final int CUST_NO_FIFTH_CHAR_SHOULD_BE_123 = 166;

public static final int STD_CODE_IN_TELEPHONENO_SHOULD_STARTWITH_022 = 177;
public static final int FIRSTTHREE_DIGITS_OF_ACCTNO_122_4THDIGIT_HYPHEN = 178;
public static final int POLICYNO_SHOULD_STARTWITH_3 = 179;
public static final int FIFTHDIGITOF_POLICYNO_FORWARDSLASH = 180;
public static final int LASTDIGITS_OF_POLICY_SHOULDNOTBE_LEFT_BLANK = 181;
public static final int FIELDVALUE_SHOULDBE_NUMERIC_DOT_ALLOWED = 182;
public static final int FIELDVALUE_SHOULDBE_NUMERIC_HYPEHN_ALLOWED = 183;
public static final int ACCT_NOT_APPLICABLE_FOR_BILLER = 184;
public static final int NICKNAME_ALREADY_EXISTS_DELETE = 188;
//public static final int INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_FWDSLASH = 189;
public static final int FOURTH_DIGIT_OF_BILLNUMBER_HYPHEN = 190;
public static final int EIGTH_DIGIT_OF_BILLNUMBER_HYPHEN = 191;
public static final int TWELVETH_DIGIT_OF_BILLNUMBER_ASTRIEK = 192;
public static final int INVALID_BILLNUMBER = 193;
public static final int MAX_PAYEE_NAME_LENGTH = 194;
public static final int MAX_PAYEE_NICKNAME_LENGTH = 195;
public static final int FIELDVALUE_SHOULDBE_NUMERIC = 196;
public static final int PAYMENT_ALREADY_REVERSED = 197;
public static final int PAYMENT_CANNOT_BE_REVERSED = 198;
public static final int PID_IP_NOT_MATCHING = 199;
public static final int PAYEE_ID_MANDATORY = 200;
public static final int TRANSACTION_AMOUNT_MANDATORY = 201;
public static final int ITEM_CODE_MANDATORY = 202;
public static final int PAYMENT_REFERENCE_NUMBER_MANDATORY = 203;
public static final int TRANSACTION_CURRENCY_MANDATORY = 204;
public static final int PAYMENT_ID_MANDATORY = 205;
public static final int TRANSACTION_TIME_MANDATORY = 206;
public static final int RETURN_URL_MANDATORY = 207;
// public static final int NO_MATCHING_RECS_FOR_TRACKING = 208;
public static final int INVALID_FD_NUMBER = 209;
public static final int IMPROPER_CREDITCRDNO_LENGTH = 215;
public static final int IMPROPER_DIRECT_CREDITCRDNO = 216;
public static final int IMPROPER_VIRTUAL_CREDITCRDNO = 217;
public static final int IMPROPER_ADD_ON_CREDITCRDNO = 218;
public static final int IMPROPER_CREDITCRDNO = 219;
public static final int IMPROPER_LOAN_ACCNT_NO_LENGTH = 220;
public static final int INVALID_FIRST_LOAN_ACCNT_NO = 221;
public static final int INVALID_LAST_LOAN_ACCNT_NO = 222;
public static final int IMPROPER_SAVINGS_ACCNT_NO = 223;
public static final int IMPROPER_DIRECT_SAVINGS_ACCNT_NO = 224;

//Added for Duplicate Check in SR
public static final int SERVICE_REQUEST_SUCCESS_MESSAGE = 146;
public static final int SERVICE_REQUEST_DUPLICATES_MESSAGE = 186;
public static final int SERVICE_REQUEST_UNABLE_TO_PROCCESS = 234;

//Added for RTGS address validations
public static final int RTGS_ADDRESS_MANDATORY = 210;
public static final int RTGS_CITY_MANDATORY = 211;
public static final int RTGS_ZIP_MANDATORY = 213;
public static final int RTGS_STATE_MANDATORY = 214;

//added for demat validations
public static final int SPECIAL_CHAR_NOT_ALLOWED_FOR_DOCUMENTNO = 230;
public static final int SPECIAL_CHAR_NOT_ALLOWED_FOR_ISIN = 227;

public static final int INVALID_CUSTOMERID = 133;
public static final int ONLY_ALPHANUMERIC_VEHICLENO_ALLOWED = 144;
public static final int IMPROPER_BENEFICIARYNAME_LENGTH = 167;
public static final int IMPROPER_BENEFICIARYADDRESS_LENGTH = 168;
public static final int IMPROPER_BENEFICIARYCITY_LENGTH = 169;
public static final int IMPROPER_BENEFICIARYSTATE_LENGTH = 170;
public static final int IMPROPER_BENEFICIARYPINCODE_LENGTH = 171;
public static final int IMPROPER_BENEFICIARYPHONE_LENGTH = 172;
public static final int AMOUNT_INR_FOREIGN = 173;
public static final int INVALID_AMOUNT_FOREIGN = 174;
public static final int INVALID_AMOUNT_INR = 175;
public static final int IMPROPER_NREACCOUNTNO_LENGTH = 176;
public static final int IMPROPER_CONTACTNUMBER = 187;
public static final int INVALID_FDAMOUNT_VAL = 225;
public static final int INVALID_PAN_VAL = 226;
// public static final int INVALID_ACCOUNT_NO_START = 231;
// public static final int INVALID_DECIMAL_PATTERN = 232;
// public static final int INVALID_ACCOUNT_NO = 233;
// public static final int INVALID_BILL_NAME = 234;

//Added as part of Login module customization
public static final int MOB_NUM_ENTERED_NOT_MATCHED_WITH_REGISTERED_NUMBER = 236;
public static final int EMAILID_ENTERED_NOT_MATCHED_WITH_REGISTERED_ID = 237;
public static final int MOB_NUM_EMAILID_ENTERED_NOT_MATCHED_WITH_REGISTERED_MOB_NUM_EMAIL_ID = 455;
public static final int EMAILID_IS_MANDATORY = 238;
public static final int MOBILENUMBER_IS_MANDATORY = 239;
public static final int LOGIN_TXN_PWDS_CANT_CHANGE = 240;
public static final int RECORD_NOT_FOUND_IN_AMPM = 241;
public static final int USER_NOT_LINKED_TO_MENUID = 242;
public static final int USR_NOT_FOUND_IN_UTML = 243;
public static final int RECORD_NOT_FOUND_IN_BAFT = 170893;
//Added for grid card
public static final int INITIATOR_ACOUNT_NOT_FOUND = 231;
public static final int NO_VALID_CARDS_FOUND_FOR_USER = 232;
public static final int NO_RESPONSE_FROM_HOST_FOR_AUTHENTICATING_CARD = 233;
public static final int FAILED_TO_PROCCESS_GRID_CARD_AUTH = 235;

//added for issue id 306633
public static final int NICKNAME_IS_ALPHANUMERIC = 244;
public static final int EMAIL_ID_OR_MOBILE_NO_REQUIRED = 245;

//Added for Repatriation from FCNR / NRE FD via Wire Transfer
public static final int IMPROPER_LENGTH_FOR_BENEFICIARY_NAME = 255;
public static final int IMPROPER_BENEFICIARY_BANK_DETAILS = 109;
public static final int DEPOSIT_CANNOT_BE_CLOSED_ON_MATURITY = 212;
public static final int IMPROPER_AMOUNT_NULL = 228;

// Added for Address deletion not done
public static final int IMPROPER_LENGTH_FOR_SRNUM = 250;
public static final int IMPROPER_CITY_NAME = 251;

public static final int EMAIL_ID_MANDATORY = 252;
public static final int INVALID_AMOUNT_REQ_RCVD = 253;
public static final int INVALID_MIN_TXN_NUMBER = 254;
public static final int CHEQUE_NUMBER_AND_DATE_NOT_ENTERED = 255;
public static final int CHEQUE_NUMBER_NOT_ENTERED = 256;
public static final int CHEQUE_DATE_NOT_ENTERED = 257;
public static final int BENEFICIARYNAME_IS_MANDATORY = 258;
public static final int BENEFICIARYNICKNAME_IS_MANDATORY = 259;
public static final int BENEFICIARYADDRESS_IS_MANDATORY = 260;
public static final int DEBITACCOUNT_IS_MANDATORY = 261;
public static final int DELIVERYOFGOLD_IS_MANDATORY = 262;
public static final int PREFERREDBRANCH_IS_MANDATORY = 263;
public static final int PREFERREDCITY_IS_MANDATORY = 264;

public static final int INVALID_PREMATURE_JOINT = 270;

//Added for View Insurance Summary
public static final int NO_POLICIES_LINKED = 268;
public static final int UNABLE_TO_FETCH_LIST_OF_POLICIES = 269;

//Added for the validation in MayIHelpYou
public static final int SUN_SAT_HOLIDAYS = 272;
public static final int TIME_OF_SUBMISSION = 273;
public static final int DETAILS_UPLOAD_FAILED = 234;
public static final int SUCCESS_OF_CLICKTOCALL_WEALTH = 2991;
public static final int SUCCESS_OF_CLICKTOCALL_PRIVATE = 2891;

public static final int DTH_RCHG_REQ_INITIATION_FAILED = 397;
public static final int DTH_RCHG_REQ_SUC_PMT_FAL = 398;
public static final int DTH_RCHG_REQ_SUSPECT = 396;
public static final int DTH_RCHG_REQ_SUCCESS = 394;
public static final int DTH_RCHG_REQ_FAILURE = 395;
public static final int DTH_RCHG_SETUP_IMPROPER = 399;
public static final int DTH_RCHG_SERVICE_PROVIDER_MANDATORY = 106602;

//Added for Bank Sr

public static final int INVALID_8_MINLENGTH_ATMID = 276;
public static final int INVALID_ATM_SELECT = 277;
public static final int INVALID_ATM_CITY_REQ = 280;
public static final int INVALID_ATM_BRANCH_REQ = 281;
public static final int INVALID_6_MINLENGTH_Pincode = 1504;
public static final int INVALID_6_MINLENGTH_TelePhoneNo = 1508;
public static final int INVALID_6_MINLENGTH_FaxNo = 1509;
public static final int INVALID_PAST_DATE_5DAYS_FROM_CHEQUE_RETURN = 278;
public static final int INVALID_CHEQUE_NUMBER_LENGTH = 279;

public static final int INVALID_25_MINLENGTH_ADDRS = 282;
public static final int INVALID_25_MINLENGTH_ADDRS_New = 283;
public static final int INVALID_25_MINLENGTH_ADDRS_Old_Office = 284;
public static final int INVALID_25_MINLENGTH_ADDRS_New_Office = 285;
public static final int INVALID_10_MINLENGTH_New_ContactNo = 286;
public static final int SPECIAL_CHAR_NOT_ALLOWED_FOR_SETLMNTNO = 287;
public static final int DEMAT_SETTLEMENT_NO_MANDATORY = 288;

public static final int INVALID_PAST_DATE_5DAYS = 289;
public static final int EMAIL_IDS_NOT_SAME = 290;

/*For ISafe Portwise Integration-Start*/

public static final int INVALID_PIN_INPUT = 294;
public static final int SMS_URL_NOT_SENT = 295;
public static final int USER_STATUS_MISMATCH = 296;
public static final int ISAFE_OTP_NOT_ENTERED = 297;
public static final int INVALID_OTP_ENTERED = 298;
public static final int PIN_CHANGE_SUCCESS = 299;
public static final int PIN_CHANGE_FAILED = 301;
public static final int UNABLE_TO_DELETE_PWUD_RECORD = 302;
public static final int PWUD_SELECT_FAILED = 303;
public static final int USER_NOT_AUTHENTICATED = 304;
public static final int URL_SUCCESSFULLY_SENT = 305;
public static final int PORTWISE_SUCCESSFULLY_ACTIVATED = 306;
public static final int PORTWISE_ACTIVATION_FAILED = 307;
public static final int NOT_REGISTERED_FOR_ISAFE_OTP = 308;
public static final int PWUD_DELETE_SUCCESSFULL = 508;
public static final int USER_NOT_REGISTERED_ADMIN = 509;

//Added for Validations Check in Force Contact

public static final int INVALID_CITY = 310;
public static final int INVALID_STATE = 311;

public static final int NRI_STATE_VALIDATION=841;
public static final int NRI_CITY_VALIDATION=842;
public static final int ONLY_ALPHABETS_ALLOWED_FOR_NRICITY = 843;
public static final int ONLY_ALPHABETS_ALLOWED_FOR_NRISTATE = 844;



public static final int ONLY_ALPHABETS_ALLOWED_FOR_SALUTATION = 313;
public static final int ONLY_ALPHABETS_ALLOWED_FOR_CITY = 314;
public static final int ONLY_ALPHABETS_ALLOWED_FOR_STATE = 315;
public static final int INVALID_CHEQUE_NUMBER_OR_DATE =318;
public static final int ACCOUNT_CONTACT_BLOCKED=677;
public static final int INVALID_ADDRESS=715;
public static final int SELECT_ANOTHER_ACCOUNT=690;
public static final int NO_ACCOUNTS_PENDING_UPDATION=691;
public static final int NAME_VALIDATION=716;
public static final int CONTAINS_ONLY_NUMBERS=698;
public static final int INVALID_SPECIAL_CHARACTERS=697;
public static final int INVALID_ADDRESSLINE1=694;
public static final int INVALID_ADDRESSLINE2=695;
public static final int INVALID_ADDRESSLINE3=696;
public static final int INVALID_EMAIL_ID_LENGTH=693;
public static final int INVALID_PIN_LENGTH_NRI=689;
public static final int INVALID_PAN_NUMBER = 688;
public static final int INVALID_REGISTERED_MOBILE_NUMBER=835;
public static final int INVALID_NRI_REGISTERED_MOBILE_NUMBER=1110;
public static final int INVALID_REGISTERED_MOBILE_NUMBER_LENGTH=692;
public static final int INVALID_REGISTERED_NRI_MOBILE_NUMBER_LENGTH=6921;
public static final int ONLY_ALPHABETS_FOR_FIRST_FIVE=711;
public static final int ONLY_NUMBERS_FOR_NEXT_FOUR=712;
public static final int FOURTH_ALBHABET=713;
public static final int ONLY_ALPHABETS_FOR_LASTVALUE=714;
public static final int INVALID_MINUMUM_PIN_LENGTH_NRI=838;


public static final int INVALID_CONTACT_EMAIL_ID = 1744;
public static final int INVALID_CONTACT_PIN =1740;
public static final int INVALID_CONTACT_CITY=742;
public static final int INVALID_CONTACT_STATE=743;


public static final int CHECK_ADDRESS = 819;
public static final int CHECK_CITY = 820;
public static final int CHECK_STATE=821;
public static final int CHECK_BRANCH=822;
public static final int CHECK_PIN=823;
public static final int CHECK_PAN = 824;
public static final int CHECK_EMAIL = 831;
public static final int CHECK_PHONE=832;
public static final int PLEASE_SELECT_VALID_ACCOUNT_TYPE = 833;
public static final int CHECK_SALUTATION = 834;
public static final int ACCOUNT_CONTACT_UPDATE_ALL_SUCCESS = 836;
public static final int ACCOUNT_CONTACT_UPDATE_FINAL = 837;
public static final int CHECK_COUNTRY=839;
//Added for Validations Check in Force Contact end


//Added for SRs which are pointing to DPSECURE and CTL
public static final int SERVICE_REQUEST_SUCCESS_MESSAGE_DPSECURE = 291;
public static final int SERVICE_REQUEST_SUCCESS_MESSAGE_CTL = 292;

//Added as the fix for the bank issue:129
public static final int SPECIAL_CHAR_AND_SPACES_NOT_ALLOWED_IN_BILLER_NICK_NAME = 319;
public static final int DUPLICATE_PAYMENT_MESSAGE = 327;

public static final int GENERATE_MMID_SUCCESS = 322;
public static final int RETRIEVE_MMID_FAIL =320;

//Added for DTH SubscriberId validation fix

public static final int INVALID_SUSCRIBER_ID = 293;

public static final int DEMAT_BILL_NUMBER_MANDATORY = 330;
public static final int IMPROPER_CREDITCRDDATE_LENGTH = 339;
public static final int IMPROPER_MONTH = 340;

public static final int IMPROPER_CREDITCRDYEAR = 341;

//Added as fix for bank issues
public static final int MOBILE_NUMBER_SHOULD_NOT_START_WITH_ZERO = 342;

public static final int ICICI_CREDIT_CARD_NUMBER = 343;
public static final int NO_OPEN_SRS_EXIST_FOR_USER = 335;

public static final int INVALID_ENGCHASVEH_MINLENGTH=10310;//(CustomEBankingErrorCodes.java)
public static final int INVALID_ENGINE_MINLENGTH=10311;//(CustomEBankingErrorCodes.java)
public static final int INVALID_CHASIS_MINLENGTH=10312;//(CustomEBankingErrorCodes.java)
public static final int INVALID_VEHICLE_MINLENGTH=10313;//(CustomEBankingErrorCodes.java)
//added for set maximum limit for Virtual Credit Card
public static final int INVALID_CC_RESET_LIMIT=10315;

public static final int INVALID_MAX_Lombard_Policy_number=1524;
public static final int INVALID_MIN_Lombard_Policy_number=1523;

public static final int INVALID_PAST_DATE_10DAYS = 345;
//Added for CIFDOWNLOAD - START
public static final int BACK_DATED_FILE_REQ_MAND = 346;
public static final int FROM_DATE_TO_DATE_MAND = 347;
public static final int LAST_DWNLD_TIME_LIE_BTW_FROM_TO_DATES = 348;
public static final int FROM_DATE_GREATER_THAN_TO_DATE = 349;
//Added for CIFDOWNLOAD - END

//Added for ATMB validation
public static final int NO_RECORD_IN_ATMB = 274;
public static final int PINCODE_IS_MANDATORY = 266;

public static final int CC_DETAILS_NOT_AVAILABLE = 350;
public static final int INVALID_POLICY_NUMBER=10314;

// Added for Bank Issue Observation : 25
public static final int  MMID_SHOULD_BE_NUMERIC = 359;
public static final int  INVALID_MMID_MOBILE_NUMBER = 360;
public static final int MMID_MOBILE_NUMBER_SHOULD_NOT_START_WITH_ZERO = 361;

public static final int BILLER_STATE_MANDATORY=352;
public static final int CITY_ZIP_COMBINATION_REQ = 353;
public static final int SEND_ZIP_SHOULDBE_NUMERIC =354;
public static final int SEND_INVALID_PINCODE =355;
public static final int REC_ZIP_SHOULDBE_NUMERIC = 356;
public static final int REC_INVALID_PINCODE =358;


public static final int DUPLICATE_CHANNEL_USER_ID=357;
public static final int LENGTH_OF_FIELD_NAME_SHOULD_BE_WITHIN_MINIMUM_AND_MAXIMUM_LENGTH=362;
public static final int CONFIRM_MSG_USRFRAUD_BEFORE_PROCESSING = 364;

// Added by Shyamamanjari
public static final int TXN_AMOUNT_GREATER_THAN_BALANCE=363;

public static final int INVALID_ACCOUNT_NUMBER_LENGTH = 365;
public static final int FIRSTTHREE_DIGITS_OF_ACCTNO_119_4THDIGIT_HYPHEN = 366;
public static final int INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC = 367;

//Added for biller amount field validations
public static final int AMOUNT_SHD_NOT_CONTAIN_SPECIAL_CHARS_OR_NUMBERS = 373;
public static final int AMOUNT_SHOULD_BE_GREATER_THAN_ZERO = 374;
public static final int ONLY_TWO_DIGITS_ALLOWED_AFTER_DECIMAL_POINT = 375;

public static final int INVALID_MOBILE_NO_START = 376;

public static final int INVALID_READING_DAY_VALUE = 379;

public static final int SPECIAL_CHARS_SPACES_NOT_ALLOWED_IN_PREMIUM_AMOUNT = 381;
public static final int IDEA_CELLULAR_ACC_START_IMPROPER = 382;
public static final int INVALID_BILL_NAME = 383;

//Added for Resend OTP flow
public static final int NICK_NAME_INVALID = 384;

//Added for Credit Card Handpick Reward Points
public static final int INSUFFICIENT_REWARD_POINTS=370;
//Added for iWish Manage Goals
public static final int NO_GOALS_RECORD_PRESENT = 386;

public static final int INVALID_ACCOUNT_NO_START = 387;
public static final int INVALID_POLICY_NUMBER_BILLER = 388;
public static final int INVALID_ACCOUNT_NO = 389;

public static final int REDEMPTION_SUCCESSFULL=390;
public static final int REDEMPTION_FAIL = 391;
//Added for Bank Issue : 324645
public static final int INVALID_MOBILE_NUMBER_LENGTH = 392;

public static final int PRIMARY_ACCOUNT_PRFERENCE_SET = 393;

public static final int INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_SPACE = 401;
//Added for Hand Pick Reward points
public static final int NO_ITEM_SELECTED =450 ;

//Added for CR 35
public static final int INVALID_DUE_DATE =402 ;

//Added for 7th Nov tab. S No 45, 259 and 274

public static final int BILLER_IMPROPER_DOB = 451;

//Added for terms and conditions check in SR - CR 36
public static final int TNC_CHECK = 461;

//Added for CR 88
public static final int BILLER_POLICY_NUM_INVALID = 453;

public static final int INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_FWDSLASH = 454;

// Added for CR 81
public static final int CA_NUMBER_ALL_DIGITS_ZERO = 456;

//Added for Loan Profile Info issue
public static final int NO_LN_AMORTIZATION_DETAILS = 457;

public static final int MIN_LENGTH_FOR_NICKNAME_IS_3 = 458;
public static final int MAX_LENGTH_FOR_NICKNAME_IS_12 = 459;

public static final int ENTER_FIRST_4_DIGITS = 465;

// Added for Admin SSO
public static final int MIGRATED_USER = 901;
public static final int MIGRATED_NON_USER = 324;
public static final int MANDATORY_MIGRATION = 325;

public static final int INVALID_FIELD_VALUE_SHOULD_CONTAIN_ALPHABETS = 403;
//Added for Payee format change done for VISA biller(ref ticket no: 329752)
public static final int CREDIT_CARD_NUMBER_MATCH_INVALID = 467;

public static final int UNIQUE_REG_NUM_NINTH_DIGIT_HYPHEN = 468;

// ADDED FOR OPERATIVE ACCOUNT ESTATEMENT BY EMAIL

public static final int INVALID_OPTION_SELECTED = 475;
public static final int INVALID_EMAILID_RECONFIRM_EMAILID = 476;
public static final int SUBSCRIBE_SUCCESS = 477;
public static final int SUBSCRIBE_UNSUCCESS = 478;
public static final int INVALID_REQUEST = 479;

// Added for Track Your Service Request - Ticket 329425
public static final int NO_OPEN_OR_CLOSED_SRS_FOUND = 480;

public static final int INVALID_AMOUNT_PPF = 107512;
//Added for issue id 330262
public static final int FUTURE_DATE_NOT_ALLOWED_FOR_FROMDATE = 483;
public static final int FUTURE_DATE_NOT_ALLOWED_FOR_TO_DATE = 484;

//added for mobile sync batch
public static final int MNHT_INSERTION_FAILED=309;
public static final int DULH_INSERTION_FAILED=321;

// Added for defect 329903
public static final int INVALID_TENURE_OF_DEPOSIT = 485;
public static final int INVALID_TENURE_OF_DEPOSIT_DAYS = 486;
public static final int INVALID_PHONE_NUMBER_LENGTH = 107516;

//Added for channel Id validations  332934 and 332936
public static final int CHANNEL_LENTH_LESS_THAN_FOUR=487;
public static final int CHANNEL_HAVING_SPL_CHARS=488;
// Added for defect 333056
public static final int IMVALID_COUNTRY_CODE = 107518;
public static final int IMVALID_LANDLINE_NUMBER = 107519;
public static final int MOBILE_NUMBER_BLANK = 107520;
// Added for defect 330966
public static final int USER_ID_CHANGED_SUCCESSFULLY=489;

public static final int FIELDVALUE_SHOULDBE_NUMERIC_COMMA_ALLOWED = 490;

public static final int SCHEDULE_PAYMENTDATE_SHOULD_NOTEXCEED_DUEDATE = 491;
public static final int INVALID_DISPATCH_NAME = 492;
public static final int INVALID_RECEIVER_NAME = 493;
public static final int BILLER_PAYEE_FORMAT_NOT_AVAIL = 494;

// Added for defect 336622
public static final int BLANK_RECIEVER_MOBILE = 495;
public static final int BLANK_RECIEVER_ADRESS = 496;
public static final int INVALID_RECIEVER_MOBILE = 497;

// Added for defect 333390
public static final int INVALID_ALT_CONTACT_NUM=525;

/* Added for TO 328141 START */
public static final int INVALID_PAYEE = 498;
/* Added for TO 328141 END */

/*Added for TO :334786*/
public static final int CTL_DOWN = 499;

public static final int REGISTER_MOBILE_BEFORE_ADD_PAYEE = 1527;
// Added For Form 15 G/H

public static final int NO_FIXED_DEPOSITS_LINKED = 1752;
public static final int CRITERIA_BLANK =  990105;
public static final int ALREADY_MARKED_FRAUD =  107793;
public static final int NOT_MARKED_FRAUD =  107794;

/*Added for PAN number validation with host record for service request - START*/
public static final int PAN_NOT_REGISTERED_IN_HOST = 30;
public static final int PAN_MISMATCH = 77;
public static final int PAN_FETCH_FAILED = 31;
/*Added for PAN number validation with host record for service request - END*/

/*Added for Mobile Number ticket*/
public static final int IMPROPER_MAX_MOBILE_LENGTH = 9994;

/*Added for the defect 338985*/
public static final int INVALID_DEALER_CONTACT_NUMBER = 4500;
public static final int DEALER_NUMBER_LENGTH_EXCEEDED = 4501;
public static final int DEALER_NUMBER_MIN_LENGTH = 4502;
/*Added for UWID batch*/
public static final int INSERTION_INTO_UWID_HAS_FAILED_ATMUPLD = 500;
public static final int ASSOCIATE_UWID_FIELD_HAS_FAILED_ATMUPLD = 501;

/*Added for 330266 and 330268*/
public static final int INVALID_NUMBER_OF_CHARS_AFTER_DECIMAL = 504;
public static final int FROM_AND_TO_AMOUNT_MANDATORY = 505;

/*Added for 339888*/
public static final int WIDGET_CAN_NOT_BE_REMOVED=526;


/*updated existing fields for portwise issues -start*/
public static final int USER_INTEGRATION_CREATION_FAILED = 527;
public static final int OPERATING_SYSTEM_NOT_SELECTED = 528;
public static final int PIN_NOT_ENTERED = 529;

/*updated existing fields for portwise issues -end*/

/*Added for the defect 340092*/
public static final int ENTER_VALID_EMAILID=555;

/*Added for the defect Lomabard Insurance*/
public static final int AUTH_CHK=4508;
/*Added for the defect 341126 START*/
public static final int NO_PAYEES_FOR_CRITERIA=4509;
/*Added for the defect 341126 END*/

/*Added for 341470*/
public static final int WIDGET_CAN_NOT_BE_ADDED=530;

/*Added for 341359*/
public static final int INVALID_FIELD_VALUE_ONLY_ALPHABET_SPACE = 507;
/*Added for 341345 */
public static final int INVALID_APPLICATION_NUMBER=558;

public static final int INVALID_CNTRY_CODE= 560;
public static final int CC_NO_TXN_HISTORY= 563;
public static final int PRI_ACCOUNT_NUMBER_BLANK= 564;
public static final int HOST_DOWN= 565;
/*Added for 330300 and 330299*/
public static final int CREDIT_GIFT_AMT_VAL=991000;

/*added for CR 96 and 97*/
public static final int FIELD_DOESNOT_CONTAIN_SPECIAL_CHARACTER = 990102;
/*added for CR111*/
public static final int MAX_LENGTH_CONTACTNUMBER = 991004;

public static final int GEN_ONLINEPASSWORD_OTP_EXPIRED = 566;

/*Added for TO 346940 start*/
public static final int IMPS_MOBILE_NUMBER_LENGTH_INVALID=580;
public static final int IMPS_MOBILE_NUMBER_CONTAIN_ALPHABET_SPECIAL_CHARACTER=581;
/*Added for TO 346940 end*/

/*Added for TO 332113 start*/
public static final int HOT_PAYMENT_SUCCESSFUL=990105;
public static final int TXN_DATE_RESCHEDULED_SUCCESSFULLY=990106;
/*Added for TO 332113 end*/
/*Added for TO 341359 start*/
public static final int CREDIT_CARD_NUMBERS_NOT_MATCH=583;
/*Added for TO 341359 end*/

/*Added for IMPS MMID start*/
public static final int IMPS_MMID_SHOULD_BE_NUMERIC=584;
public static final int IMPS_MMID_NUMBER_LENGTH_INVALID=585;
/*Added for IMPS MMID start*/
// for SR link loan account start
public static final int INVALID_LOAN_ACCOUNT = 991008;
// for SR link loan account end
/*Added for TO 327889 start */
public static final int LENGTH_LESS_THAN_MINIMUM_LENGTH = 546;
public static final int FIELD_SHOULD_CONTAIN_ONLY_NUMBERS_NO_SPECIAL_CHARACTERS=547;
/*Added for TO 327889 end */
/*Added for Contact Number start */
public static final int CONTACT_NUMBER_MINIMUM_LENGTH = 33603;
public static final int CONTACT_NUMBER_ONLY_NUMERIC_ALLOWED=33602;
public static final int CONTACT_NUMBER_CANNOT_BE_NEGATIVE_OR_ZERO=33604;
/*Added for Contact Number end */

public static final int NO_MATCHING_RECS_FOR_TRACKING = 588;

/*Added for admin verify url usecase Start */
public static final int BILLER_ID_SHOULD_BE_NUMERIC = 569;
/*Added for admin verify url usecase End*/
public static final int INVALID_MOTHER_MAIDEN_NAME= 562;
public static final int INVALID_PIN_CODE = 582;


/* Add for SR AGC Start**/
public static final int AGC_LENGTH_CREDITCARD = 991005;
public static final int AGC_START_CREDITCARD = 991006;
/* Add for SR AGC End**/
/* Add for Consolidated Investment Summary Start**/
public static final int CONSOLIDATED_INVESTMENT_NULL = 435;
/* Add for Consolidated Investment Summary End**/
/*Added for Status on AdditionDeletion of MandateNominee Started*/
public static final int SR_SMN_NMADRV=991039;
public static final int SR_SMN_CRA_NAM=991040;
public static final int SR_SMN_BILL_NO=991041;
/*Added for Status on AddtionDeletion of MandateNominee Ended*/
/*Added by China team: Begins*/
/*Added for new sr BNU started*/
public static final int INVALID_BNU_BILLERNAME = 991011;
public static final int INVALID_BNU_BILLNUMBER = 991012;
public static final int INVALID_BNU_DUEDATE = 991013;
public static final int INVALID_BNU_REGDATE1 = 991016;
public static final int INVALID_BNU_REGDATE2 = 991017;
/*Added for new sr BNU end*/
/*Added for new sr SNR started*/
public static final int INVALID_SNR_STMT = 991046;
/*Added for new sr SNR end*/
/*Added for new sr DNC started*/
public static final int INVALID_DNC_CAO = 991047;
/*Added for new sr DNC end*/
/*Added for new sr RBS started*/
public static final int INVALID_RBS_CUSTID = 991018;
public static final int INVALID_RBS_TODATE = 991073;
public static final int INVALID_RBS_FROMDATE1 = 991071;
public static final int INVALID_RBS_FROMDATE2 = 991072;
/*Added for new sr RBS started*/
public static final int INVALID_IFT_BACCNUMBER = 991024;
/*Added for new sr Information on Payee Details started*/
public static final int SR_IPD_TRAN_DATE=991037;
public static final int SR_IPD_VALID_CHQ_NO=991009;
public static final int SR_IPD_NOT_EN_CHQ_NO=991010;
public static final int SR_IPD_VAL_AMT=991036;
public static final int SR_IPD_VAL_DESC=993146;
/*added for new sr Information on Payee Details ended*/
/*Added for Status on AdditionDeletion of MandateNominee Started*/
/*Added for AMT Card on Mandate started*/
public static final int SR_FRM_NAM_MANDATE=991026;
public static final int SR_FRM_CITY=991027;
public static final int SR_FRM_STATE=991028;
public static final int SR_FRM_PINCOD=991029;
public static final int SR_FRM_CONTACT_NO=991030;
/*Added for AMT Card on Mandate Ended*/

// ADD FOR Request_FAI_UNSEC_NRI_LI_N_CashDepositedNC
//To revert public static final int SR_IPD_VALID_CHQ_AM=991030;
public static final int SR_IPD_VALID_DW_CD=991031;
public static final int SR_IPD_VALID_DR_BR=991032;
public static final int SR_IPD_VALID_PO_CD=991033;
public static final int SR_IPD_VALID_LO_AB=991050;
public static final int SR_IPD_VALID_CHQ_NON=991051;
public static final int SR_IPD_VALID_DR_BN=991052;
public static final int SR_IPD_VALID_CHQ_NOM=991053;
public static final int SR_IPD_VALID_CHQ_AMM=991054;
public static final int SR_CDA_VALID_placeO_fCD=991055;
public static final int SR_CDA_VALID_Date_WCD=991056;

//Add for LCU SR Request_FAI_NRI_LI_LinkingofCC_SBAC
public static final int IMPROPER_LCU_CREDITCRDNO = 991025;

/* added for SR(Reissue of Lost ATM/DebitCard) */
public static final int INVALID_CUSTOMER_NAME_LENGTH = 991060;

/* added for SR(Demand Draft Request Form) */
public static final int INVALID_AMOUNT_OF_DD = 991061;
public static final int INVALID_DD_PAYABLE_AT = 991062;
public static final int INVALID_BENEFICIARY_NAME = 991063;
public static final int INVALID_PINCODE = 991064;
public static final int INVALID_PHONE_NUMBER = 991065;

/* added for SR(Status on Opening of Fixed Deposit) */
public static final int DEPENDANCY_MODE_OF_DISPATCH = 993052;
public static final int DEPENDANCY_SR_NUMBER = 993053;
public static final int INVALID_SR_NUMBER = 993054;
public static final int INVALID_REQUEST_SUBMIT_DATE_2DAYS = 993055;
public static final int INVALID_REQUEST_SUBMIT_DATE_8DAYS = 993056;
public static final int INVALID_REQUEST_SUBMIT_DATE_15DAYS = 993057;
public static final int INVALID_REQUEST_SUBMIT_DATE_21DAYS = 993058;
public static final int ACCOUNT_STATUS_DORMANT = 993059;
public static final int ACCOUNT_BALANCE_ZERO = 993060;

/* added for SR(Status on Opening of Fixed Deposit) */
public static final int MANDATORY_SR_NUMBER = 991067;

//Add for CBN SR Request_FAI_UNSEC_NRI_LI_N_DelivrbleNotRecdChqBook
public static final int SR_CBN_CHEQUE_BOOK_APPLIED_DATE = 991044;
/*Added for Stop cheque Request started*/
public static final int SR_STC_RMK=991043;
public static final int SR_STC_CHQ=993161;
public static final int SR_STC_CHQ_DIG=993162;
/*Added for Stop cheque Request ended*/
public static final int SR_RSD_FLD_LENGTH=991066;
// ADD FOR Request_FAI_NRILI_InfonUpgradetoNRIEDGE
public static final int SR_IUE_VALID_NM_PA=991080;
public static final int SR_IUE_VALID_CON_NO=991081;

public static final int PCL_CUS_NAME_LENGTH = 991090;
public static final int PCL_PLATINUM_CARD_NUMBER_LENGTH = 991091;
public static final int PCL_PLATINUM_CARD_NUMBER_TYPE = 991092;
/*Added for Contact Number start */
public static final int IMPROPER_SAVING_ACCOUNT_NUMBER =993009;
/*Added for Contact Number end */
/*Added for RDR */
public static final int DB_ACCOUNT_NUMBER_ONLY_NUMERIC_ALLOWED = 993000;
public static final int DB_ACCOUNT_NUMBER_MINIMUM_LENGTH=993001;
public static final int IMPROPER_DB_ACCNT_NO=993002;
public static final int DD_ISSUE_DATE_INVALID_PAST_DATE_10DAYS = 993003;
public static final int IMPROPER_BENEFICIARYNAME_MIN_LENGTH = 993004;
public static final int IMPROPER_BENEFICIARYADDRESS_MIN_LENGTH =993005;
public static final int IMPROPER_BENEFICIARYADDRESS_ONLY_ALPHABETS_ALLOWED =993006;
public static final int IMPROPER_BENEFICIARYCITY_ONLY_ALPHABETS_ALLOWED =993007;
public static final int IMPROPER_BENEFICIARYCITY_MIN_LENGTH =993008;
/*Added for RDR */
/* add for SR RWT start*/
public static final int RWT_TOBE_CLOSEDON_MANDATORY = 991075;
public static final int RWT_Repatriation_TOBECLOSE=991019;
public static final int RWT_FD_ACCOUNT=991058;
public static final int RWT_REPATRIATED_AMOUNT=993035;
public static final int RWT_FD_ACCOUNT_MAX_LENGTH=991077;
public static final int RWT_CONFIRM_MESSAGE=991086;
/* add for SR RWT end*/
/* add for SR PAN start*/
public static final int INVALID_DATE_BIRTH_ON_PAN = 991049;
public static final int PAN_INVALID_PAN_NUM = 991048;
/* add for SR PAN end*/

public static final int INVALID_IFT_BBANKNAME = 991059;
public static final int INVALID_IFT_AMTTRAN =991067;
public static final int INVALID_IFT_AmtTranDate = 993107;

public static final int INVALID_OAA_BRANCH = 993106;
public static final int INVALID_RCP_CARDHOLDERNAME = 991045;

public static final int RST_INVALID_SAVINGACCT_PRODUCT_CATEGORY = 991078 ;
public static final int INVALID_RST_SBACCRYPE = 991079;
public static final int INVALID_RST_Amount1 = 993028;
public static final int INVALID_RST_Amount2 = 993027;
public static final int INVALID_RST_Amount3 = 993026;
public static final int INVALID_RST_Amount4 = 993025;

public static final int INVALID_IBP_BILLERNAME = 991074;
public static final int INVALID_IBP_AMOUNT = 993108;
public static final int INVALID_IBP_PAYMENTDATE = 993096;
public static final int INVALID_IBP_PAYMENTID =993029;


public static final int INVALID_ORD_AMOUNT = 993010;
public static final int INVALID_ORD_TENUREYEAR = 993011;
public static final int INVALID_ORD_TENUREMONTH = 993012;
public static final int INVALID_RSD_AMTFOREIGNCCY = 993065;
public static final int INVALID_RSD_DDAMTINR = 993066;
/*Added for LAU start*/



/*Added for LAU start*/


public static final int INVALID_CFR_FDNUMBER = 993013;
public static final int INVALID_CFR_CLOSURETYPE = 993014;
public static final int INVALID_CFR_CLOSUREAMOUNT = 993015;
public static final int INVALID_CFR_SAVINGACOUNT = 993016;
public static final int INVALID_CFR_REQUEST = 993017;
public static final int INVALID_ORD_PAYID = 993018;
public static final int INVALID_BNU_AMOUNT = 993019;
/*Added for TCR start*/
public static final int INVALID_EARLIER_SR_OR_CASE_ID_NO = 993093;
public static final int INVALID_EARLIER_SR_OR_CASE_ID_LENGTH = 993094;
/*Added for TCR end*/

/*Added for OSD start*/
public static final int ACCT_BAL_ZERO_NEGATIVE_FOR_FD = 993110;
public static final int MINIMUM_FD_AMOUNT_ERROR = 993111;
public static final int MAXIMUM_FD_AMOUNT_ERROR = 993112;
public static final int AVAILABLE_BALANCE_INSUFFICIENT = 993113;
public static final int TENURE_DAYS_MANDATORY = 993114;
public static final int OSD_TYPE_OF_FD_MANDATORY = 994017;
/*Added for OSD end*/
/*Added for 389315 start*/
public static final int MINIMUM_OSD_FD_AMOUNT_ERROR = 994036;
/*Added for 389315 end*/

/*Added for TYA start*/
public static final int TYA_BRANCH_MANDATORY = 993140;
/*Added for TYA end*/

/* Added for SFD by China team june xiong: Begins*/
public static final int TENURE_YEARS_MANDATORY = 993118;
public static final int FCNR_TENURE_YEARS_MIN = 993119;
public static final int FCNR_TENURE_YEARS_MAX = 993120;
public static final int NRO_TENURE_YEARS_MIN = 993121;
public static final int NRO_TENURE_YEARS_MAX = 993122;
public static final int MINIMUM_FCNR_AMOUNT_ERROR = 993128;
public static final int CURRENCY_YEARS_MANDATORY = 993130;
public static final int DEPOSIT_AMOUNT_BLANK = 993166;
/* Added for SFD by China team june xiong: End*/
//Added for CR 143 start
public static final int TOBE_RENEWED_ON_POPULATOR_ERR = 993133;
public static final int TOBE_RENEWED_ON_BLANK = 993129;
//Added for CR 143 end
/*Added by China team: Ends*/
/*Added for CR 145*/
public static final int IS_PPF_EEC_ACCT_NO = 594;
public static final int IS_PPF_EEC_HOT_TXNS = 586;
public static final int IS_PPF_EEC_SCHD_TXNS = 587;


public static final int LIMIT_UPDATED_SUCCESSFULLY= 1526;

//Added for SMO TO's

public static final int SEND_REC_CITY_MANDATORY = 589;
public static final int SEND_REC_ADDR_MANDATORY = 590;
public static final int SEND_REC_NAME_MANDATORY = 591;
public static final int SEND_REC_STATE_MANDATORY = 592;
public static final int SEND_REC_ZIP_MANDATORY = 441 ;

public static final int SEND_REC_INVALID_PINCODE = 699;
public static final int SEND_REC_INVALID_PINCODE_LENGTH = 799;

/*added for to id 329910 start*/
public static final int IMPS_VISIBILTY_CHECK = 593;
/*added for to id 329910 end*/

// Added for TO 333034
public static final int INVALID_MOB_NUM_MTR = 597;


/*Added for NRI SR status on address change start*/
public static final int DATES_WITHIN_8DAYS = 990001;
public static final int DATES_WITHIN_3MONTHS =990002;
public static final int INVALID_IBUSER_ID = 990180;

/*Added for NRI SR status on address change end*/

/*Added for NRI SR Status of cheque sent to NRI Services start*/
public static final int DATES_AFTER_11DAYS = 990004;
public static final int BANK_NAME_MIN_LEN_EXTEND = 990005;
public static final int INVALID_CHQ_NUMBER = 990006;
public static final int CHQ_SNET_NOT_BEFORE_TODAY = 990007;
public static final int INVALID_CHQ_AMT = 990008;
public static final int INVALID_COURIER_POST_NAME = 990009;
public static final int INVALID_BILL_NO = 990010;
public static final int INVALID_CHQ_AMT_RANGE = 990011;
public static final int DATES_AFTER_18DAYS = 990012;
public static final int DATES_AFTER_5DAYS = 990013;
public static final int DATES_AFTER_3DAYS = 990014;
public static final int DATES_AFTER_8DAYS = 990015;
public static final int DATES_AFTER_21DAYS = 990016;
public static final int DATES_AFTER_15DAYS = 990017;
public static final int AWB_MAND = 990018;
public static final int COURIER_NAME_MAND = 990019;
/*Added for NRI SR Status of cheque sent to NRI Services end*/
public static final int DATES_BEFORE_TODAY = 990020;
public static final int SR_VALUE = 990040;
/*Added for LAU start*/
public static final int NOT_WITHIN_2DAYS = 990181;
public static final int NOT_WITHIN_8DAYS = 990182;
public static final int NOT_WITHIN_15DAYS = 990183;
public static final int MOD_IS_BLANK = 990184;
public static final int COURIER_POSTNAME_IS_BLANK = 990185;
public static final int INVALID_COURIER_POSTNAME = 993076;
public static final int BILL_NO_IS_INVALID = 990186;
public static final int EARLIER_SRNO_IS_BLANK = 990187;
public static final int INVALID_LINKED_ACCT = 990188;
public static final int INVALID_EARLIER_SRNO = 993061;
/*Added for LAU start*/
/*Added for Login clone id start*/

public static final int EXCEPTION_OCCURRED_DURING_CLDT_INSERTION = 107070;

/*Added for Login clone id end*/

/*Added for TO 353278 start*/
//   public static final int IMPS_MMT_SYSTEM_DOWN=620;
/*Added for TO 353278 end*/

/*Added for TO 353284 start*/
public static final int IMPS_AMOUNT_VALIDATION=107560;
public static final int AMT_IFSC_VALIDATION=107562;
public static final int AMT_IFSC_DECIMAL_VALIDATION=107563;
/*Added for TO 353284 end*/
/*Added for  IFSC start*/
public static final int IFSCNO_VALIDATION=107514;
public static final int ACT_IFSC_VALIDATION=107515;

/*Added for  IFSC start*/
//Added for FTA
public static final int TERM_CONDITION_LINK = 595;
public static final int EITHER_FORIEGN_INR = 599;
public static final int ONLY_ONE_FRGN_INR = 600;
public static final int VALID_RELATION = 603;
public static final int STUDENT_NAME_ID = 604;
public static final int CURRENCY_BANK_ROUTING = 612;
public static final int BANK_SWIFT_CODE = 615;
public static final int BENEFICIARY_CORRESPONDANT_SWIFT_CODE = 623;
public static final int MANDATORY_CHARGE_SCHEDULE = 601;
public static final int STUDENT_NAME_INVALID = 627;
public static final int FTA_BENEFICAIRY_NAME_INVALID = 629;
public static final int FTA_BENEFICAIRY_ADDRESS_INVALID = 995659;
public static final int FTA_BENEFICAIRY_ADD_MAND = 6608;
public static final int FTA_SOURCE_OF_FUNDS_MAND = 7777;
public static final int FTA_PURP_REM__MAND = 6602;
public static final int FTA_ALPHA_NUMERIC_VAL = 662;
public static final int FTA_ALPHA_NUMERIC_BANK_NAME_VAL = 664;
public static final int FTA_ALPHA_NUMERIC_BANK_SWIFT_VAL = 665;
public static final int FTA_ALPHA_NUMERIC_BANK_ROUTING_VAL = 669;
public static final int FTA_ALPHA_NUMERIC_CORRESPONDENT_VAL = 670;
public static final int FTA_ALPHA_ROUTING_CORRESPONDENT_VAL = 671;
public static final int FTA_ALPHA_SWIFT_CORRESPONDENT_VAL = 672;
public static final int BANK_CORRESPONDANT_SWIFT_CODE = 687;

/*Added for Address Change SR - Start*/
public static final int ACC_NOT_OLD_FOR_ADD_CHANGE = 619;
public static final int ACC_NOT_ACTIVE_FOR_ADD_CHANGE = 620;
public static final int ACC_NO_BAL_FOR_ADD_CHANGE = 621;
/*Added for Address Change SR - End*/

/*Added for SR TDS - Start*/
public static final int CUSTID_VALUE_SHOULDBE_NUMERIC = 630;
/*Added for SR TDS  - ends*/
/*Added for 349832*/
public static final int MAIL_BODY_CANNOT_HAVE_SPACES= 632;
/*Added for Apply for auto Invest Account - NRO Started*/
public static final int SR_AIA_VALID_FD_YE=991084;
public static final int SR_AIA_VALID_FD_MO=991085;
public static final int SR_AIA_VALID_MI_AM=991082;
public static final int SR_AIA_VALID_MI_BA=991083;
public static final int SR_AIA_VALID_AC_DORMAT=993062;
public static final int SR_AIA_VALID_AC_DEBIT=993069;
public static final int SR_AIA_VALID_AC_ZERO=993063;
public static final int SR_AIA_VALID_AC_SCH=993075;
public static final int SR_AIA_VALID_AC_MOP=993064;
public static final int SR_AIA_VALID_RNDAY=993078;
public static final int SR_AIA_VALID_FDDAY=993077;
/*Added for Apply for auto Invest Account - NRO Ended*/

/* added for UNR start*/
public static final int UNR_AGREE_SELECT = 993051;
public static final int UNR_SAVING_ACCT_INVALID_STATUS = 993070 ;
public static final int UNR_INVALID_SAVINGACCT_PRODUCT_CATEGORY= 993073;
public static final int UNR_INVALID_SAVINGACCT_BALANCE1 = 993074;
public static final int UNR_INVALID_SAVINGACCT_BALANCE2 = 991076;
public static final int UNR_SAVING_ACCT_MANDATORY = 993071;
/* added for UNR start*/

/*Added for RFW */
public static final int INVALID_STATE_NAME= 993036;
public static final int INVALID_BENEFICIARY_PHONE_NUMBER=993037;
public static final int INVALID_FD_ACCOUNT_NUMBER_ZERO_NEGATIVE=993038;
public static final int INVALID_FD_ACCOUNT_NUMBER_DEBIT_FREEZE=993039;
public static final int INVALID_FD_ACCOUNT_NUMBER_NRO=993040;
public static final int INVALID_FD_ACCOUNT_NUMBER_CLOSURE_OF_FD =993041;
/*Added for RFW */
/*Added for RDR */
public static final int INVALID_DD_ISSUE_DATE= 993042;
/*Added for RDR */
/* add for SR FRA start*/
public static final int VALID_CUSTERMER_NAME_ON_FRA = 993079;
public static final int ACCOUNT_TYPE_WITH_NRO_ON_FRA = 993080;
public static final int ACCOUNT_TYPE_WITH_NRE_ON_FRA = 991100;
public static final int INVALID_DATE_OF_EARLIER_REQUEST_ON_FRA = 991101;
/* add for SR FRA end*/

/*Added for NBR Debit Card Hotlisting ----Start*/
public static final int SERVICE_REQUEST_SUCCESS_MESSAGE_HOTLIST = 333;
public static final int DEBIT_CARD_BLOCKING_REASON =334 ;
public static final int UNIQUE_REFERENCE_NUMBER = 426;
/*Added for NBR Debit Card Hotlisting ----End*/

/*Added for alert send to mobile number and email id -Start*/

public static final int USERID_SEND_TO_EMAIL_ID = 635;
public static final int USERID_SEND_TO_MOBILE_NUM = 634;
/*Added for alert send to mobile number and email id -End*/

/*Added for CR - Status of bill payment ----Start*/
public static final int INVALID_PAYMENT_ID= 705;
/*Added for CR - Status of bill payment ----End*/

/*Added for Forgot Password - Start*/
public static final int INVALID_ACCOUNT_ID = 812;
public static final int ENTER_PIN = 801;
public static final int ENTER_CITY = 802;
public static final int ENTER_ADDR = 803;
public static final int ENTER_DOB = 804;
public static final int ENTER_VALID_DOB = 805;
public static final int ENTER_MAIDEN_NAME = 806;
public static final int ENTER_VALID_MAIDEN_NAME = 808;
public static final int ENTER_USER_ID = 807;
public static final int ENTER_VALID_USER_ID = 809;
public static final int ENTER_ACCOUNT_ID = 810;
public static final int ENTER_VALID_ACCOUNT_ID = 811;
public static final int ENTER_VALID_CITY = 813;
/*Added for Forgot Password - End*/
/*Added for ADN */
public static final int INVALID_NAME_TO_BE_ADDED_LENGTH= 993043;
/*Added for ADN */
/* Added for error messages from IMPS system start */
public static final int IMPS_MMT_INVALID_BENEFICIARY_MOBILE_NUMBER_MMID=638;
public static final int IMPS_MMT_AMOUNT_LIMIT_EXCEEDED=639;
public static final int IMPS_MMT_ACCOUNT_BLOCKED_FROZEN=640;
public static final int IMPS_MMT_NRE_ACCOUNT=641;
public static final int IMPS_MMT_ACCOUNT_CLOSED=642;
public static final int IMPS_MMT_LIMIT_EXCEEDED_FOR_MEMBER_BANK=643;
public static final int IMPS_MMT_INVALID_PAYMENT_REFERENCE=644;
public static final int IMPS_MMT_FUNCTIONALITY_NOT_SUPPORTED_BY_ISSUING_BANK=645;
public static final int IMPS_MMT_FUNCTIONALITY_NOT_SUPPORTED_BY_BENEFICIARY_BANK=646;
public static final int IMPS_MMT_INVALID_OTP=647;
public static final int IMPS_MMT_OTP_EXPIRED=648;
public static final int IMPS_MMT_ISSUER_NODE_OFFLINE=649;
public static final int IMPS_MMT_INVALID_REMITTER=650;
public static final int IMPS_MMT_INVALID_NBIN_IFSC_CODE_OF_BENEFICIARY=651;
public static final int IMPS_MMT_INVALID_MPIN=652;

public static final int IMPS_MMT_OTP_TRANSACTION_LIMIT_EXCEEDED=653;
public static final int IMPS_MMT_ISSUING_BANK_CBS_NODE_OFFLINE=654;
public static final int IMPS_MMT_DUPLICATE_TRANSMISSION=655;
public static final int IMPS_MMT_RECONCILE_ERROR=656;
public static final int IMPS_MMT_UNABLE_TO_PROCESS=657;
public static final int IMPS_MMT_HOST_UNREACHABLE=658;
/* Added for error messages from IMPS system end*/

/*Added for TO 353278 start*/
public static final int IMPS_MMT_SYSTEM_DOWN=659;
/*Added for TO 353278 end*/
/*Added for 349809*/
public static final int MAIL_BODY_CANNOT_BE_BLANK= 633;
/*Added for CR 57 - start*/
public static final int INVALID_PWD_RESET_3DAYS = 661;
public static final int UNIQUE_NO_INCORRECT = 673;
public static final int UNIQUE_NO_CANT_BE_GENERATED = 675;
public static final int UNIQUE_NO_NOT_GENERATED = 676;
public static final int INVALID_USER_ID = 678;
public static final int LOGIN_DISABLED_FOR_USER = 679;
public static final int ENTERED_UNIQUE_NO_INCORRECT = 680;
public static final int UNIQUE_NO_MANDATORY = 681;

/*Added for CR 57 - End*/

/*Added for Renewal of Term Deposit start*/
public static final int INVALID_MONTHS_TO_BE_RENEWED = 993104;
public static final int INVALID_DAYS_TO_BE_RENEWED = 993105;
public static final int MONTH_TO_BE_RENEWED_BLANK = 993105;
/*Added for Renewal of Term Deposit end*/
/*FDC*/
public static final int MODE_OF_DISPATCH_MANDANTORY =993081;
public static final int SR_NUM_MANDANTORY =993082;

//Added for RTC--start
public static final int INVALID_LENGTH_TO_FINANCIAL_YEAR = 993087;
public static final int SPECIAL_CHARACTER_MISSING_TO_FINANCIAL_YEAR = 993088;
public static final int CONTAINS_ONLY_NUMBER_TO_FINANCIAL_YEAR = 993089;
public static final int INVALID_CENTURY_TO_FINANCIAL_YEAR = 993090;
public static final int SEQUENCE_YEAR_TO_FINANCIAL_YEAR = 993091;
public static final int INVALID_DECADE_TO_FINANCIAL_YEAR = 993092;
public static final int RTC_CHECK = 993097;
public static final int PAN_NUMBER_NOT_UPDATED = 993095;
public static final int PAN_NUMBER_NO_UPDATED = 993098;
//Added for RTC --end

/*Added for LDAP - start*/
public static final int GENERIC_BUSINESS_ERROR = 814;
/*Added for LDAP - End*/

/*Added for grid card data entry validation start*/
public static final int GRID_CARD_VALUES_SHOULD_BE_NUMERIC=667;
public static final int GRID_CARD_VALUES_BLANK=668;
/*Added for grid card data entry validation end*/
/*Added for MayIHelp start*/
public static final int MAYIHELP_URL_NULL = 107081;
/*Added for MayIHelp end*/


/*Added for Personalize transaction limit Dropdown valdation START*/
public static final int PERSONALIZE_TXN_LIMIT_DROPDOWN_SHOULD_NOT_BE_EMPTY=979;
/*Added for Personalize transaction limit Dropdown valdation END*/

/*Added for CFD */
public static final int SR_CFD_ACCOUNT_MATURITYDATE= 993100;
public static final int SR_CFD_ACCOUNT_BALANCE= 993101;
public static final int SR_CFD_INVALID_Beneficiary_OF_PHONENO= 993102;
public static final int INVALID_PINCODE_ON_CFD= 993103;
public static final int INVALID_ACCOUNT_NUMBER_ON_CFD= 993116;
public static final int SR_CFD_AMT_MAX_DIGIT=994021;
public static final int SR_CFD_PH_NO=994022;
public static final int SR_CFD_AMT_NOT_NEG=994023;
/*Added for CFD */

/*Added for ROC */
public static final int INVALID_PINCODE_ON_ROC= 994000;
/*Added for ROC */

/* Added for Know your User ID start */
public static final int KYUID_INVALID_ACCOUNT_NUMBER = 993116;
public static final int KYUID_INVALID_EMAILID = 993117;
public static final int KYUID_ACCOUNT_NUMBER_MANDATORY = 686;
public static final int KYUID_MOBILE_NUMBER_COUNTRYCODE = 422;
public static final int KYUID_MOBILE_NUMBER_LENGHT = 423;
public static final int KYUID_MOBILE_NUMBER_VALIDCOUNTRYCODE = 424;
public static final int KYUID_MOBILE_NUMBER_NOT_REGISTERED = 421;
public static final int KYUID_MOBILE_NUMBER_DEOSNT_MATCH = 636;
public static final int KYUID_EMAILID_NOT_REGISTERED = 430;
public static final int KYUID_EMAILID_DOESNT_MATCH = 637;
/* Added for Know your User ID end */
/*Added for PDC */
public static final int IMPROPER_CUSTOMER_NAME_LENGTH= 993044;
/*Added for PDC */


/* Added for SMO TO's */
public static final int REC_NAME_SHOULDBE_ALPHABETS = 682;
public static final int REC_CITY_SHOULDBE_ALPHABETS = 683;
public static final int ADDR_LENGTH_SHOULDBE_GREATER_THAN_THREE = 818;
public static final int LENGTH_OF_NAME_SHOULDBE_GREATER_THAN_THREE = 817;

/* Added for CR 141 start */
public static final int REQUEST_TYPE = 706;
public static final int ATTACH_FILE = 707;
public static final int IMPROPER_FILE_CONTENTTYPE = 708;
public static final int MANDATORY_DOCUMENT_LIST = 709;
/* Added for CR 141 end */

/* Added for Message Center */
public static final int RESPONSE_NULL = 241;

//Added for CR 177//
public static final int UNABLE_TO_FETCH_LIST_OF_DEMAT_ACCOUNTS=685;
public static final int NO_DEMAT_ACCOUNTS_LINKED = 684;
//add by suma
public static final int SELECTED_ACCOUNT_DORMANT = 993109;
public static final int THERE_ARE_NO_PAYEE_REGISTERED_FOR_PAY_ANY_VISA_CREDIT_CARD = 993216;
public static final int FEEDBACK_DUPLICATE = 107565;
public static final int FEEDBACK_FAILURE = 107566;
public static final int FEEDBACK_MANDATORY = 107567;
public static final int FEEDBACK_SUCCESS = 107564;
/*Added for Privilege Banking- End*/
//add for check in CCA
public static final int TYPE_OF_FD_MANDATORY = 993116;
public static final int INVALID_ADDR_LINE_1 =993083;
public static final int INVALID_ADDR_LINE_2=993084;
public static final int INVALID_PIN_CODE_LENGTH=993085;
public static final int INVALID_NEW_PIN_CODE=993123;
public static final int ACCOUNT_DORMENT=993124;
public static final int ACCOUNT_LESS_THAN_SIX_MONTH=993125;

public static final int PWUD_TABLE_OPERATOR_EXCEPTION = 993126;
public static final int PORTWISE_REGISTERED_USER = 993127;

/* Added for UEN Date Validation */
public static final int INVALID_DATE_RANGE_SELECTED= 991097;

/* Added for CR 149 */
public static final int GTP_FACILTY_ERROR=730;
public static final int GTP_FACILTY_TEMP_ERROR=731;
public static final int GTP_FACILTY_ALERT_ALREADY_SENT=732;
public static final int GTP_PASSCODE_EXPIRED=733;
public static final int GTP_INVALID_PASSCODE=734;
public static final int GTP_PASSCODE_NOT_GENERATED=735;
public static final int PASSCODE_UPDATE_FAILED=736;
public static final int GTP_DEBITCARD_STATUS_INACTIVE=737;
public static final int INVALID_PASSCODE_LENGTH=738;
public static final int INVALID_PASSCODE_ATTEMPT=740;
public static final int NO_LOGIN_PWD_HISTORY=780;
public static final int NO_TRANSACTION_PWD_HISTORY=781;
public static final int GTP_DEBITCARD_NOTLINKED_TO_ACCOUNT=741;
public static final int INVALID_USERID=794;
public static final int USERID_FACILITY_ENABLED=795;
public static final int USERID_FACILITY_ALREADY_ENABLED=796;
public static final int USERID_FACILITY_DISABLED=797;
public static final int USERID_FACILITY_ALREADY_DISABLED=798;
public static final int LP_FACILITY_ENABLED=995709;
public static final int LP_FACILITY_DISABLED=995710;
public static final int LP_FACILITY_ALREADY_ENABLED=995703;
public static final int LP_FACILITY_ALREADY_DISABLED=995704;
public static final int PGF_FACILITY_ENABLED=995705;
public static final int PGF_FACILITY_DISABLED=995706;
public static final int PGF_FACILITY_ALREADY_ENABLED=995707;
public static final int PGF_FACILITY_ALREADY_DISABLED=995708;


/* Added for Defect 355850 SMO start */
public static final int ZIP_CODE_CHK = 440;
/* Added for Defect 355850 SMO end */

/* Added for TO id: 358544 start */
public static final int SUBSCRIBER_ID_BLANK = 993225;
/* Added for TO id: 358544 end */

/* Added for Open PPF by Mirunaline_S: start */
public static final int NO_SB_ACCNT_LINKED = 993217;
public static final int PPF_AMT_VAL = 993218;
public static final int SERIAL_NO_ERR = 993219;
public static final int PAN_NO_FETCH_ERR=993220;
public static final int PPF_AMT_VAL2=993221;
public static final int PANNO_MANDATORY = 993224;
public static final int MOBNO_MANDATORY = 993228;
public static final int PPF_TRAN_REM_VAL = 993237;
public static final int ENTER_CORRECT_PAN = 993238;

/* Added for Open PPF by Mirunaline_S: end */


//Added for SMO TO
public static final int AMT_IN_MUTLIPLES_OF_HUNDRED = 442 ;
/*Added for CR Query on non receipt of Mobile alerts */
public static final int MOBILE_NOT_REGISTERED_FOR_ALERTS=700;
public static final int MOBILE_REGISTERED_FOR_ALERTS=701;
public static final int MOBILE_NUMBER_NOT_REGISTERED=703;
/*Added for CR Query on non receipt of Mobile alerts */

/* Added for Defect 355856(SMO landing page) start */
public static final int AMNT_FIELD_BLANK= 445;
public static final int INIT_ACCNT_FIELD_BLANK= 446;
/* Added for Defect 355856(SMO landing page) SMO end */

/* Added for Manage Mandates - start */
public static final int NO_RECORDS_FOUND = 107070;
public static final int MANDATORY_FIELDS_CANNOT_BE_BLANK_MAND_START_DATE = 107071;
public static final int MANDATE_REGISTRATION_FAILURE = 107072;
public static final int MANDATE_DEREGISTERED_SUCCESS=825;
public static final int MANDATE_DELETE_SUCCESS=826;
public static final int MANDATE_DELETE_FAILURE=827;
public static final int BENEFICIARY_ID_MANDATORY_MANDATE=107073;
/* Added for Manage Mandates - end */

/*Added for the defect 339391*/
public static final int INVALID_AMOUNT_OF_SALARY_LENGTH=556;
/* Added for biller Id validation*/
public static final int INVALID_SHOPPING_MALL_ID= 908;
/* Added for TO:362860,362299 */
public static final int BILLER_ID_LENGTH= 909;
public static final int CHECK_YN_FLAG= 907;

//Added for Receive Funds
public static final int INVALID_CREDIT_DATE=943;
public static final int INVALID_TRANSACTION_AMOUNT= 721;
public static final int INVALID_NO_OF_INSTALLMENTS= 722;
public static final int INVALID_AMOUNT_RF=123456;

/*Added for forgot password issue - 355456 : Start*/
public static final int ENTER_COUNTRY = 815;
public static final int ENTER_VALID_COUNTRY = 816;
/*Added for forgot password issue - 355456 : End*/

//Added for Mandate Deregister
public static final int MANDATE_DEREGISTRATION_FAILURE = 102235;
// added for 361047
public static final int LESS_THAN_3 = 993141;

//Added by neha_kerkar for 341113
public static final int LOGIN_PWD_CHANGED_SUCCESS = 1528;
public static final int TRANSACTION_PWD_CHANGED_SUCCESS = 1529;
public static final int INVALID_RSD_CCYAMT = 993139;

/*Added for 361618 */
public static final int SR_COURIER_POST_NAME_LENGTH = 993144;
/*Added for 361618 */

/*Added for 361921 */
public static final int SUBSCRIBER_ID_LENGTH = 107801;
/*Added for 361921 */
/*Added for 361914 */
public static final int NEGATIVE_AMOUNT_ENTERED = 100075;
/*Added for 361914 */

/*Added for RDR */
public static final int IMPROPER_DEMAND_DRAFT_AMOUNT= 993045;
/*Added for RDR */


//Added for isafe pin validation
public static final int SPECIAL_CHARACTERS_NOT_ALLOWED_IN_PIN = 1866;
//Added for isafe pin validation

//Added for OPEN PPF by Mirunaline_S and Soumya_Shivam
public static final int NEG_MOBNO = 993231;
public static final int INVALID_MOBNO = 993230;
public static final int PANNO_ALPHA1 = 993232;
public static final int PANNO_ALPHA2 = 993233;
public static final int PANNO_ALPHA3 = 993234;
public static final int PANNO_NUMERIC = 993235;
public static final int PANNO_ALPHA4 = 993236;
public static final int INVALID_PANNO = 993239;

/*Added for RDR */
public static final int BENEFICIARY_NAME_MANDATORY=993046;
public static final int BENEFICIARY_CONTACT_NUMBER_MANDATORY=993047;
/*Added for RDR */

/*Added for shopping mall payment start*/
public static final int SHOPPINGMALL_INITIATOR_ACCOUNT_NUMBER_MANDATORY= 828;
/*Added for shopping mall payment end*/
public static final int INVALID_DDN_NUMLENTH = 993145;
/*Added for Tax Payment Start*/
public static final int CHALLAN_NUMERIC=744;
public static final int DATE_MORE_MONTHS=745;
/*Added for Tax Payment End*/
/*Added for Cheque book request Starts*/
public static final int CBR_REQUEST_MESSAGE_AFTER_SUCCESS= 10500;
/*Added for Cheque book request Ends*/

/*Added for Submit NRE proof for INR credit to NRE account
START*/
public static final int CUSTOMER_NAME_NUMERIC = 991068;
public static final int CUSTOMER_NAME_DIGIT = 990069;
public static final int NPF_ATTACH_FILE = 990070;
public static final int NPF_IMPROPER_FILE_CONTENTTYPE = 990071;
public static final int NPF_BRANCH_MANDATORY = 990072;
/*Added for Submit NRE proof for INR credit to NRE account
END*/

/*Added for USRDTL - START*/
public static final int USER_ID_DEACTIVATED = 994001;
public static final int USER_ID_GENERATED = 994002;
public static final int FORGOT_USER_ID = 994003;
/*Added for USRDTL - END*/
/* Added for defect 361366 start */
public static final int DATES_WITHIN_3DAYS = 993147;
public static final int DATES_WITHIN_15DAYS = 993148;
public static final int DATES_WITHIN_21DAYS = 993149;
/* Added for defect 361366 end */
/*Added for RFW */
public static final int NAME_OF_BENEFICIARY_MANDATORY=993048;
public static final int BENEFICIARY_ADDRESS_MANDATORY= 993049;
public static final int MODE_OF_OPERATION_NOT_SINGLE= 995664;
/*Added for RFW */
/* Added for TO:361738  */

public static final int INVALID_AMOUNT_ENTERED = 829;
/* Added for Mobile Alert TO defects*/
public static final int MOBILE_NUMBER_TRANSACTION_ALERT=789;
public static final int MOBILE_NUMBER_NOT_REGISTERED_FOR_TRANSACTION_ALERT=787;
public static final int MOBILE_NUMBER_INTERNET_ALERT=785;
public static final int MOBILE_NUMBER_NOT_REGISTERED_FOR_INTERNET_ALERT=782;
/* Added for TO:364436  */
public static final int FD_TENURE_ON_BLANK = 993160;

//Added by neha_kerkar for ConvertTOEMI
public static final int CONVERT_TO_EMI_SUCCESS = 1530;
public static final int CONVERT_TO_EMI_SUCCESS_000 = 11531;
public static final int BRANCH_NOT_REGISTERED_FOR_RTGS = 9876;
//	Added for Sakthi
public static final int DPG_URN_INVALID_ALERTS=702;
public static final int ALERTS_SEND_TO_USER=704;
public static final int DPG_FACILTY_BLOCK_ERROR=760;
public static final int INVALID_URN_LENGTH=761;
public static final int DPG_URN_EXPIRED=762;
public static final int DPG_INVALID_URN=763;
public static final int DPG_URN_NOT_GENERATED=764;
public static final int DPG_URN_BLK_ALERTS=765;
public static final int DPG_INVALID_EMAILID=766;
public static final int DPG_EMAILID_MANDATORY=767;
public static final int DPG_MOBILENUM_MANDATORY=768;
public static final int DPG_INVALID_MOBILENUM=769;
public static final int DPG_URN_MANDATORY=770;
public static final int DPG_AUTH_DISABLED=102327;
public static final int DPG_AUTH_FAILED=107200;
public static final int DPG_FACILTY_URN_ALREADY_SENT=775;
public static final int DPG_PINGEN_HOST_FAILED=774;
public static final int DPG_PINGEN_HOST_SUCMSG=776;
public static final int DPG_PINGEN_HOST_SUCCESS=777;
public static final int DEBITCARD_PIN_LENGTH_INVALID=778;
public static final int DEBITCARD_PIN_NO_SPACES=779;
public static final int DEBITCARD_PIN_NOT_MATCHED=790;
public static final int DEBITCARD_PIN_MANDATORY=1001;



public static final int CANNOT_MODIFY_RECURRING_TRANSACTION = 995400;
public static final int CANNOT_STOP_MODIFY = 746;

//Start: Added by Devika for Integra gridcard validation
public static final int GRID_CARD_VALIDATION_NOT_SUCCESSFUL=994004;
public static final int GRID_CARD_ALPHABETS_BLANK=994005;
public static final int INVALID_USER_OR_CORP_ID=994009;
//End: Added by Devika for Integra gridcard validation

//Added for SMO ticket
public static final int CITY_LENGTH_SHOULDBE_GREATER_THAN_THREE = 747;

//Added for OTPV
public static final int OTP_EXPIRED = 994006;
public static final int OTP_USED = 994007;

//Added for INVMPIN
public static final int INVALID_QUERY_CRITERIA =994008;

//Added for FRDT table
public final static int FRDT_INSERTION_FAILED = 51005;


//Added for RPDT table
public final static int RPDT_RECORD_INSERTION_FAILED = 51009;


//added for name filed validation
public static final int ONLY_ALPHABETS_SPACE_ALLOWED_FOR_DRAWEEBANK = 997;
public static final int ONLY_ALPHABETS_SPACE_ALLOWED_FOR_DRAWEEBRANCH = 998;
public static final int ONLY_ALPHABETS_SPACE_ALLOWED_FOR_CARDHOLDER_NAME = 1000;
public static final int NO_BILLS_PENDING = 748;



/* Added for Facebook Banking*/

public final static int NO_RECORDS_FOR_DATA = 994010;
public final static int NO_MOBILE_NUMBER = 994011;
public final static int PROVIDE_HOST_ID = 994012;
public final static int PROVIDE_BANK_ID = 994013;
public final static int PROVIDE_CHANNEL_ID = 994014;
public final static int PROVIDE_PRINCIPAL_ID = 994015;
public final static int PROVIDE_REQUEST_ID = 994016;

/* Added for Facebook Banking*/
//add For CFD
public static final int CFD_DEP_TOBECLOSED_MANDATORY =994019;
public static final int CFD_TOBECLOSEON_MANDATORY =994020;
public static final int SMC_PLATINUM_CARD_NUMBER_LENGTH = 991099;

/*Added for RFW */
public static final int RFW_TO_BE_CLOSED_ON_MANDATORY = 993050;
public static final int RFW_REPATRIATION_OPTION_MANDATORY = 993030;
public static final int RFW_FD_ACCOUNT_NUMBER_MANDATORY = 994030;
/*Added for RFW */

/* Added for TO:338253  */
public final static int INVALID_TYPE_OF_CONVERSION_ON_RTN = 994080;
/*Added for Tax Payment Reconcilation Menuoption*/
public final static int DIRECT_TAX_RECONCILATION_SUCCESS = 910;
public final static int INDIRECT_TAX_RECONCILATION_SUCCESS = 911;
public final static int TAX_RECONCILATION_FAILED = 912;
public static final int TXND_UPDATION_FAILED = 913;
public static final int TXN_ALREADY_RECONCILED = 914;

public static final int HOT_PAYMENT_SUCCESS_OTHER_CHANNELS = 994024;

/*Added for TO 361725 */
public static final int INVALID_SALARY_CREDITED_DATE = 994025;
/* Added for Integra*/

public final static int NO_USER_TYPE = 994027;
public final static int NO_DEBIT_CARD_FOUND = 994028;
//Added for RTGS ENABLED
public final static int RTGS_ERROR_CODE= 791;

/*Added for NBR Debit Card Hotlisting ----Start*/
public static final int DEBIT_CARD_NUMBER_MANDATORY = 994026;
public static final int DEBIT_CARD_BLOCKING_REASON_RET =994034 ;
public static final int DEBIT_CARD_BLOCKING_REASON_NRI =994035 ;
/*Added for NBR Debit Card Hotlisting ----End*/

/*Added for SIB */
public static final int SR_SIB_VALID_DO_YQ=993192;
public static final int SR_SIB_VALID_CI_TYS=993193;
public static final int SR_SIB_VALID_DA_TE=993194;
public static final int SR_SIB_VALID_BR_CHS=993195;
public static final int SR_SIB_VALID_CI_TYT=993196;
public static final int SR_SIB_VALID_BR_CHT=993197;
/* for fix defect 371197 about SR UNR -----Start*/
public static final int SR_UNR_INVALID_AGREE_YESNO=993180;
public static final int SR_UNR_INVALID_YESNO_MANDATORY=993181;
/* for fix defect 371197 about SR UNR -----End*/
/* Added for RTGS ADMIN START*/
public static final int IFSC_CODE_MANDATORY = 915;
public static final int VALID_IFSC_CODE= 916;
public static final int BANK_DESCRIPTION_MANDATORY= 917;
public static final int BRANCH_DESCRIPTION_MANDATORY= 918;
/* Added for RTGS ADMIN END*/
/*Added for NBR Debit Card Hotlisting ----Start*/
public final static int MANDATORY_FIELDS_CANNOT_BE_BLANK = 994029;
/*Added for NBR Debit Card Hotlisting ----End*/

/*Added for TO 370715 ----Start*/

public final static int BOTH_FROM_TO_DATE_NEEDED = 994030;


/*Added for TO 370715 ----End*/

public final static int NO_RD_DETAILS = 786;
public static final int RTGS_NOT_ENABLED_BRANCH= 990;

/* For iSafe */
public static final int ISAFE_SEED_SUCCESSFULLY_SENT = 1601;
public static final int MAX_NO_RECORDS_EXCEEDED = 840;

//CreditCard URN - START
public static final int URN_GEN_SUCCESS_CODE=1002;
public static final int WRONG_URN_FOR_TXN=1003;
public static final int URN_EXPIRED=1004;
//CreditCard URN - END

//Added for Buy Gold
public static final int BUY_GOLD_NO_RECORDS_FETCHED=108400;
// Added for iWish accounts
public final static int NO_IWISH_ACCOUNTS =830;
public final static int NO_MOBILE_SUBSCRIPTION =995001;

/* Added for TO ID 375442 : START*/
public static final int WRONG_MOBILE_NUMBER_ENTERED= 995;
public static final int MOBILE_NOT_REGISTERED= 996;
/* Added for TO ID 375442 : END*/

//Credit Card OTP
public static final int HOST_DOWN_FOR_SESSIONKEY=1005;

/*Added for NBR - SR Validations*/
public final static int INVALID_CARD_NUMBER = 919;
public final static int INVALID_CARD_HOLDER_NAME = 920;
public final static int CARD_STATUS_OPEN = 921;
public static final int CARD_STATUS_CLOSED = 922;
public final static int MOBILE_NUMBER_NOT_MATCH_CUSR = 923;
public final static int EMAIL_ID_NOT_MATCH_CUSR = 924;
public final static int ACCOUNT_NUMBER_NOT_FOUND_UEDT = 925;
public static final int CITY_NOT_MATCH_CUSR = 926;
public static final int ACCOUNT_LIEN_MARKED = 930;
public static final int UNABLE_TO_PROCESS_OPEN_FD = 931;
public static final int PAN_NOT_FOUND = 932;
public static final int PAN_NOT_MATCH = 933;
public static final int CC_EXPIRY_DATE_NOT_MATCH = 934;
public static final int CANNOT_RAISE_CHANGE_ADDRESS_REQUEST = 935;
public static final int UNABLE_TO_OPEN_FD = 936;


//Added for tenure validations in Standard FD
public static final int INCORRECT_TENURE_CUMMULATIVE_FD=927;
public static final int INCORRECT_TENURE_MONTHLY_FD=928;
public static final int INCORRECT_TENURE_QUARTERLY_FD=929;

public static final int MAXIMUM_FD_AMOUNT_SPECIAL_CHARACTER=995002;
//Added for ISAFE
public static final int ISAFE_ACTIVATION_FAILED = 995003;
public static final int ISAFE_ACTIVATION_SUCCESS = 995004;

/*Added for TO ID 379673  - START*/
public final static int CHEQUE_NUMBER_REQUIRED = 751;
public final static int ECS_FAVORING_TO_REQUIRED = 752;
/*Added for TO ID 379673  - END*/
public static final int SELECT_FDRD_ACC_CLO=1111;
/*Added for TO ID 381012   - START*/
public static final int ONLY_CAP_ALPHABETS_FOR_FIRST_FIVE=995005;
public static final int SIXTH_TO_NINTH_TOBE_NUMERIC=995006;
public static final int ONLY_CAP_ALPHABETS_FOR_LAST_ONE=995007;
/*Added for TO ID 381012   - END*/

/*Added for Buy Gold Fixes - Start*/
public static final int GOLD_NOT_AVAILABLE = 937;
/*Added for Buy Gold Fixes - End*/
public static final int RTGS_REMARKS_MANDATORY = 938;
public final static int PARTIAL_CLOSURE_REPATRIATION = 995014;

/*Added for TO ID 381377- START*/
public final static int INVALID_COURIER_DATE  = 995009;
public final static int INVALID_HAND_DELIVERY_DATE  = 995010;
public final static int INVALID_PO_BOX_AMOUNT  = 995011;
/*Added for TO ID 381377- END*/
/*Added for TO ID 387244- START*/
public final static int INVALID_REGISTERED_POST_DATE  = 995015;
/*Added for TO ID 387244- END*/
/*Added for TO ID 387465- START*/
public final static int CONTACT_SHOULDBE_NUMERIC  = 995016;
/*Added for TO ID 387465- END*/
public final static int INVALID_ECS_BRANCH_NAME = 995012;

/*Added for TO ID 381377- START*/

public final static int INVALID_LOCATION = 995013;

/*Added for TO ID 381377- END*/
/*Added for TO ID 385641- START*/
public static final int RECURRING_TRANSACTION_MODIFY_NOTALLOWED = 939;
/*Added for TO ID 385641- END*/

public static final int INVALID_TENURE_OF_DEPOSIT_DAYS_LESSTHAN_92 = 874;
public static final int INVALID_TENURE_OF_DEPOSIT_DAYS_LESSTHAN_32 = 875;

/* Added for TO ID 389204 START*/
public static final int BILL_DEFAULTED = 942;
/* Added for TO ID 389204 END*/
/* Added for TO ID 388493 START*/
public static final int PWD_DISABLE_SUCCESSFULL = 510;
public static final int PWD_ENABLE_SUCCESSFULL = 511;
public static final int RECORDS_NOT_FOUND = 512;
/* Added for TO ID 388493 END*/
public static final int AMOUNT_NOTIN_MULTIPLES_100 = 899;

//Added for TO Id 387812
public static final int FD_RECEIPT_TAXSAVER_FD_NOT_ALLOWED = 995022;
/*Added for CR 199 : Aadhaar SR Start */
public static final int AADHAAR_NUMBER = 995023;
/*Added for CR 199 : Aadhaar SR End */
public static final int MICR_CODE_INVALID = 877;
public static final int GRID_TRAN_DISABLED = 878;
public static final int MOBILE_NUM_EXISTS = 995030;
public static final int CVV_NUMBER_INVALID = 856;
public static final int CH_CHECK = 995033;
public static final int CLICK_HERE_LINK = 995032;
public static final int SMM_TENURE_YEARS_MIN = 995402;
public static final int SMM_TENURE_YEARS_MAX = 995403;
/*Added for CR 210 Start*/
public static final int KYC_ENABLE_SUCCESS_MESSAGE=847;
public static final int KYC_DISABLE_SUCCESS_MESSAGE=848;
public static final int INVALID_USER_KYC_LINE = 881;
/*Added for CR 210 End*/
/*Added for Remarks CR *Start*/
public static final int INVALID_REMARKS_FIELD = 885;
/*Added for Remarks CR *End*/
public static final int DEMAT_LINKED_TO_SAVINGS = 995404;
/*added for 384708  SR Repatriation from NRE SB via DD Start*/
public static final int IMPROPER_BENEFICIARYSTATE_MIN_LENGTH =993021;
public static final int IMPROPER_BENEFICIARYSTATE_ONLY_ALPHABETS_ALLOWED =993020;
/*added for SR Repatriation from NRE SB via DD End*/

//Added for issue 384768
public static final int MIN_NO_OF_MONTHS_IS_10 = 995405;
public static final int MAX_NO_OF_MONTHS_IS_120 = 995406;
public static final int DAYS_TO_BE_RENEWED_BLANK = 995407;
public static final int MAX_NO_ALLOWED_YEARS_EXCEEDED = 995408;
//added for issue 394371
public static final int CUSTOM_INVALID_NRE_ACCOUNT = 995410;

public static final int ONLINE_PWD_GEN_DISABLED = 995411;
public static final int EMAIL_UPDATE_FAIL = 879;
public static final int TIME_OUT_SUCCESS_MESSAGE = 880;
//added for issue 386287
public static final int PREMATURE_CLOSURE_FD_NOT_ALLOWED=1112;
public static final int PROCESSING_FAILED_FOR_ENABLEGRIDOTP_BATCH = 995413;
public static final int SIDT_UPDATE_FAILED = 995414;
public static final int UADT_UPDATE_FAILED = 995415;
public static final int TRANSACTION_DISABLED = 995416;
public static final int MAX_WIDGET_COUNT_REACHED = 995426;
public static final int REMOVE_WIDGET_COUNT = 995427;

public static final int DMT_NO_TXN = 995430;

//Added for shopping mall reversal
public static final int SHPMALL_REVERSAL_DISABLED = 1777;
public static final int SHPMALL_LATE_REQUEST = 1778;
public static final int SHPMALL_INVALID_URL_TIME = 1779;
public static final int WRONG_PARAMS_IN_REVREQ = 1780;
public static final int SMS_TRANSACTION_CANCELLED_SUCCESSFULLY = 995428;
public static final int PID_LEN_INVALID_IN_REVREQ = 1781;
public static final int TXNTIME_LEN_INVALID_IN_REVREQ = 1782;
public static final int CRN_LEN_INVALID_IN_REVREQ = 1783;
public static final int ITC_LEN_INVALID_IN_REVREQ = 1784;
public static final int PRN_LEN_INVALID_IN_REVREQ = 1785;
public static final int REVERSAL_FAILURE = 1786;
public static final int PAYEE_ADDITION_LIMIT = 995444;
public static final int smsNcash_AMOUNT_NOTIN_MULTIPLES_100 = 995447;
public static final int FIELD_DOESNOT_CONTAIN_NUMBERS_SPECIAL_CHARACTER = 995448;

public static final int FIELD_VALIDATION = 995445;
public static final int INVALID_PIN_LENGTH_CCA = 995450;
public static final int UTML_CHK = 995451;
public static final int SERVICE_REQ_EXISTS_MSG = 995490;

public static final int DD_DATE_BEFORE_THREE_MONTHS = 995446;
public static final int USER_ENABLED_TO_GET_OTP_ON_EMAIL = 995456;
public static final int EMAILID_CHK = 995457;
public static final int NRI_CHK = 995460;
public static final int MOBNO_CHK = 995459;
public static final int OTP_ENABLED = 995455;
public static final int OTP_TO_EMAILID_DISABLED_SUCCESSFULLY = 995454;
public static final int DELETE_CHK = 995453;
public static final int PWD_CONTAINS_USERID = 99501;

//Added for Welcome Page CR
public static final int CONFIRM_MOBILE_NUM = 993226;
public static final int RTGS_INVALID_DATE = 944;
public static final int REWARDS_HIF_ERROR = 945;
//Added for TO 409128
public static final int INVALID_FD_MOP = 993227;
public final static int CSIP_ALIAS_NOT_FOUND = 51020;
public static final int FIELD_SHOULD_CONTAIN_ONLY_ALPHANUMERICDOT = 995110;
public static final int FIELD_SHOULD_CONTAIN_ONLY_UPPERCASE_LETTERS_AND_NUMBERS = 995111;
public static final int FIELD_SHOULD_CONTAIN_ONLY_ALPHANUMERICHYPHEN9 = 995112;
public static final int FIELD_SHOULD_CONTAIN_NUMBER_AND_HYPHEN = 995113;

//Added for CR 411688
public static final int INVALID_ASSESSMENT_YEAR =995464;
public static final int TDS_NOT_GENERATED = 995492;
public static final int TECH_ERROR= 995494;
//Added for iMobile Batch
public static final int USERID_CANNOT_BE_BLANK = 993223;
public static final int PROCESSING_FAILED_IN_IMOBILEUPLD_BATCH = 993222;
//added for CR 379695
public static final int INVALID_MAX_MOBILE_LENGTH = 726;

/* Added for 418735 start */

public static final int DP_FROM_DATE = 995495;
public static final int DP_TO_DATE = 995496;

public static final int NO_ACCOUNTS_FOUND = 9992;
public static final int INVALID_ACCOUNT_NUMBER = 100046;
/*Added for SR68535668*/
public static final int INVALID_MOBILE_LENGTH_CCA = 9993;

//Added for NRI Validations CR
public static final int ADDRESS_RECENTLY_UPDATED = 993211;
public static final int DUPLICATE_ADDRESS_CHANGE_REQUEST = 993212;
public static final int ADDRESS_CHANGE_REQUEST_OPEN_STATUS = 993213;

/*Added for SR68538060*/
public static final int MANDATE_REGISTRATION_DUPLICATION = 995497;

//added for RTGS Scheduling CR
public static final int RTGS_SCHEDULE_NOT_ALLOWED_BEYOND_GIVEN_RANGE = 995498;

//added for bill payments

public static final int BLP_CC_MAKEPAYMET = 995499;

// Added for Service Request-RWT
public static final int RWT_REPAT_AMT_MANDATORY = 727;

// Added for SR68953251
public static final int REWARD_ITEMS_MAX_LIMIT_REACHED = 123115;

/* Added for USERIDFOROTP MB service */
public final static int CSIP_CHANNEL_M_NO_RECORDS_FETCHED = 995502;
/* Added for USERIDFOROTP MB service */

public final static int CLICK_CHK_PRCD = 995510;
/* Added for SR70436897 */
public static final int USERID_CONFIRM_USERID_DIFF = 995504;
public static final int USERID_MANDATORY = 995505;
/* Added for SR70436897 */

public static final int ONLY_ALPHABETS_SPACE_HYPHEN_DOT_COMMA_ALLOWED = 995514;
public static final int INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_HYPHEN_DOT = 995515;
public static final int INVALID_FIELD_VALUE_ONLY_NUMERIC_HYPHEN_DOT = 995516;
public static final int INVALID_PWD_RESET_MOB_COOLING = 995518;
public static final int CC_LENGTH = 995599;

/*Added for NRI PRO/Premia SR-start*/
public static final int NPP_SAVING_ACCT_MANDATORY = 618;
public static final int NPP_SAVING_ACCT_INVALID_STATUS = 6667;
public static final int NPP_DEBIT_FREEZE = 6666;
public static final int NPP_INVALID_COUNTRY = 6671;
public static final int NPP_INVALID_COUNTRYCODE = 6663;
public static final int NPP_LIEN_MARKED = 6664;
public static final int NPP_INACTIVE_ACCOUNT = 6665;
/*Added for NRI PRO/Premia SR-end*/

/* Added for CR2054-54139 */
public static final int FD_PAN_NOT_FOUND = 995601;
/* Added for CR2054-54139 */

/* Added for SR73653446 */
public static final int INVALID_PWD_RESET_0DAYS = 995519;
/* Added for SR73653446 */
public static final int CCRT_INVALID_PAYEE_ID = 995602;
public static final int PMMT_INVALID_BANK_ID = 995603;
public static final int PMMT_INVALID_BRANCH_NAME = 995604;
public static final int PMMT_INVALID_ZIP = 995607;
public static final int PMMT_INVALID_ZIP_ETXN = 995606;

/* Added for CR-2054-56545_smsNcash */
public static final int MOBILE_NUMBER_NOT_REGISTERED_SNC = 995520;
public static final int SPACES_IN_REGISTERED_MOBILE_NUMBER = 995521;
/* Added for CR-2054-56545_smsNcash */
public static final int CC_LENGTH_PAYEE = 995597;

/* Added for CR-2054-54624 */
public static final int REQ_FORECLOSURE_STATEMENT = 995522;
public static final int LSA_ACCOUNT_STATEMENT = 995523;
public static final int LENGTH_LESS_THAN_MINIMUM_LENGTH_NOT_ALLOWED_IN_FIELD_NAME_BEST =995524;
/* Added for CR-2054-54624 */

/* Downtime message on RIB for iCore migration */
public static final int ICORE_DOWNTIME =995525;
/* Downtime message on RIB for iCore migration */

// CR 56382

public static final int CARD_STATUS_LOST = 995608;

public static final int LID_CC_LINKED_USERID = 995612;
public static final int LOA_ACCNT_LINKED_USERID = 995613;
public static final int LLA_ACCNT_LINKED_USERID = 995614;
public static final int RECEIVE_FUNDS_FAIL =995610;
public static final int RECEIVE_FUNDS_TRAN_FAIL =995611;

//CR 56382
public static final int DEBITCARD_ALREADY_LINKED=995609;
//ICORE CR

public static final int PREMISE_BUILDING_NAME_INVALID=995615;
public static final int STREE_ROAD_NUMBER_INVALID=995616;
public static final int STREE_ROAD_NAME_INVALID=995617;
public static final int LANDMARK_INVALID=995618;
public static final int LANDLINE_NUMBER_INVALID=995619;
public static final int ALTERNATE_MOBILE_NUMBER_INVALID=995620;
public static final int RCC_ADDRESS_DETAILS_NULL=995621;
public static final int HOUSE_FLAT_NUMBER_INVALID=995622;
public static final int FLOOR_NUMBER_INVALID=995623;
public static final int STD_CODE_INVALID=995626;

public static final int SERVICE_REQUEST_NUMBER_LENGTH =995624;
public static final int SERVICE_REQUEST_NUM_STARTS_WITH = 995625;

/* Added for CR-2054-58289 */
public static final int INVALID_LPG_NO = 995627;
public static final int INVALID_IFSC_CODE = 995628;
/* Added for CR-2054-58289 */

/* Added for CR-2054-56545 */
public static final int ICASH_TIMEOUT = 995629;
/* Added for CR-2054-56545 */
public static final int IS_FD_RD_IWISH_HOT_TXNS = 995633;
public static final int IS_FD_RD_IWISH_SCHD_TXNS = 995631;
public static final int IS_FD_RD_IWISH_ACCT_NO = 995632;
public static final int NO_OPEN_SRS_FOUND = 995636;
public static final int NO_CLOSED_SRS_FOUND = 995637;


/* Added for Favorite transactions for PMR/DTH */
public static final int FAV_PAYEE_DUPLICATE = 995638;
public static final int FAV_PAYEE_SUCCESS = 995639;

public static final int PAN_NUMBER_MANDATORY=995640;
public static final int IMPROPER_LENGTH_FOR_NAME_ON_CARD=995641;

/* Added for Favorite transactions for PMR/DTH */
public static final int FAV_PAYEE_DELETE_SUCCESS = 995642;
public static final int NO_FAV_FETCHED = 6669;
public static final int CARD_TYPE_UAD_MANDATORY = 995643;
public static final int STDCode_SHOULDBE_NUMERIC=995644;
public static final int PinCode_SHOULDBE_NUMERIC=995646;
public static final int ACCT_DETAILS_NOT_FETCHED=9995;

public static final int INVALID_DATE_9DAYS = 600001;
/*Added for Income Tax e-Filing CR -Start*/
public static final int No_ACCNT_SELECTED = 6675;
public static final int PAN_NOT_FETCHED = 6676;
public static final int PAN_RESPONSE_NOT_RECEIVED = 6677;
/*Added for Income Tax e-Filing CR -End*/

/* Added for SR80162034 */
public static final int ADDR2_FIRST_CHAR_SHOULD_NOT_BE_NUMERIC = 995648;
/* Added for SR80162034 */
public static final int MOBILENUMBER_IS_MANDATORY_IMOBILE = 9955;
public static final int INVALID_MOBNO_IMOBILE =9956;
/*Added for GridCard Validation*/
public static final int GRID_VALUES_NOT_FETCHED =9957;
public static final int GRID_EXCEPTION =9958;
public static final int GRID_VALIDATION_FAILED =9959;
/*Added for NRI Welocme Page Validations*/

public static final int CONFIRM_EMAIL_ID =995649;
public static final int INVALID_NRI_MOBNO_LENGTH =995650;
public static final int INVALID_NRI_MOBNO =995651;
public static final int INVALID_AREA_CODE =995652;
public static final int INVALID_NRI_LANDLINE =995653;
public static final int INVALID_NRI_LANDLINE_LENGTH =995654;
public static final int LANDLINE_CNTRY_CODE_MANDATORY =995655;
public static final int LANDLINE_AREA_CODE_MANDATORY =995655;
public static final int NVALIDCREDIT_CARDNO = 995656;
/* Added for generate Credit Card Pin Online */
public static final int CARDTYPE_INVALID =9960;
public static final int BLOCK_CODE_INVALID =9961;
public static final int ACT_CODE_INVALID =9962;
public static final int CVV_INVALID_ATTEMPTS_CASE =9963;
public static final int SELECT_REMITTANCE_SCHEME = 764469;
public static final int TERMS_N_CONDITIONS = 764468;

public static final int NO_CC_ROWS_FETCHED = 764470;

public static final int PIN_NOT_GENERATED =9965;
public static final int PIN_GENERATED_SUCCESSFULLY =9966;

public static final int POCKETS_MONTH_INVALID =19956;

public static final int CREDITCARD_PIN_LENGTH_INVALID=9967;
public static final int CREDITCARD_PIN_NO_SPACES=9968;
public static final int CREDITCARD_PIN_MANDATORY=9969;
public static final int CREDITCARD_PIN_NOT_MATCHED=9970;

public static final int NEW_RECORD_UPDATED_SUCCESSFULLY =9971;
public static final int CPG_PINGEN_HOST_SUCCESS =9972;
public static final int CPG_PINGEN_HOST_FAILED =9973;
public static final int CPG_PINGEN_FACILITY_DISABLED =9974;
public static final int ACCOUNT_AGE_DAYS=995663;
public static final int FTA_PAN_UPDATE_MAND = 995660;
public static final int CPG_PINGEN_FACILITY_BLOCKED =9975;
/*Added for Pradhan Mantri Bima SR's*/
public static final int GENDER_MANDATORY = 9980;
public static final int NOMINEE_NAME_MANDATORY = 9981;
public static final int NOMINEE_REL_MANDATORY = 9983;
public static final int NOMINEE_ADDR_MANDATORY = 9982;
public static final int INVALID_NOMINEE_NAME = 9984;
public static final int INVALID_NOMINEE_REL = 9985;
public static final int INVALID_GUARDIAN_NAME = 9986;
/*Added for Pradhan Mantri Bima SR's*/
public static final int RECORD_CANNOT_UPDATE =9978;
public static final int RECORD_CANNOT_UPDATE_Y =9977;
public static final int RECORD_CANNOT_UPDATE_N =9976;
public static final int FDC_DATE_3DAYS = 995670;
public static final int RECORD_UPDATED_SUCCESS =9979;


public static final int CONSUMER_CODE_INVALID =9989;
public static final int USER_NOT_REGISTERED_QUICKCHECKOUT = 9990;
public static final int CAR_FAILURE_ACTCODE = 995679;

public static final int PKP_CHECK = 995799;
public static final int INVALID_MESSAGE = 995700;

public static final int INCORRECT_IFSC_MESSAGE = 99502;
public static final int LIVE_ASST_SESSION = 9951;
public static final int IFSC_NOT_VERIFIED = 9953;
public static final int IFSC_MANDATORY = 9954;
public static final int ONE_REQUEST_ALLOWED_PER_DAY=107770;
/*Added for Favourite Payee CR*/
public static final int USER_REGISTERED_AS_FAVOURITE = 995711;
/*Added for RD alliance CR*/
public static final int INVALID_RD_ALLIANCE_AMOUNT = 995801;
public static final int NO_FAVOURITE_AVAILABLE = 995712;
public static final int IMPS_FUNCTIONALITY_NOT_AVAILABLE = 995804;
public static final int MAX_NO_FAVOURITE = 995805;
public static final int ONPWDGEN_DISABLED_FOR_USER = 674;
/*Added for Closure/Renewal FR/RD  CR*/
public static final int MIN_FD_ACCOUNT_BALANCE = 995806;
public static final int INVALID_WITHDRAWAL_AMOUNT = 995807;
public static final int MAND_WITHDRAWAL_AMOUNT = 995808;
public static final int SPECIAL_CHAR_NOT_ALLOWED_IN_PAYEE_NICKNAME=995983;
public static final int CRD_SERVICE_REQUEST_SUCCESS_MESSAGE = 995809;
public static final int PAYEE_ALREADY_FAV = 995810;
public static final int BILLER_ALREADY_FAV = 995811;
public static final int LLA_INVALID_ACCNT= 99567;

//Added for CR-2054-70834 SR for IB payment status enquiry.

public static final int PAYID_NOT_WEEK_OLD = 995812;
public static final int NEFT_RTGS_PAY_ID = 995813;
public static final int NO_RECHARGE_PLAN=9998;
public static final int LOOKUP_MANDATORY = 995816;

//Added for Rewards enroll CR
public static final int ENROLL_FAILED=101649;

//Added for gold bonds CR
public static final int UNITS_OUT_OF_LIMIT = 996033;
public static final int UNITS_SHOULD_NOT_HAVE_DECIMAL = 996015;
public static final int INVALID_DOB_SGB = 996016;
public static final int DPID_SGB_INVALID=996017;
public static final int ACCT_BAL_INSUFFICIENT_FOR_SGB=996018;
public static final int INSUFFICIENT_BALANCE_FOR_CARD = 1708;

public static final int ACCOUNT_MANDATORY=33061;

public static final int USER_MOBILE_MISMATCH=996034;
public static final int USER_EMAIL_MISMATCH=996035;

public static final int INVALID_DP_ID_LENGTH=996031;
public static final int INVALID_DP_CLIENT_ID_LENGTH=996032;
public static final int FUTURE_DOB=996030;
//added for CRD_SERVICE_REQUEST_FAILURE_MESSAGE
public static final int LIEN_MARKED_CRD = 996019;
public static final int FDRD_ACCOUNT_FREEZE = 996020;
public static final int SB_ACCOUNT_FREEZE = 996021;
public static final int FD_LINKED=996022;
public static final int CLOSED_FDRD_ACCOUNT=996023;
public static final int CLOSED_SYS_ERROR=996024;
public static final int FI_VISIT_BRANCH=996025;
public static final int FI_REPAY_ACCOUNT_NOT_SAME=996026;
public static final int FI_CLOSURE_OF_ACCOUNT=996027;
public static final int FI_CLOSURE_DATE_CANT_BE_LATER_THAN_BOD=996028;


public static final int DIG_REG_FAIL = 5661;
public static final int DIG_DREG_FAIL = 5662;

//Added for CR-2054-72784 SR for common check box
public static final int CHK_BOX = 995820;
public static final int NOT_REGSITERED_FOR_DIGITAL_CERTIFICATE=996071;
public static final int EMAS_HOST_NOT_AVAILABLE = 996072;
public static final int CERTIFACTE_DEREGISTRATION_FAILED = 996073;
public static final int CERTIFACTE_ALREADY_REGISTERED = 996074;
public static final int CUSTOMER_ALREADY_EXISTS = 996075;
public static final int REGISTRATION_FAILED = 996076;
public static final int CERTIFICATE_NOT_MATCHING = 996077;
public static final int CERTIFICATE_VERIFICATION_FAILED = 996078;


//Added for APY CR
public static final int MANDATORY_SPOUSE_NAME=996090;
public static final int MANDATORY_GUARDIAN_NAME=996091;
public static final int SPOUSE_NAME_NOT_VALID=996096;
public static final int GUARDIAN_NAME_NOT_VALID=996097;
public static final int NOMINEE_NAME_NOT_VALID=996098;
public static final int NOMINEE_RELATION_FORMAT_NOT_VALID=996099;
public static final int INVALID_AGE_RANGE=996105;
public static final int MANDATORY_GUARDIAN_NAME_APY=996106;
public static final int MANDATORY_SPOUSE_NAME_APY=996107;
public static final int NOT_REQUIRED_GUARDIAN_NAME_APY=999907;
public static final int NOT_REQUIRED_SPOUSE_NAME_APY=999908;
public static final int NOMINEE_RELATION_APY=999931;
//end
//Added for CR-2054-76859
public static final int ACC_STAT_CHECK=996082;
//FD Closure
public static final int  MIN_WITHDRAWAL_AMOUNT=999903;
public static final int AMOUNT_WITHDRAWAL_RENGE=999904;
public static final int FD_RD_CLOSURE_SUCCESS=999905;

//Added for CR-2054-70314 SR Validation - start
public static final int INVALID_FIELD_FOR_MATURITY_PROCEEDS_FD = 999100;
public static final int INSTANCE_CC_AGAINST_FD_FOR_JA_NOT_POSSIBLE = 999101;
public static final int INSTANCE_CC_AGAINST_FD_FOR_MINOR_NOT_POSSIBLE = 999102;
public static final int DOB_NOT_UPDATED = 999103;
public static final int MOTHER_MAIDEN_NAME_NOT_UPDATED= 999104;

public static final int SIX_MONTHS_OLD_ACCOUNT=999200;
public static final int SB_INACTIVE_ACCOUNT=999201;
public static final int SB_DORMANT_ACCOUNT=999202;
public static final int SB_FROZEN_ACCOUNT=999203;
public static final int SB_CURRENT_ACCOUNT=999204;
public static final int SB_LIEN_ACCOUNT=999205;
public static final int SB_DEBIT_BALANCE=999206;
public static final int TRANSACTIONS_WERE_FOUND_FOR_THIS_ACCOUNT=999600;

public static final int NRI_ACC_INVALID_STATUS=999207;
//Added for CR-2054-70314 SR Validation - end
public static final int CSIP_UPDATE_ERROR = 4002;
public static final int DEBITCARD_PIN_NO_SPECIAL_CHAR = 99209;
public static final int CREDIT_CARD_NUMBER_IS_MANDATORY = 999901;
public static final int ENTER_MOBILE_NUMBER_MANDATORY = 999902;

//Added for Search Box
public static final int SEARCH_STRING_LESS_THAN_THREE = 993;
//Added for dth
public static final int FAV_SUBSCRIBER_ID_DUPLICATE = 999909;

//Added For CR-2054-78471 - CUSR DEL Flag Update
public static final int EXCEPTION_UPDATE_CUSR_FLAG = 108403;
public static final int SUCCESS_UPDATE_CUSR_FLAG = 108404;

//Added For CR-2054-78471 - CUSR Password Flag Update
public static final int EXCEPTION_UPDATE_CUSR_PWD_FLAG = 108405;
public static final int SUCCESS_ENABLE_CUSR_PWD_FLAG = 108406;
public static final int SUCCESS_DISABLE_CUSR_PWD_FLAG = 108407;

//Added for Duplicate Check in SR For CR-2054-68305
public static final int SERVICE_REQUEST_DUPLICATES_MESSAGE_NEW = 108408;

public static final int PRINCIPAL_DUES_ERROR = 995832;
public static final int MATURITY_DATE_ERROR = 995833;
public static final int SEQUENCE_NOT_GENRATED = 995834;

//Added for NRI_OTP_ALERTS CR-78410
public static final int COOLING_PERIOD_NRI = 999920;
public static final int COOLING_PERIOD_SCHD_NRI = 999921;

public static final int PROCESSING_FAILED_IN_MOBILE_NUMBER_DELETION_BATCH = 999933;
//Added for 68203
public static final int INVALID_MONTH_FORMAT = 999928;
public static final int INVALID_YEAR_FORMAT = 999929;
public static final int MANDATORY_FIELD = 999930;

//Added for 82348
public static final int FD_MATURITY_CLOSURE_ERROR = 996201;
public static final int FD_RENEWED_MATURITY_CLOSURE_ERROR = 996202;
public static final int PAN_NO_NOT_FETCHED = 995839;
public static final int MANDATORY_EQUITY=999952;
public static final int MANDATORY_TOTALASSET=999953;
public static final int FATHER_NAME_NOT_VALID=999954;

//added for operator name
public static final int OPERATOR_NAME_NULL = 996901;
//public static final int FIELDVALUE_SHOULDBE_LENGTH = 99100;
public static final int FIELDVALUE_INVALID = 99100;
public static final int FIELDVALUE_SHOULDBE_ALPHABETS = 99101;
public static final int SPECIAL_CHAR_AND_SPACES_NOT_ALLOWED = 99102;
public static final int ONLY_HYPEN_ALLOWED = 99103;
public static final int ONLY_NUMBERS_ALLOWED = 99104;
public static final int INVALID_FIELD_VALUE_ONLY_ALPHANUMERICALPHA_HYPHEN_NUMERIC = 999951;



public static final int INVALID_RD_ALLIANCE_AMOUNT_TEXT = 995899;
public static final int INVALID_COMMON_CODE = 995864;
public static final int INVALID_CODE_TYPE = 995865;
public static final int INVALID_CODE_DESC = 995866;
public static final int INVALID_SPECIAL_CHARS_CODE_TYPE = 995867;
public static final int INVALID_SPECIAL_CHARS_COMMON_CODE = 995868;

public static final int LIEN_FD_ACCOUNT = 995869;
public static final int ISIN_LIST_NOT_AVAILABLE=996200;
public static final int SPECIAL_CHARACTERS_NOT_ALLOWED_ISIN=996209;

	//Added for Pay on Delivery messages in API call
    public static final int INVALID_PRODUCT_DETAILS=960;
    public static final int INVALID_IP_ADDRESS=968;
	public static final int PAYMENT_EXPIRED = 962;
	public static final int INVALID_OTP_ENTERED_COD = 963;
	public static final int COD_OTP_EXPIRED = 964;
	public static final int PRODUCT_MISMATCH_OTPGEN_PAYMENT = 965;
	public static final int PMT_ALREADY_DONE = 966;
	public static final int INVALID_AMOUNT_COD = 967;
public static final int ISIN_MIN_LENGTH=996210;

	public static final int NOTMANDATORY_GUARDIAN_NAME_NPR=999947;
	public static final int MANDATORY_GUARDIAN_NAME_NPR=996106;
public static final int REGISTER_MOBILE_BEFORE_ADD_PAYEE_NRI = 999950;
public static final int SELECT_VALID_TENURE = 999931;

   //debit card limits
  public static final int DOMESTIC_AND_INTERNATIONAL_IDD = 999944;

public static final int DOMESTIC_INTERNATIONAL_LIMITS = 999993;
 public static final int PERMANENT_TEMPORARY_ENTRY=999984;
 public static final int DESIRED_LIMIT_FOR_CASH=999985;
 public static final int DESIRED_LIMIT_FOR_MERCHANT=999986;
 public static final int DESIRED_LIMIT_FOR_ONLINE=999987;
 public static final int INTERNATIONAL_PERMANENT_TEMPORARY_ENTRY=999988;
 public static final int INTERNATIONAL_DESIRED_LIMIT_FOR_ONLINE=999989;
 public static final int INTERNATIONAL_DESIRED_ONLINE__TRANSACTION=999990;
 /*Debit card STP start*/
 public static final int INTERNATIONAL_DEACTIVATED_CASE=7785;
 public static final int INTERNATIONAL_ALREADY_ACTIVATED=7784;
 public static final int INTERNATIONAL_DEACTIVATED_DEACTIVE_SELECT=7783;
 public static final int MAX_DEBIT_LIMIT_EXCEED=7819;










  //end debit card limits
public static final int USER_NOT_IN_SESSION= 996212;
public static final int ACCOUNT_NOT_AVAILABLE=996213;
public static final int INSTALLMENT_NOT_AVAILABLE = 999952;
public static final int ACCOUNT_STATUS = 999978;
public static final int UNBILLED_TRANSACTION_UNAVAILABLE = 999980;


public static final int PINCODE = 999997;

 public static final int PINULL = 999964;

public static final int PINValid = 999965;

public static final int ADDRESS = 999963;

 public static final int NAMEONCARD = 996670;

public static final int DECIMAL_AMOUNT = 99956;
public static final int CIRCLE_INVALID = 99957;

	public static final int SCHEDULEID_DISABLED = 99969;
public static final int NO_RECORDS_FETCHED_DIGI_LOCKER = 999055;

public static final int DIGI_LOCKER_CALLBACK_FAILED = 999056;

public static final int NRIFD = 90690;
//Aadhar Number Validation
public static final int AADHAR_VAL_ERROR = 999994;
/*Added for CR-2054-76630 Quick Checkout API - start*/
public static final int QUICK_CHECKOUT_API_ENABLE = 7659;
public static final int QUICK_CHECKOUT_MERCHANT_ENABLE = 7679;
public static final int QUICK_CHECKOUT_ENABLE = 8643;
public static final int INSERTION_FAILED_TO_QCAT =3110;
public static final int QUICK_CHECKOUT_OTP_EXPIRED = 3114;
public static final int QUICK_CHECKOUT_INVALID_DETAILS =3113;
public static final int QUICK_CHECKOUT_PAYMENT_DONE =3112;
public static final int QUICK_CHECKOUT_NO_RECORD =3115;
public static final int QUICK_CHECKOUT_INVALID_OTP =3116;
public static final int QUICK_CHECKOUT_FUNTIONALITY_DISABLED =3111;
public static final int QUICK_CHECKOUT_MOBILE = 8644;
/*Added for CR-2054-76630 Quick Checkout API - end*/

//Added For Bill Pay Through SMS START
public static final int MORE_THAN_ONE_PRESENTMENT =888888;
public static final int BILLPAY_NO_PRESENTMENT_BILLS =888889;
//Added For Bill Pay Through SMS END
//CR-2054-86484
public static final int LOANPAY_PAYMENT_PRODUCTID = 996092;
public static final int LOAN_PRODUCTID_LIST_NOT_AVAILABLE =995208;
//CR-2054-86484
public static final int EMANDATE_AVAILABLE_BAL = 14045;

public static final int ONLY_NUMBERS_FOR_POCKETS_PIN =999987;
public static final int ONLY_ALPHABETS_WITH_SPACES_STATE=999985;
public static final int ONLY_ALPHABETS_WITH_SPACES_CITY=999986;
public static final int PINCODE_LIST_NOT_AVAILABLE=999988;


  public static final int AMOUNT_BELOW_SIXTY = 996301;
  public static final int ESTIMATED_TOTALINCOME_NOT_LESS = 996302;
  public static final int AGGREGATE_AMOUNT_NOT_LESS = 996303;
  public static final int AMOUNT_BETWEEN_SIXTY_EIGHTY= 996304;
  public static final int AMOUNT_EIGHTY= 996305;
  public static final int INVALID_AMOUNT= 996400;
  public static final int EST_AMOUNT_NOT_GREATER=996306;
  public static final int AGG_AMOUNT_NOT_GREATER=996307;
public static final int MAX_ATTEMPTS_EXCEED= 999057;
public static final int BILLPAY_AUTOFLAG_PRESENTMENT_BILLS =888884;
public static final int ITRACK_NO_RECORDS_FOUND=8504;
public static final int BILL_CYCLE_NOT_ACCEPTED =200016;
public static final int BILL_CYCLE_DATE_NOT_VALID =200017;
public static final int BILL_CYCLE_DATE_INVALID =200018;
public static final int BILL_CYCLE_CHOOSING_DATE_INVALID =200019;
public static final int TOKEN_NOT_AVAILABLE=996219;
public static final int CHECK_VPA_AVILABLE_MSG =996220;
public static final int COUNTER_RESET_SUCCESSFUL=999058;
public static final int INVALID_AGE_RANGE_NPR=200020;
public static final int INVALID_BRNACH_NPR=200021;

public static final int MOBILE_LENGTH_NOT_PROPER=991007;
public static final int TRAVEL_CARD_UPDATE_PROFILE=999603;
public static final int TRAVEL_CARD_CHANGE_STATUS=999604;
public static final int TRAVEL_CARD_LINK_REQUEST=999605;
public static final int YEAR_MANDATORY_FIELD =8645;
	/*Added for LOMBARD Payment CR-2054-84963 -start*/
	public static final int INSERTION_FAILED_TO_LPDT =3117;
	public static final int LOMBARD_OTP_EXPIRED = 3118;
	public static final int LOMBARD_INVALID_DETAILS =3119;
	public static final int LOMBARD_INVALID_OTP =3120;
	public static final int LOMBARD_PAYMENT_DONE =3121;
	public static final int LOMBARD_NO_RECORD =3122;
	public static final int LOMBARD_INVALID_PRIMARY_ACC =3123;
	/*Added for LOMBARD Payment CR-2054-84963 -end*/
	public static final int FUNCTIONALITY_NOT_AVAIL_CREDITCARD= 99970;

public static final int INVALID_MOBILENO_NPR = 9994;
public static final int INVALID_TRAVEL_CARD = 999955;
public static final int TRAVEL_CARD_NO_SPECIAL_CHAR =999610;

	public static final int FAVOURITE_UBPS_DOWN= 99971;
public static final int MOTHER_NAME_NOT_VALID = 200023;
public static final int OFFICE_EXTN_NOT_VALID = 200024;
public static final int TRAVEL_CARD_CHANGE_STATUS_ACTIVE=999941;
public static final int TRAVEL_CARD_INVALID_PASSPORT =999611;
public static final int TRAVEL_CARD_CHANGE_STATUS_BLOCK=999942;
public static final int TRAVEL_CARD_CHANGE_STATUS_ALREADY_ACTIVE=999944;
public static final int TRAVEL_CARD_CHANGE_STATUS_ALREADY_BLOCKED=999943;
public static final int NPR_SR_SUCCESS_MESSAGE = 200025;
public static final int LTC_SR_SUCCESS_MESSAGE=146;
public static final int NO_RECORDS_FETCHED_TRAVEL_CARD =999055;
public static final int OFFICE_PIN_NOT_VALID =200026;
public static final int TRAVEL_CARD_CHANGE_STATUS_INACTIVE=999943;
public static final int INVALID_PASSPORT_NUMBER=999946;
public static final int ONLY_ALPHABETS_FOR_FIRST=999948;
public static final int SECOND_TO_EIGHT_TOBE_NUMERIC=999949;

public static final int DATEOFBIRTH_CHECK_ERROR = 777777;
public final static int SBN_TAI = 96561;
public final static int SBN_TNAI = 96562;
public final static int SBN_DATE = 96563;
public final static int SBN_PAN_ACK = 96564;
public static final int RESIDENTIAL_STATUS = 3124;
public static final int VISA_TYPE = 3125;
public static final int VISA_EXPIRY = 3126;
public static final int PIO_CHECKBOX = 3127;
public static final int SIGN_DOC_CHECKBOX = 3128;
public static final int VISA_ISSUE = 3131;
public static final int PASSPORT_NUMBER_INVALID = 956742;


public static final int PLACE_OF_ISSUE_INVALID = 956743;
public static final int FUTURE_DOI = 956744;
public static final int PAST_DOE = 956745;
public static final int MOBILE_NUMBER_INVALID = 956746;
public static final int CONTACT_NUMBER_INVALID = 956747;

public final static int SBN_TAI_NUMERIC = 96565;
public final static int SBN_TNAI_NUMERIC = 96566;
public static final int LOANBRANCH_ALREADY_EXISTS=112255;
public static final int AADHAR_CHECK_ERROR = 995028;
public static final int INVALID_UFS_Agric_income = 996555;
public static final int INVALID__UFS_pan_A = 996556;
public static final int INVALID__UFS_pan_D = 996557;
public static final int INVALID__UFS_pan_Both = 996558;
public static final int INVALID_UFS_Agric_negative = 996559;
public static final int INVALID_UFS_Agric_date = 996560;
public static final int INVALID_UFS_Father_Name = 996561;
public static final int INVALID_UFS_ACK_NO = 996572;
public static final int WRONG_MAIL_ID_FORMAT=987600;
public static final int BLANK_MOBILE_NUMBER = 965749;
public static final int BLANK_CONTACT_NUMBER = 965750;
public static final int FIELD_MAND_CODE = 100257;
public static final int JHA_NO = 3132;
public static final int JHA_NO_MAN = 3133;

public final static int SBN_PAN_CHECK = 96567;
public final static int SBN_PAN_VAL = 96568;
public static final int COMPANY_MAN = 3134;
public static final int COUNTRY_MAN = 3135;


public static final int FROM_DATE_BLANK = 3215;
public static final int TO_DATE_BLANK = 3216;
public static final int SPECIAL_CHARS_SBN_NOT_ALLOWED = 3136;
public static final int SBN_PAN_DATE = 96569;
public static final int SBN_PDF_VISA = 96570;
public static final int INVALID_UFS_Income_negative = 996573;
public static final int TC_ORDER_FETCH = 9099;
public static final int HOME_LOAN_ACCOUNT_LENGTH=996197;
public static final int INVALID_HOME_LOAN_ACCOUNT=996198;
public static final int HOME_LOAN_SHOULD_CONTAIN_ONLY_ALPHANUMERIC=996199;
public static final int OMNIDOCS_FAILURE = 96571;

//country restrict-NRI
public static final int SBN_COUNTRY_RESTRICT = 3137;

//JH restrict-NRI
public static final int SBN_JH_RESTRICT = 3138;
//upload format validation
public static final int SBN_UPLOAD_FORMAT_RESTRICT = 3139;
public static final int PROCESSING_ERROR_IN_SIPG_BATCH = 320001;
// added for Travel Card Start
	public static final int TRAVELCARD_DEACTIVE = 3150;
	public static final int TRAVELCARD_TRADE_STATUS_DEACTIVE = 3151;
	public static final int TRAVELCARD_PRODUCT_STATUS_DEACTIVE = 3152;
	public static final int TRAVEL_CARD_RETURN_DATE = 3153;
	public static final int TRAVEL_CARD_TRAVEL_DATE = 3154;
	public static final int PROMOCODE_INVALID = 3157;
	public static final int TRAVELCARD_CURRENCY_UNIT_INVALID = 3158;
	public static final int TRAVEL_DATE_NULL = 100257;
	public static final int TRAVEL_CARD_RETURN_VAL_DATE = 3159;
	public static final int TRAVEL_CARD_PASSPORT_EXPIRY_DATE = 3160;
	public static final int TRAVELCARD_TRADE_STATUS_CURR_TRADE_STATUS_DEACTIVE = 3161;
	public static final int TRADE_STATUS_DOWN_CURR_TRADE_STATUS_UP = 3162;
	public static final int TRADE_STATUS_UP_CURR_TRADE_STATUS_DOWN = 3163;
	public static final int PRODUCT_STATUS_DOWN_CURR_PRODUCT_STATUS_UP = 3164;
	public static final int PRODUCT_STATUS_UP_CURR_PRODUCT_STATUS_DOWN = 3165;
	public static final int CURRENCY_PRODUCT_STATUS_INACTIVE = 3166;
	public static final int TRAVEL_CARD_PRODUCT_STATUS_INACTIVE = 3167;
	public static final int TRAVEL_CARD_PCMS_PASS_PORT_RESPONSE = 3168;
	public static final int TRAVEL_CARD_CURRENCY_INACTIVE = 3169;
	public static final int PRODUCT_STATUS_DOWN_CURR_PRODUCT_STATUS_DOWN = 3170;
	public static final int TRAVEL_CARD_CURRENCY_UNITS_CHECK = 3171;
	public static final int TRAVEL_CARD_PASSPORT_EXPIRY_CHECK = 3172;
	public static final int TRAVEL_CARD_CURRENCY_DOB_CHECK = 3173;
	public static final int TRAVEL_CARD_DYNAMIC_ERROR_MESSAGE = 3174;
	public static final int TRAVEL_CARD_PASSPORT_EXPIRY_CHECK_RETURNDATE = 3175;
	public static final int TRAVEL_CARD_BUYRELOAD_DUPLICATE_CURRENCY_CHECK = 3178;
	// added for Travel Card END


	 public static final int INVALID_FATHER_MOTHER_NAME=996309;
public static final int INVALID_SSY_CERTIFICATION_NO=996310;
public static final int INVALID_SSY_ISSUING_AUTHORITY=996311;
public static final int INVALID_SSY_ID_DETAILS=996312;
public static final int MAN_DETAILS=996308;
public static final int CONFORM_LOAN_ACCOUNT_LENGTH=996195;
public static final int LOAN_ACCOUNT_RE_ENTER_LOAN_ACCOUNT=996196;
public static final int INTERNATIONAL_IMN_SHOULD__START_WITH_DOUBLE_ZERO = 996315;
public static final int VEHICLE_LOAN_SHOULD_CONTAIN_ONLY_ALPHANUMERIC=998651;
public static final int INVALID_VEHICLE_LOAN_ACCOUNT=998650;
public static final int VEHICLE_LOAN_ACCOUNT_LENGTH=998649;
public static final int VEHICLE_ACCOUNT_RE_ENTER_LOAN_ACCOUNT=998648;
public static final int MAX_UPLOADED_FILE_SIZE =888879;
public static final int CHECK_BOOK_ERROR =888880;
	/*Added for NPS E-sign -start*/
public static final int ESIGN_UPLOAD_FORMAT_RESTRICT = 3240;
/*Added for NPS E-sign -end*/
public static final int CHEQUE_BOOK_FAILED = 965767;
public static final int CHEQUE_BOOK_PENDING = 965757;
public static final int PINCODE_EXISTS = 999969;
public static final int ERROR_WHILE_UPLOADING_PDF = 923456;

/* added for FATCAnCRS_Validation_Updated */

public static final int INVALID_LENGTH_ID =996231;
public static final int CHAR_NOT_ALLOWED =996232;
public static final int NUMBER_NOT_ALLOWED =996233;
public static final int SPL_CHAR_NOT_ALLOWED =996234;
public static final int INVALID_ID =996235;
public static final int CTFD_LIST_VALUE = 996236;

public static final int CIBIL_REPORT_MANDATORY = 899025;
public static final int INVAL_TIN_NUM =996237;
public static final int SPL_NUMBER_NOT_ALLOWED =996238;



public static final int INVALID_EXP_DATE=3160;

public static final int INVALID_ISIN_INPUT=987601;




/*Added for local chq not credited SR  deliverables phase 3-start*/
public static final int WORKDAYS_NON_ICICI = 999886;
public static final int WORKDAYS_ICICI = 999887;
public static final int FUTURE_DATE_NOT_ALLOWED_FOR_DEPOSIT = 999888;
public static final int CHQ_NUM_NOT_NUMERIC = 999889;
public static final int CHQ_AMT_NOT_NUMERIC = 999890;
/*Added for local chq not credited SR -end*/

public static final int SR_FRM_LANDMARK=200029;




public static final int DRA_MSG_NRE=200032;
public static final int DRA_MSG_NRO=200033;
public static final int REDEMPTION_ACCOUNT_IS_JOINT=8162;
public static final int SIDT_ALREADY_UPDATED=987602;

public static final int DRA_MSG_NRO_NRE=200032;


public static final int PG_TO_EMI_CONVERT_ELIGIBILTY_CHECK = 3177;



public static final int AMOUNTLESS_INVALID_GPR = 814401;
public static final int AMOUNTMORE_INVALID_GPR = 814402;




public static final int INVALID_ECOL_PAYEE = 200058;

public static final int CFR_FD_GUADIAN_CODE_VAL =996696;
public static final int FREEZE_FD_CFR_ACCOUNT = 996691;

public static final int CFR_IMPROPER_FILE_CONTENTTYPE = 3139;
public static final int CFR_MAX_UPLOADED_FILE_SIZE = 200031;



public static final int ONLINE_IPO_DISABLED=8167;

public static final int CFR_FD_SCHEME_CODE_VAL = 996697;

public static final int MIN_FDNRIFCNR_CFR_ACCOUNT_CLOSE = 996694;

public static final int PPF_PAN_MANDATORY=200101;
public static final int PPF_ACCT_AADHAAR_MANDATORY=200102;
public static final int PPF_INITIAL_DEPOSIT_AMOUNT=200103;
public static final int PPF_AMOUNT=200104;
public static final int PPF_START_DATE=200105;
public static final int PPF_END_DATE=200106;
public static final int PPF_MOBILE_MANDATORY=200107;
public static final int PPF_INITIAL_DEPOSIT_AMOUNT_LESSTHAN = 200108;
public static final int PPF_INITIAL_DEPOSIT_AMOUNT_GREATERTHAN=200109;
public static final int PPF_AMOUNT_LESSTHAN=200110;
public static final int PPF_AMOUNT_GREATERTHAN=200111;
    public static final int INVALID_ISSUE_DATE=8176;
    public static final int SR_FRM_LOCALITY=8174;
    public static final int DRA_MAX_UPLOADED_FILE_SIZE=8175;
    public static final int DRA_CHECK_MOBNDC=8179;
    public static final int INVALID_VISA_ISSUE_DATE=8177;
    public static final int INVALID_VISA_EXP_DATE=8178;

  public static final int MAX_NO_OF_MONTHS_IS_60 = 996699;
public static final int INVALID_AGE_FOR_INSURANCE = 3183;
public static final int ICORE_DOWN_PA_POLICY_FAILED = 3185;

public static final int  INSERTION_FAILED_TO_PACT = 3181;
public static final int INVALID_FIFTEENGH_EMPLOYEE=996318;

public static final int DRA_INVALID_PASSPORT_NUMBER=956742;
public static final int INVALID_VISA_NUMBER=8180;

 public static final int NSDL_SERVER_DOWN = 8169;
    public static final int FI_SERVER_DOWN = 8170;
    public static final int ONLY_CAP_ALPHABETS_FOR_FOURTH_ONE = 8172;

public static final int  GPR_PAYMENT_FAL = 814404;
public static final int  GPR_PAYMENT_PROCESS_FAL = 814405;

	 public static final int SPL_CHAR_IPO = 200054;

public static final int MAX_AMOUNT_LESS_THEN_10Laks=996702; 
public static final int RTD_maturitydate=996698;

public static final int DRA_IMPROPER_FILE_CONTENTTYPE = 8181; 

public static final int INVALID_SEARCH_TEXT=987699;
public static final int  GPR_PAYMENT_SUC = 814408;
public static final int IPAY_INVALID_PRIMARY_ACC =996241;
public static final int NSDL_PANNO_WORNG = 8182;

public static final int DRA_IMPROPER_FILENAME=8183;
public static final int CUSTOM_INVALID_AMOUNT_PPF = 996708;
public static final int TC_TO_DATE_ERR=200041;
public static final int PPF_END_DATE_GREATERTHAN15=200601;


public static final int ACTIVE_DORMANT_ACCOUNT=996674;
public static final int ACTIVE_INACTIVE_ACCOUNT=996675;

public static final int TC_MOB_EMPTY = 200060;
public static final int TC_EMAIL_EMPTY = 200061;

public static final int INVALID_LOAN_ID = 888871;
public static final int ILOAN_DETAILS_NOT_FETCH = 888872;

	/* Added for Health Insurance - Srinivas Viswanath - START */
	public static final int HI_PLAN_NOT_FOUND = 9002;
	public static final int HI_PIN_CODE_MANDATORY = 9003;
	/* Added for Health Insurance - Srinivas Viswanath - END */
	public static final int HEALTH_INSURANCE_MANDATORY = 200601;
	public static final int HEALTH_INSURANCE_ADULT_DOB = 200602;
	public static final int HEALTH_INSURANCE_DOB_MANDATORY = 200603;
	public static final int HEALTH_INSURANCE_ADULT_RELATION = 200604;
	public static final int HEALTH_INSURANCE_GSTN_VAL = 200605;
	public static final int HEALTH_INSURANCE_NOMINEE_NAME_INVALID = 200605;
	
	
	public static final int MAIDNAME_MANDATORY=8186;
	public static final int SPOUCE_MANDATORY=8187;
	public static final int NAME_NOT_VALID=8188;
	public static final int FORM60_MAND=8190;
	public static final int RKC_COUNTRY = 8191;
	public static final int RKC_MAX_UPLOADED_FILE_SIZE=8192;
	public static final int RVISA_TYPE =8193;
	public static final int HEALTH_INSURANCE_NOMINEE_DOB_INVALID=91110;
	public static final int HEALTH_INSURANCE_CHILD_DOB = 200607;
	
	public static final int HEALTH_INSURANCE_AGE_INFO = 200701;
	public static final int HEALTH_INSURANCE_EXISTED_INFO = 200702;
	public static final int HEALTH_INSURANCE_EXIST_DESEASE_INFO = 200703;
	public static final int HEALTH_INSURANCE_BMI_INFO = 200704;
	public static final int HEALTH_INSURANCE_DISEASE = 200705;
public static final int ADA_INVALID_ACC=8185;
public static final int RESTRICT_NON_RESIDENT_INDIA=8199;
/* Added for Credit Card Empowerment */
public static final int TXN_CHANGE = 3192;
public static final int ESTATEMENT_MOBILE_NUMBER = 814406;
public static final int ESTATEMENT_EMAILD_ID = 814407;
public static final int ESTATEMENT_FROM_DATE = 814409;
public static final int ESTATEMENT_TO_DATE = 814410;
//userId Password added by Naidu
public static final int USPWD_DEBITCARD_NUMBER_MANDATORY = 999859;
public static final int USPWD_DEBIT_CARD_NUMBER_INVALID = 999858;
public static final int REST_OTHER_THAN_INDIA_FOR_RESIDENT=8129;
public static final int JET_PREVELIZE=996251;
//Travel card refund changes
public static final int TRAVELCARD_REFUND_AMOUNT = 814411;
public static final int TRAVELCARD_REFUND_AMOUNT_VALUE = 814414;

public static final int COUNTRY_PER_BANK_SEL_COUNTRY_MATCH=7161;
public static final int INVALID_STATEMENT_FROM_DATE = 7162;
public static final int INVALID_STATEMENT_TO_DATE=7163;
public static final int INVALID_TRANSACTION_DATE=7164;
public static final int INVALID_TRANSACTION_FROM_TO_DATE=7167;
public static final int INVALID_STATEMENT_TODATE_90DAYS = 7165;
public static final int INVALID_STATEMENT_PERIOD_90DAYS=7166;
public static final int INVALID_STATEMENT_TODATE_60DAYS = 7168;
public static final int INVALID_STATEMENT_PERIOD_60DAYS=7169;
public static final int INVALID_STATEMENT_FROMDATE_TODATE=7170;
public static final int RKC_FILEUPLOAD_JOIN2=8194;
public static final int BRANCH_LIST_NOT_AVAILABLE=996256;
	public static final int PAYEMENT_DATE_MANDATORY=994355;

public static final int IWISH_ADDFUNDS_MANDITORY = 8200;
public static final int IWISH_ADDFUNDS_ONLY_CHARACTERS = 8201;
public static final int IWISH_ADDFUNDS_AVAILABLE_BAL = 8202;
public static final int IWISH_ADDFUNDS_TARGETAMOUNT_BAL = 8203;
public static final int FILE_PREVIEW_CHECK=8205;
 public static final int FILE_PASSWORD_PROTECTED=8206;
public static final int INVALID_PASSPORT_ISSUED_DATE = 200028;
public static final int CFR_PASS_MAX_UPLOADED_FILE_SIZE = 996715;
public static final int  IWISH_AMOUNTVAL_CHECK = 996707;
public static final int STATUS_OF_TRANSACTION_DATE= 996359;
public static final int IWISH_RECURRING_DEPOSIT_VAL = 8220;
public static final int IWISH_INTIALAMOUNTVAL = 8215;
public static final int IWISH_RECURRING_VAL = 8208;
public static final int ACCOUNT_IS_DORMANT_STATUS=8012;
public static final int ACCOUNT_IS_INACTIVE_STATUS=8013;
public static final int ACCOUNT_HAVE_INSUFF_BAL=8014;
public static final int NUMERIC_PIN = 999913;

public static final int LOCALITY_INVALID = 77095;
public static final int LANDMARK_NEW_INVALID = 77096; 
public static final int FLOOR_NUMBER_NEW_INVALID = 77097;
public static final int STREE_ROAD_NEW_NUMBER_INVALID = 77098;
public static final int IS_SIP_DOWN_TIME=996267;

public static final int HEALTH_BOOSTER_MANDATORY = 200711;
public static final int HEALTH_BOOSTER_CHILD_DOB = 200712;
public static final int HEALTH_BOOSTER_ADULT_DOB = 200713;
public static final int HEALTH_BOOSTER_DOB_MANDATORY = 200714;
public static final int HEALTH_BOOSTER_ADULT_RELATION = 200715;
public static final int HEALTH_BOOSTER_NOMINEE_NAME_INVALID = 200716;
public static final int HEALTH_BOOSTER_NOMINEE_DOB_INVALID=200717;
public static final int HEALTH_BOOSTER_AGE_INFO = 200718;
public static final int HEALTH_BOOSTER_EXISTED_INFO = 200719;
public static final int HEALTH_BOOSTER_EXIST_DESEASE_INFO = 200720;
public static final int HEALTH_BOOSTER_BMI_INFO = 200721;
public static final int HEALTH_BOOSTER_DISEASE = 200722;
public static final int HEALTH_BOOSTER_ALREADY_INSURED = 200723;
public static final int HEALTH_BOOSTER_INSURED_NAME_INVALID = 200724;
//added for travel Insurance changes Start
	public static final int TI_TRIP_START_DATE_VAL1=7001;
	public static final int TI_TRIP_START_DATE_VAL2=7002;
	public static final int TI_TRIP_END_DATE_VAL1=7003;
	public static final int TI_MULIT_TRIP_EXISTING_POLICY=7005;
	public static final int TI_SINGLE_TRIP_EXISTING_POLICY=7004;
	public static final int TI_PRE_EXIST_DISEASE_VAL=7006;
	public static final int TI_AGE_LIMIT_VAL=7007;
	public static final int TI_AGE_SIMILAR_PASSPORT_VAL=7008;
//added for travel Insurance changes End
public static final int INVALID_ACC_INSTAPL=8016;
  public static final int FEEDBACK_VALUE_EXCEEDS = 108501;
public static final int UNABLE_TO_FETCH_PORTFOLIO=996268;
public static final int UNABLE_TO_FETCH_PROFILE=996269;

public static final int HEALTH_INSURANCE_ALREADY_INSURED = 7020;
public static final int PLCC_WTL_OFFER_NOT_ELIGIBLE = 8018;
public static final int INVALID_TRANSACTION_DATE_TWO=7177;
public static final int INV_STATEMENT_PERIOD_THREE_MONTHS=7178;
public static final int INVALID_DRIVING_EXPIRY_DATE=7180;
public static final int INVALID_STATEMENT_FOR_TWO_MONTHS=7181;
public static final int INV_STATEMENT_RECENT_OLDER_PERIOD=7179;
public static final int INVALID_STATEMENT_ONE_MONTH=7182;
public static final int INVALID_STATEMENT_TWO_MONTHS=7183;
public static final int INV_STAT_RECENT_THREE_MONTHS_PERIOD=7184;
public static final int INV_STAT_ONE_TWO_MONTH=7185;
public static final int COINTRIBE_SERVER_DOWN=996278;
public static final int CAR_MOP=996280;


	/* Added by Srini K for Offers CR - Start */
	public static final int INVALID_WFCODE = 999917;
	public static final int INVALID_OFFERCODE = 999915;
	public static final int TECHNICAL_EXCEPTION = 999916;
	public static final int NO_OOFERS_FOR_MOB_LOPID = 999968;
	public static final int INVALID_REQUEST_ID = 999918;
public static final int XSERVICE_OFFER_EXCEEDED_ELIGIBLEAMT = 999919;
public static final int INVALID_OFFER = 999914;
public static final int  EXISTINGLOAN_WITH_CRM_REQ_ID_NOT_EXPIRED  = 996279;
public static final int CRM_REQUEST_ID_EXPIRED =996289;
	/* Added by Srini K for Offers CR - End */


/* Added by Srini K for Digital Gold CR - Start */
	public static final int SAFEGOLD_EXCEPTION = 999892;
	public static final int SAFEGOLD_NO_RESPONSE = 992098;
	public static final int SAFEGOLD_EXCEPTION_CARDS = 992099;
	public static final int SAFEGOLD_EXCEPTION_STATUS = 998665;
/* Added by Srini K for Digital Gold CR - End */
/* Added by Sridevi for Digital Gold CR - Start */
	public static final int SAFEGOLD_BUY_MIN_AMOUNT_VALUE = 992101;
	public static final int SAFEGOLD_BUY_MIN_WEIGHT = 992102;
	public static final int SAFEGOLD_BUY_MAX_WEIGHT = 992103;
	public static final int SAFEGOLD_SELL_MIN_AMOUNT_VALUE = 992104;
	public static final int SAFEGOLD_SELL_MIN_WEIGHT = 992105;
	public static final int SAFEGOLD_SELL_MAX_WEIGHT = 992106;
/* Added by Sridevi for Digital Gold CR - End */
public static final int ADA_FI_SUCCESS=996276;
public static final int ADA_FI_FAILURES=9000;
public static final int ADA_NO_ACCOUNTS=996280;

public static final int INVALID_RD_MONTHLY_AMOUNT = 995469;
public static final int MAX_TENURE_FOR_RD_MONTHLY =995470;
public static final int MIN_TENURE_FOR_RD_MONTHLY = 995471;
public static final int MAXIMUM_FDMI_AMOUNT_SPECIAL_CHARACTER = 995475;
public static final int MAXIMUM_FDMONTHLY_AMOUNT_ERROR = 995476;
public static final int MAXIMUM_FDMITENURE_ERROR = 995477;

public static final int CUSTOM_FAMILY_DETAILS_MISMATCH = 89556;
public static final int CUSTOM_FAMILY_INVALID_REQUEST = 89557;
public static final int CUSTOM_FAMILY_UPDATE_EMAILID = 89558;
public static final int CUSTOM_FAMILY_SURNAME_VAL = 89560;
public static final int RKC_FILEUPLOAD_ONE_HUN=8490;
public static final int RKC_FILEUPLOAD_TWO_HUN=8491;
public static final int RKC_FILEUPLOAD_THREE_HUN=8492;
public static final int RKC_FILEUPLOAD_FOUR_HUN=8493;
public static final int RKC_FILEUPLOAD_SIX_HUN=8494;
public static final int RKC_FILEUPLOAD_ELEVEN_HUN=8495;

public static final int PENSION_KYC = 8006;
public static final int PENSION_PHOTO = 8005;
	
	/* Added by Srini K for Joint Account holder service - Start */
	public static final int NO_ACMT_FOR_ACMS_INSERTION = 993017;
	public static final int CUST_EXISTS_FOR_ACMS_INSERTION = 993018;
	/* Added by Srini K for Joint Account holder service - End */
public static final int MANDATORY_MOBILENO=996299;
public static final int INVALID_MOBILENO=997250;
public static final int UPDATED_MOBILENO_SUCCESS=996297;
public static final int UPDATED_MOBILENO_FAILURE=996298;

public static final int PLCC_BT_OFFER_NOT_ELIGIBLE = 8020;
public static final int OTH_BNK_CC_NUM_MANDATORY = 8021;
public static final int CNF_OTH_BNK_CC_NUM_MANDATORY = 8022;
public static final int OTH_BNK_NAME_MANDATORY = 8023;
public static final int OTH_BNK_IFSC_CODE_MANDATORY = 8024;
public static final int CUST_NAME_ON_CARD_MANDATORY = 8025;
public static final int CNF_AND_OTH_BNK_CC_NUM_MISMATCH = 8026;

public static final int OTH_BNK_CC_NUM_ONLY_NUMBERS_ALLOWED = 8027;
public static final int CNF_OTH_BNK_CC_NUM_ONLY_NUMBERS_ALLOWED = 8028;
public static final int OTH_BNK_NAME_ONLY_ALPHABETS_ALLOWED = 8029;
public static final int OTH_BNK_IFSC_CODE_ONLY_ALPHANUMERIC_ALLOWED = 8030;
public static final int CUST_NAME_ON_CARD_ONLY_ALPHABETS_ALLOWED = 8031;

public static final int INVALID_CC_LENGTH = 8032;
public static final int INVALID_IFSC_LENGTH = 8033;
public static final int TWLOAN_CIBIL_FAILURE = 999118; 
public static final int TWLOAN_CONNECTION_ERROR = 999119;
 public static final int TCS_CIBIL_FAILURE = 999120;
 public static final int TCS_CITY_REQ_FAILURE = 999121;
 public static final int TCS_DEALER_FETCH_FAILURE = 999122;
 public static final int CUSTNAME_ALPHANUMERIC_ALLOWED = 999117;
public static final int AADHAAR_NUMBER_REQD = 999111;

public static final int AADHAAR_NUMBER_NUMERIC = 999112;
public static final int PAY_ACC=996292;

public static final int SELECT_ACCOUNT_NUMBER=8466;
public static final int REMITTER_NAME_MANDATORY=8467;
public static final int INVALID_REMITTER_NAME = 8468;
public static final int SELECT_COUNTRY_NAME = 8469;
public static final int REMITTER_EMAILID_MANDATORY = 8470;
public static final int RQST_AMOUNT_MANDATORY = 8471;
public static final int INVALID_REQUEST_AMOUNT = 8472;
public static final int MORE_OPEN_STATUS_REQUEST = 8473;

public static final int STIR_SUCCESS_RESPONSE=8441;
public static final int STIR_FAILURE_RESPONSE=8442;
public static final int INVALID_FIRST_NAME = 8443;
public static final int INVALID_ACCOUNT_NUMBER_FIFTH_DIGIT = 8444;
public static final int INVALID_COUNTRY_CODE = 8445;
public static final int RESP_INVALID_STATE = 8446;
public static final int RESP_INVALID_ADDRESS1 = 8447;
public static final int RESP_INVALID_CITY = 8448;
public static final int RESP_INVALID_ZIPCODE=8449;
public static final int RESP_INVALID_LANDLINE=8450;
public static final int RESP_INVALID_MOBILENO = 8451;
public static final int RESP_INVALID_EMAIL = 8452;
public static final int RESP_INVALID_NICKNAME = 8453;
public static final int RESP_INVALID_CHANNELID = 8454;
public static final int INVALID_SRNO = 8455;
public static final int RESP_INVALID_REMITTER_NAME = 8456;
public static final int RESP_INVALID_PROCESSDATE=8457;
public static final int RESP_INVALID_INITIATEDATE=8458;
public static final int RESP_INVALID_STATUS = 8459;
public static final int RESP_INVALID_LASTNAME = 8460;
public static final int RESP_PARAMETERS_NULL = 8461;
public static final int INVALID_RQST_AMOUNT = 8462;
public static final int ALREADY_EXISTS_ACCOUNTNUMBER = 8463;
public static final int INVALID_REMITTER_EMAILID = 8464;
public static final int REMITTER_EMAILID_ALREADY_EXISTS = 8465;

public static final int INVALID_STIR_RESPONSE = 8474;
public static final int RQSTMONEY_CONNECTION_ERROR = 8475;
public static final int OPEN_STATUS_REQUESTS =8476;

public static final int PURPOSE_OF_REQ_MAND =8477;
public static final int UNIQUE_EMAIL_ID_MAND =8478;
public static final int XSERVICE_INVALID_LOP_RESPONSE = 999927;
public static final int BRE_TECH_ERROR = 8582;
public static final int INCORRECT_AMOUNT_AND_TENURE = 8002;
public static final int BUREAU_ONE_FAIL = 8003;
public static final int DORMAT_ACCOUNT=899008;
public static final int CLOSED_ACCOUNT=642;
public static final int ALPHANUMERIC_ZIP_CODE = 21389;

/* Added by Srini K for BBPS API Integration CR - Start */
	public static final int BBPS_NO_RESPONSE = 201;
	public static final int BBPS_PAYMENT_SUCCESS = 202;
	public static final int BBPS_PAYMENT_FAILURE = 203;
	public static final int BBPS_PAYMENT_INPROGRESS = 204;
	public static final int BBPS_INCORRECT_RESPONSE_CODE = 205;
	
	public static final int BBPS_TXNREFID_INVALID = 206;
	public static final int BBPS_BILFETCH_INVALID = 267;
	public static final int BBPS_PAYMENT_INCORRECT_STATUS = 309;
	public static final int BBPS_CUST_PARAMS_INVALID = 329;
	public static final int BBPS_BILFETCH_DEUDATE_EXPIRY = 328;
	
	public static final int BBPS_MOD_SUCCESS = 994051;
	public static final int BBPS_MOD_FAILURE = 994052;
	public static final int BBPS_STP_SUCCESS = 994053;
	public static final int BBPS_STP_FAILURE = 994054;
	
	
	public static final int BBPS_REG_MOD_SUCCESS = 994055;
	public static final int BBPS_REG_MOD_FAILURE = 994056;
	public static final int BBPS_REG_DEL_SUCCESS = 994057;
	public static final int BBPS_REG_DEL_FAILURE = 994058;
	
	public static final int BBPS_PAYMENT_SCHEDULED = 994059;
	public static final int BBPS_REGISTRATION_ALREADY_DONE = 994060;
	public static final int BBPS_NO_BILL_DUE = 994061;
	public static final int BBPS_BILL_FETCH_GEN = 7144;
	
	public static final int BBPS_INSTALLMENTS_MANDATORY = 994065;
	/* Added by Rahul for BBPS API Integration  */
	public static final int BBPS_SI_MOD_SUCCESS = 368;
	public static final int BBPS_SI_MOD_FAILURE = 369;
	public static final int BBPS_SI_DEL_SUCCESS = 372;
	public static final int BBPS_SI_DEL_FAILURE = 371;
	public static final int BBPS_REG_SI_FAILED = 414;
	
	/* Added by Rahul for BBPS API Integration */
/* Added by Srini K for BBPS API Integration CR - End */
	
public static final int RMS_CUST_NAME = 996326;
public static final int RMS_PRU_NAME = 996327;
public static final int RMS_CUS_NAME = 996328;
public static final int RMS_EMI_AMOUNT = 996329;
public static final int PRE_EMI = 996320;
public static final int SR_DUE_DATE = 996336;
public static final int ROBO_INVALID_REDEMPTION_ACCOUNT=996369;
public static final int  ROBO_INVALID_TOKEN= 996370;
public static final int TWO_COUNTRYS_SHOULD_MATCH = 8299;
public static final int MINIMUM_PFC_FD_AMOUNT_ERROR = 995036;
public static final int MAXIMUM_PFC_FD_AMOUNT_ERROR = 995037;
public static final int CUMMU_NRO_TENURE_MONTHS_MIN= 993989;
public static final int TRADE_NRO_TENURE_MONTHS_MIN = 993999;
public static final int OADT_INSERTION_FAILED = 8582;
public static final int CUSTOM_SHP_REV_NO_PAYMENT_ID =996998;
public static final int PAGE_WISE_MAX_UPLOADED_FILE_SIZE = 999924;

public static final int INSTAHL_LAN_NOT_ACTIVE = 996337;
public static final int INSTAHL_INVALID_RESPONSE = 996338;

public static final int INVALID_MINOR_DOB=8601;
public static final int INVALID_MAJOR_DOB=8602;
public static final int INVALID_SENIOR_DOB=8603;
public static final int RKU_SINGLE_FILE_SIZE=8605;
public static final int RKU_MUL_FILE_SIZE=8606;
public static final int RKU_EMAILID=8607;
public static final int RKU_MOBILE=8608;
public static final int RKU_CHECKBOX=8609;
public static final int RKU_DOB=8610;
public static final int RKU_PAN_DOB=8611;
public static final int RKU_ADDRESS=8612;
public static final int RKU_DOB_EDIT=8613;
public static final int RKU_EDIT_ADDRESS=8614;
public static final int RKU_EDIT_PINCODE=8615;
public static final int RKU_PHOTO=8616;
public static final int RKU_FILE_ERROR=8617;

public static final int IPRU_BALANCE_VAL=8805;

public static final int MAXIMUM_FDMI_AMOUNT_ERROR = 995476;

//added by shraddha for direct tax payment when challan number exceeds 99999
public static final int CHALLAN_NUMBER_EXCEEDS = 2205;

public static final int RKU_IMPROPER_FILENAME=8618;
   public static final int NRI_KYC_INVALID_ACCOUNT_ID = 8225;
   
     public static final int IPRU_MAX_BALANCE_VAL=996629;
    public static final int APPONITE_NAME_CHECK=996630;
    public static final int APPONITE_DOB_CHECK=996631;
    public static final int NOMINEE_DOB_CHECK=996632;
    public static final int APPONITE_NAME_ONLY_ALPHABETS=996633;
	public static final int RKC_MULTIPLE_FILE_PAGE_LIMIT = 996634;

	
	public static final int RKU_AADHAR_CHECKBOX=8619;
	public static final int REFERRAL_CODE_ALPHANUMERIC_ALLOWED = 999210;

	
	//added for Nomination on RIB CR-2054-130604 
	public static final int NOMINEE_MINOR_SELECTION = 996383;
public static final int NOMINEE_MAJOR_SELECTION = 996384; 
public static final int NOMINEE_NAME_NEW_INVALID = 996388;
public static final int GUARDIAN_NAME_NEW_INVALID = 996389;
public static final int NOMINEE_FLOOR_NUMBER_NEW_INVALID = 996392;
public static final int NOMINEE_PREMISE_BUILDING_NAME_INVALID = 996393;
public static final int NOMINEE_STREET_ROAD_NAME_INVALID = 996394;
public static final int GUARDIAN_FLOOR_NUMBER_NEW_INVALID = 996395;
public static final int GUARDIAN_PREMISE_BUILDING_NAME_INVALID = 996403;
public static final int GUARDIAN_STREET_ROAD_NAME_INVALID = 996405;

public static final int DEPXSER_ACCOUNTNO_MANDITORY=996639;
public static final int DEPXSER_ID_MANDITORY=996640;
public static final int DEPXSER_TY_MANDITORY=996641;
public static final int DEPXSER_TM_MANDITORY=996642;
public static final int DEPXSER_TD_MANDITORY=996643;
public static final int COMP_FLY_ENC_ERROR = 8622;
public static final int DEPXSER_RD_MUTLTYOFTHREE =996640;
/* DMT Fields */
public static final int DMT_MOBILE = 200107;
public static final int DMT_EMAIL = 995990;
public static final int DMT_RADIO_BOX = 8620;
public static final int DMT_RADIO_NO = 8621;
/* DMT Fields*/

public static final int INVALID_MOP = 996120;

//added by divyanshu for fastag recharge 
public static final int INVALID_MIN_VEHICLERECHARGE_AMOUNT = 1260;
public static final int INVALID_MAX_VEHICLERECHARGE_AMOUNT = 1270;
public static final int INVALID_MIN_ONEWALLET_AMOUNT = 1280;
public static final int INVALID_MAX_ONEWALLET_AMOUNT = 1310;
public static final int RECHARGE_AMOUNT_NULL = 1411;
public static final int INVALID_VEHICLE_NUMBER=1412;
public static final int INVALID_CUSTOMER=1413;


public static final int  DBT_COMMON_ERROR=996431;
public static final int  DBT_AADHAR_NUM=996432;
public static final int  DBT_AADHAR_LEN=996433;
public static final int  DBT_INVALID_OTP_CONTENT=996434;
public static final int  DBT_INVALID_OTP_LENGTH=996435;
public static final int  DBT_INVALID_OTP_ERROR=996436;
public static final int  DBT_OTP_SUCCESSFUL=996437;
public static final int  DBT_DATA_MATCHED=996438;
public static final int  DBT_DATA_NOT_MATCHED=996439;
public static final int  DBT_INVALID_AADHAAR=996440;
public static final int  DBT_RADIO_BOX=996441;
public static final int  DBT_AADHAR_ALREADY_MAPPED=996444;

//added for quickcheckout account authentication START
public static final int QUICK_CHECKOUT_ACC_VERIFICATION = 4045;
//added for quickcheckout account authentication END

//ADDED FOR NRI ADD PAYEE MOBILE COOLING PERIOD START 
 public static final int MOBILE_COOLING_PERD_BEFORE_ADD_PAYEE_NRI = 999820;
//ADDED FOR NRI ADD PAYEE MOBILE COOLING PERIOD END
public static final int RKU_AADHAAR = 8626;

public static final int OAP_URLGEN_ERROR = 999126;

public static final int ED_URLGEN_ERROR = 999130;

public static final int OD_MANDITORY_CHECK=8809;
public static final int OD_LIEN_ACCOUNT_CHECK=8810;
public static final int OD_LIMIT_AVAILABILITY_CHECK=8811;
public static final int COLLATERAL_CHECK=8812;
public static final int LINKEDFD_CHECK=8813;
public static final int OD_ACCOUNT_CHECK=8814;
public static final int  INVALID_INPUT = 87653;
public static final int NO_DEBIT_CARD_ACCOUNTS=1272;
public static final int PAYMENT_BILLER_CANNOT_BE_MODIFIED=418;
public static final int TXN_LMT_UPDATE_LMTSCH_MANDATORY=500000;
public static final int MANDATORY_FIELDS_CANNOT_BE_NULL=500001;
public static final int BBPS_PAYMENT_ERROR_FROM_RESPONSE=500002;
public static final int IMPS_FT_INVALID_TO_ACCOUNT=500003;
public static final int UNABLE_TO_FETCH_ROI = 500011;
public static final int INVALID_DATE_BBPS_PAYMENT = 500012;

public static final int OTFT_TO_ACCOUNT_ID_MANDATORY = 500500;
public static final int BBPS_INVALID_ACCOUNT = 500004;

/*Added for UPI - START*/
public static final int MOBILE_NUMBER_MANDATORY = 500021;
public static final int ACCOUNT_NUMBER_MANDATORY = 500022;
public static final int ACCOUNT_NUMBER_INVALID = 500023;
public static final int MOBILE_NUM_NOT_REGISTERED = 500024;
public static final int FAILURE_HOST_RESPONSE = 500025;
public static final int TRANSACTION_FROM_DATE_MANDATORY = 500026;
public static final int TRANSACTION_TO_DATE_MANDATORY = 500027;
/*Added for UPI - END*/
public static final int ERROR_OCCURED_WHILE_DELETING_PAYEE = 500028;
public static final int NO_RECORD_FETCHED = 500030;
public static final int INVALID_CRITERIA = 500031;
public static final int NO_CRITERIA_SELECTED = 500032;
public static final int REMARKS_NOT_ENTERED = 500033;
public static final int OTFT_TXN_PROCESSED_ALREADY = 500035;
//added for block debit card
public static final int SR_BLOCK_DC_BLOCK_TYPE = 500036;
public static final int SR_BLOCK_DC_BLOCK_REASON = 500037;


public static final int MAX_MULTI_TXN =20215;
public static final int MAX_MULTI_AMT = 20212;
public static final int CARD_MULTI_TXN = 20213;
public static final int TENURE_MULTI_TXN = 20214;
//mutual funds
public static final int SIPINVEST_SERVICE_UNAVAILABE = 999711;


//added for SBNInitate
public static final int SBN_IMPROPER_FILE_CONTENTTYPE= 648563;

	}


