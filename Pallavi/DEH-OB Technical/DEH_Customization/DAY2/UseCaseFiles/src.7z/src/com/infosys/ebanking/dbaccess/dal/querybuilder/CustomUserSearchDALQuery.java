/**
 * CustomUserSearchDALQuery.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.infosys.ebanking.dbaccess.dal.querybuilder;

import com.infosys.feba.framework.common.exception.DALException;
import com.infosys.feba.utils.insulate.HashMap;
import com.infosys.feba.framework.dal.AbstractQuery;
import com.infosys.feba.framework.types.FEBATypesUtility;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.types.FEBAStringBuilder;
import com.infosys.feba.framework.types.IFEBAType;
import com.infosys.feba.framework.types.primitives.IFEBAPrimitive; 
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject; 
import com.infosys.feba.framework.types.primitives.FEBAAString;
import com.infosys.feba.framework.common.util.resource.PropertyUtil;
import com.infosys.feba.framework.sql.DBDateUtil;
import 
					com.infosys.feba.framework.types.primitives.FEBAUnboundString
				;

/**
 * This Query class is responsible for preparing the query and setting the data in the query dynamically
 * @author DalGenerator
 * @version 1.0
 * @since FEBA 2.0
 * Generated on :: Tue, Nov 23, 2021 
 */
public class CustomUserSearchDALQuery extends AbstractQuery {

	/** declaration of private variables to represent columns being queried on **/	
	
		private FEBAUnboundString   userId;


	/**
	 * Method to pass values to the query file in key-value format
	 *
	 * @param sFieldName
	 * @param objFieldValue	
	 * @see com.infosys.feba.framework.dal.IFEBAQuery#setFieldByName(java.lang.String,
	 *      com.infosys.feba.framework.types.IFEBAType)	 
	 */
	public void associate(String sFieldName, IFEBAType objFieldValue) {
		
		
		if (sFieldName.equals("userId")) {
			this.userId = (FEBAUnboundString) objFieldValue;				
		}
	}

	/**
	 * Responsible to prepare the FEBAStringBuilder that has the query
	 * 
	 * @param context
	 * @return	
	 * @see com.infosys.feba.framework.dal.AbstractListQuery#prepareQuery(com.infosys.feba.framework.tao.FEBATransactionContext)	 
	 */
	protected FEBAStringBuilder prepareQuery(FEBATransactionContext context) {
	
		FEBAStringBuilder queryString = new FEBAStringBuilder(116);
		int arrayListSize = 0;
		boolean conditionCheck = false;
queryString.append("Select "); 
	if(PropertyUtil.getProperty("RDBMS_TYPE",context).equalsIgnoreCase("ORACLE")){
	if(PropertyUtil.getProperty("ORACLE_COMPATIBLE_TYPE",context).equalsIgnoreCase("EDB")){
queryString.append(" USER_ID, MOB_NUM, EMAIL_ID");
	} else {
queryString.append(" USER_ID, MOB_NUM, EMAIL_ID");
	} 

	} else {
queryString.append(" USER_ID, MOB_NUM, EMAIL_ID");
	} 

queryString.append(" from ");
queryString.append("UCDT");
 if( FEBATypesUtility.isNotNullOrBlank(userId) ) 
 { 
queryString.append(" where ");

if( FEBATypesUtility.isNotNullOrBlank(userId) ) {
queryString.append("USER_ID = ?");

conditionCheck = true;
} 
 }

		return queryString;		
		
	}

	/**
	 * Responsible for setting data in the query dynamically	 
	 *
	 * @param context	 
	 * @see com.infosys.feba.framework.dal.AbstractListQuery#setQueryParameters(com.infosys.feba.framework.tao.FEBATransactionContext)
	 */
	protected void setQueryParameters(FEBATransactionContext context) throws DALException{
		int counter = 0;
		int arrayListSize = 0;
		
if (FEBATypesUtility.isNotNullOrBlank(userId) ) {
setParameterInQuery(++counter , userId, context );
}

	}	
	    
}
