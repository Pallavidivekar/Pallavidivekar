package com.custom.ebanking.rest.common.v2;
import java.util.Set;

import com.infosys.ebanking.rest.common.v1.IRestResourceConfiguration;
//import com.custom.ebanking.users.api.retail.v2.resources.CustomFetchAuthModesResource;
//import com.custom.ebanking.users.api.retail.v2.resources.CustomSBAcctAddResource;
import com.custom.ebanking.users.api.retail.v2.resources.CustomUserContactRetailResourceV2;




public class CustomRetailResourceConfiguration implements IRestResourceConfiguration{

	@Override
	public void resourceConfigurationReader(Set<Class<?>> classes) {
		// TODO Auto-generated method stub
		
		classes.add(CustomUserContactRetailResourceV2.class);
	//	classes.add(CustomSBAcctAddResource.class);
	//	classes.add(CustomFetchAuthModesResource.class);

	}

}
