package com.custom.ebanking.service;

import com.infosys.feba.framework.common.exception.*;
import com.infosys.feba.framework.transaction.pattern.AbstractLocalListInquiryTran;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.feba.framework.dal.QueryOperator;
import com.infosys.feba.framework.valengine.FEBAValItem;

import com.infosys.ebanking.types.valueobjects.CustomUserSearchCriteriaVO;
import com.infosys.ebanking.types.valueobjects.CustomUserSearchEnquiryVO;

public class CustomUserSearchServiceSearchUsersImpl extends
		AbstractLocalListInquiryTran {
	/*The invoke method of this transaction pattern calls six template methods.
	* 1. getTransactionWM() - fetches the Value Object implementing
	* IFEBAValueOject representing the working memory for passing data between
	* the template methods. 2. validateData() - validates inputs to the
	* transaction. 3. validateBusinessRules() - executes business rules. 4.
	* executeQuery() - The DAO call to fetch the list of records matching the
	* criteria is made in this method. Pagination logic is also handled here.
	* Elements are added to the response Array List if post Query method
	* returns true. 5. postQuery() - The response ArrayList element ie: an
	* implementation of IFEBAvalueObject is populated from the DB resultset in
	* this method. Additional data required is fetched/computed in this method.
	* Any filtering criteria to ascertain if the list element is to be added to
	* the response Array list is also applied in this method. 6. postProcess() -
	* transaction chaining is done from this method ie: if another transaction
	* implementation class is to be invoked at the end of the current
	* transaction - the transaction class is directly invoked from the
	* implementer of this method.*/
	protected void executeQuery(FEBATransactionContext objContext,
			IFEBAValueObject objInputOutput, IFEBAValueObject objUsr)
			throws BusinessException, BusinessConfirmation, CriticalException {

		CustomUserSearchEnquiryVO ucVO = (CustomUserSearchEnquiryVO) objInputOutput;
		super.executeQuery(objContext, ucVO, objUsr);
	}
	
	public void associateQueryParameters(FEBATransactionContext objContext,
			IFEBAValueObject objInputOutput, IFEBAValueObject objUsr, QueryOperator usrId)
			throws CriticalException {

		CustomUserSearchCriteriaVO ucCritVO = (CustomUserSearchCriteriaVO) objInputOutput;
		usrId.associate("userId", ucCritVO.getUserId());

	}
	

	public FEBAValItem[] prepareValidationsList(FEBATransactionContext objContext,
			IFEBAValueObject objInputOutput, IFEBAValueObject objUsr)
			throws BusinessException, BusinessConfirmation, CriticalException {
		/*FEBAValEngineConstants.MANDATORY / FEBAValEngineConstants.NON_MANDATORY
		This is used when we want to throw mandatory validation directly. i.e you dont have to create an exception.
	 	Just give which field and configure as Mandatory, remaining ValEngine will take care.
		FEBAValEngineConstants.INDEPENDENT / FEBAValEngineConstants.DEPENDENT
		This Dependent is used when the validation item you are writing is directly dependent on the previous valitem in the list.*/
		/*
		
		CustomUserSearchCriteriaVO ucVO = (CustomUserSearchCriteriaVO)objInputOutput;
		//params - Object to be validated, Type of Validation to be done(MANDATORY) or pass Validator Name , order of Validation(INDEPENDENT or DEPENDENT), ErrorCode
		FEBAValItem valItemList[] = new FEBAValItem[] {
						new FEBAValItem("userId",
								ucVO.getUserId(),
								FEBAValEngineConstants.MANDATORY,
								FEBAValEngineConstants.INDEPENDENT,
								102744)
	
		};
		return valItemList;*/
		return null;

	}


	public String getQueryIdentifier(FEBATransactionContext objContext,
			IFEBAValueObject objInputOutput, IFEBAValueObject objUsr) {
		return "CustomUserSearchDAL";
	}
	
	 public final void postProcess(
	    	    FEBATransactionContext objContext,
	    	    IFEBAValueObject objInputOutput,
	    	    IFEBAValueObject objUsr)
	    	    throws BusinessException,
	    	    BusinessConfirmation,
	    	    CriticalException 
	 {
		 
		 
	 }
	
}