package com.custom.ebanking.users.api.retail.v2.pojo;



import java.util.List;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.infosys.feba.framework.interceptor.rest.pojo.RestHeaderFooterHandler;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author Nidhi Zachariah
 * This is the VO which holds the input fields for the user details.
 *
 */
@ApiModel(value="User Details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)

public class CustomUserContactsListDetailsResponseVOV2 extends RestHeaderFooterHandler {

	
	private List<CustomUserContactListDetailsVOV2> userList;
	
	@ApiModelProperty(value = "This field holds user list")
	
	public List<CustomUserContactListDetailsVOV2> getUserList() {
		return userList;
	}

	public void setUserList(List<CustomUserContactListDetailsVOV2> userList) {
		this.userList = userList;
	}

	
	
}

