/**
 * CustomUserSearchDALDataBuilder.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.infosys.ebanking.dbaccess.dal.databuilder;

import com.infosys.feba.framework.common.util.FieldUtil;
import com.infosys.feba.framework.common.util.resource.PropertyUtil;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.dal.AbstractNewVOPopulator;

import com.infosys.feba.framework.dal.QueryRecord;
import com.infosys.feba.framework.types.valueobjects.FEBAAVOFactory;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.ebanking.types.valueobjects.CustomUserSearchDetailsVO;
import com.infosys.feba.framework.types.primitives.FEBAUnboundString;

 

/** 
 * This class is used to populate a CustomUserSearchDetailsVO after a list search.
 * 
 * @author DalGenerator
 * @version 1.0
 * @since FEBA 2.0
 * Generated on ::Tue, Nov 23, 2021 
 */
public class CustomUserSearchDALDataBuilder extends AbstractNewVOPopulator {
	
	
	
	/*
	 * Populator method to populate VO.
	 * @param txnContext
	 * @param queryRecord
	 * @return vo
	 * @see com.infosys.feba.framework.dal.AbstractGenericDataBuilder#populateVO(com.infosys.feba.framework.context.FEBATransactionContext,
	 *      com.infosys.feba.framework.dal.QueryRecord)
	 */	

	protected IFEBAValueObject populateVO(FEBATransactionContext pTxnContext,
			QueryRecord pQueryRecord) {
			
			
			
			final CustomUserSearchDetailsVO vo = (CustomUserSearchDetailsVO) FEBAAVOFactory
						.createInstance("com.infosys.ebanking.types.valueobjects.CustomUserSearchDetailsVO");		
			
				final String userId_P = pQueryRecord.getString("USER_ID" );
                if(userId_P !=null ) {
                FEBAUnboundString userId = new FEBAUnboundString(userId_P);
		vo.setUserId(userId);
			    }

				final String mobileNumber_P = pQueryRecord.getString("MOB_NUM" );
                if(mobileNumber_P !=null ) {
                FEBAUnboundString mobileNumber = new FEBAUnboundString(mobileNumber_P);
		vo.setMobileNumber(mobileNumber);
			    }

				final String emailId_P = pQueryRecord.getString("EMAIL_ID" );
                if(emailId_P !=null ) {
                FEBAUnboundString emailId = new FEBAUnboundString(emailId_P);
		vo.setEmailId(emailId);
			    }

			    postProcess(pTxnContext,vo,pQueryRecord);
			     		    
			
			return vo;		
		
		
	}  
	protected void postProcess(FEBATransactionContext pTxnContext,IFEBAValueObject outputVO,
				QueryRecord pQueryRecord)
	{
		
	}	
	
}
