/*z
 * CustomEBIncidenceCodes.java
 * @author
 * @since Feb 2012
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.icici.ebanking.common;

/**
 * Class containing all custom incidence code constants
 *
 * @author
 * @version 1.0
 * @since FEBA 2.0
 */
public class CustomEBIncidenceCodes {
	
	public static final String INPUT_EMPTY = "INPBLK001";

	public static final String SPECIAL_CHAR_NOT_ALLOWED_IN_NICKNAME = "TXNSCU001";
	public static final String UNIQUE_NICKNAME = "TXNSCU002";
	public static final String ACCOUNT_NUMBER_LENGTH = "TXNSCU003";
	public static final String SPECIAL_CHAR_NOT_ALLOWED_IN_ACCOUNT_NUMBER = "TXNSCU004";
	public static final String RE_ACCOUNT_NUMBER = "TXNSCU005";
	public static final String SPECIAL_CHAR_IN_RE_ACCOUNT_NUMBER = "TXNSCU005";
	public static final String ACCOUNT_NUM_NOT_MATCHING = "TXNSCU006";
	public static final String PAYEE_NAME_INVALID = "TXNSCU007";
	public static final String SPECIAL_CHAR_NOT_ALLOWED_IN_BILLER_NICKNAME = "TXNSCU011";
	public static final String VIEW_AMORT_FLAG = "ACCLN664815";



	public static final String UNIQUE_BILLER_NICKNAME = "TXNSCU012";
	public static final String FIELD_LENGTH_LESS_THAN_MINIMUM_LENGTH = "TXNSCU013";
	public static final String FIELD_SHOULD_CONTAIN_ONLY_NUMBERS = "TXNSCU014";
	public static final String FIELD_SHOULD_CONTAIN_ONLY_ALPHABETS = "TXNSCU015";
	public static final String FIELD_SHOULD_CONTAIN_ONLY_ALPHANUMERIC = "TXNSCU016";
	public static final String FIELD_SHOULD_CONTAIN_ONLY_ALPHABETS_OR_SPECIAL_CHARS = "TXNSCU017";
	public static final String INVALID_STARTING_CHARACTER_SET = "TXNSCU018";
	public static final String INVALID_INDEX_DIGIT = "TXNSCU019";
	public static final String IMPROPER_ACCOUNT_NUMBER_LENGTH = "TXNSCU020";
	public static final String INVALID_FIELD_VALUE_ONLY_ALPHABET_HYPHEN = "TXNSCU021";
	public static final String INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_SPACE_HYPHEN = "TXNSCU022";
	public static final String INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_HYPHEN = "TXNSCU023";
	public static final String INVALID_CONSUMER_NUMBER_LENGTH = "TXNSCU024";
	public static final String CREDIT_CARD_NUMBER_INVALID = "TXNSCU025";
	public static final String INVALID_CUST_NO = "TXNSCU026";
	public static final String INVALID_ACCOUNT_NUMBER_MTNL = "TXNSCU027";
	public static final String UNIQUE_REG_NUM_BILLER = "TXNSCU028";
	public static final String STD_CODE_IN_TELEPHONENO_SHOULD_STARTWITH_022 = "TXNSCU029";
	public static final String FIRSTTHREE_DIGITS_OF_ACCTNO_122_4THDIGIT_HYPHEN = "TXNSCU030";
	public static final String POLICYNO_SHOULD_STARTWITH_3 = "TXNSCU031";
	public static final String FIFTHDIGITOF_POLICYNO_FORWARDSLASH = "TXNSCU032";
	public static final String LASTDIGITS_OF_POLICY_SHOULDNOTBE_LEFT_BLANK = "TXNSCU033";
	public static final String FIELDVALUE_SHOULDBE_NUMERIC_DOT_ALLOWED = "TXNSCU034";
	public static final String FIELDVALUE_SHOULDBE_NUMERIC_HYPEHN_ALLOWED = "TXNSCU035";
	public static final String INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_FWDSLASH = "TXNSCU036";
	public static final String FOURTH_DIGIT_OF_BILLNUMBER_HYPHEN = "TXNSCU037";
	public static final String EIGTH_DIGIT_OF_BILLNUMBER_HYPHEN = "TXNSCU038";
	public static final String TWELVETH_DIGIT_OF_BILLNUMBER_ASTRIEK = "TXNSCU039";
	public static final String INVALID_BILLNUMBER = "TXNSCU040";
	public static final String MAX_PAYEE_NAME_LENGTH = "TXNSCU041";
	public static final String MAX_PAYEE_NICKNAME_LENGTH = "TXNSCU042";
	public static final String FIELDVALUE_SHOULDBE_NUMERIC = "TXNSCU043";

	public static final String LOGIN_ATTEMTPS_NOT_FETCHED = "USRCUS001";
	public static final String LOGIN_ATTEMTPS_FIELD_MANDATORY = "USRCUS002";
	public static final String LOGIN_ATTEMTPS_UPDATE_FAILED = "USRCUS003";
	//Added for ChannelUserId Validation
	public static final String SPECIAL_CHAR_NOT_ALLOWED_IN_USERID = "USRCUS004";
	//Added for CUSRUPDT batch

	public static final String PROCESSING_FAILED_FOR_CUSRUPDT_BATCH = "BATCUS001";
	public static final String CULN_DATA_FETCH_HAS_FAILED = "BATCUS002";
	public static final String NO_RECORDS_FOUND_IN_CLOC_FOR_GIVEN_INPUT = "BATCUS003";
	public static final String CUSR_UPDATE_FAILED = "BATCUS004";

	public static final String PROCESSING_FAILED_FOR_ENABLEGRIDOTP_BATCH = "BATCUS031";
	//Added for ATMUPLD batch
	public static final String INVALID_ADMIN_ID_PASSED_ATMUPLD = "BATCUS005";
	public static final String INVALID_PRIMARY_ACCOUNT_ID_PASSED_ATMUPLD = "BATCUS006";
	public static final String INVALID_MENU_PROFILE_CODE_PASSED_ATMUPLD = "BATCUS007";
	public static final String INSERTION_INTO_IUSR_HAS_FAILED_ATMUPLD = "BATCUS008";
	public static final String INSERTION_INTO_CSIP_HAS_FAILED_ATMUPLD = "BATCUS009";
	public static final String INSERTION_INTO_CUSR_HAS_FAILED_ATMUPLD = "BATCUS010";
	public static final String INSERTION_INTO_CULN_HAS_FAILED_ATMUPLD = "BATCUS011";
	public static final String INSERTION_INTO_UART_HAS_FAILED_ATMUPLD = "BATCUS011";
	public static final String PROCESSING_FAILED_IN_ATMUPLD_BATCH = "BATCUS012";
	public static final String INSERTION_INTO_UADT_HAS_FAILED_ATMUPLD = "BATCUS020";
	public static final String INSERTION_INTO_SIDT_HAS_FAILED_ATMUPLD = "BATCUS021";

	//Added for BULKPWD batch
	public static final String BULKPWD_ERROR_WHILE_FETCHING_USERS = "BATCUS020";
	public static final String BULKPWD_ERROR_NO_RECORD_FETCHED = "BATCUS021";
	public static final String PROCESSING_FAILED_IN_BULKPWD_BATCH = "BATCUS022";
	public static final String BULKPWD_PWD_RESET_DATE_DAYS_VALIDATION_FAILED = "BATCUS030";

	//Added for Service request
	public static final String EMAIL_ID_OR_MOBILE_NO_REQUIRED = "SERVCU001";
	public static final String FROM_DATE_GREATER_THAN_TO_DATE = "SERVCU002";
	public static final String INVALID_EMAILID = "SERVCU003";
	public static final String EMAIL_LENGTH_CANNOT_EXCEED_50_CHARACTERS = "SERVCU004";
	public static final String INVALID_MOBILE_LENGTH = "SERVCU005";
	public static final String TELEPHONE_NUMBER_MAX_LENGTH_SHOULD_BE_15_CHARACTERS = "SERVCU006";
	public static final String INVALID_TELEPHONE_NUMBER = "SERVCU007";
	public static final String MAX_CUSTID_LENGTH_EXCEEDED = "SERVCU008";
	public static final String CUSTID_CONTAINS_SPECIAL_CHARS = "SERVCU009";
	public static final String IMPROPER_LENGTH_FOR_NAME_TO_BE_PRINTED_ON_CARD = "SERVCU010";
	public static final String NAME_TO_BE_PRINTED_ON_CARD_CONTAINS_SPECIAL_CHARS = "SERVCU011";
	public static final String PAN_IS_REQD_FOR_RD = "SERVCU012";
	public static final String PAN_IS_REQD_FOR_FD = "SERVCU013";
	public static final String INVALID_PAST_DATE = "SERVCU014";
	public static final String EXISTING_NEW_MOBILE_NO_CANNOT_BE_SAME = "SERVCU015";
	public static final String EXISTING_NEW_EMAIL_ID_CANNOT_BE_SAME = "SERVCU016";
	public static final String FROM_DATE_INVALID = "SERVCU017";
	public static final String INVALID_SERVICE_REQUEST_NUMBER = "SERVCU018";
	public static final String TELEPHONE_NUMBER_MIN_LENGTH_SHOULD_BE_5_CHARACTERS = "SERVCU019";
	public static final String ATM_BANK_NAME_MAX_LENGTH_SHOULD_BE_50_CHARACTERS = "SERVCU020";
	public static final String ATM_BANK_NAME_MIN_LENGTH_SHOULD_BE_5_CHARACTERS = "SERVCU021";
	public static final String TXN_ID_DISPUTED_MAX_LENGTH_SHOULD_BE_2_CHARACTERS = "SERVCU022";
	public static final String TXN_ID_DISPUTED_MIN_LENGTH_SHOULD_BE_1_CHARACTERS = "SERVCU023";
	public static final String INVALID_PAST_DATE_3MONTHS = "SERVCU024";
	public static final String INVALID_PAST_DATE_7DAYS = "SERVCU025";
	public static final String INVALID_PAST_DATE_9DAYS = "SERVCU026";
	public static final String INVALID_PAST_DATE_15DAYS = "SERVCU027";
	public static final String INVALID_CHEQUENO_LENGTH = "SERVCU028";
	public static final String INVALID_PRIOR_DATE = "SERVCU029";
	public static final String LENGTH_DESCRIPTION_SHOULD_NOT_EXCEED_100_CHARACTERS = "SERVCU030";
	public static final String INVALID_DESCRIPTION = "SERVCU031";
	public static final String TXN_AMOUNT_MAX_LENGTH_SHOULD_BE_10_DIGITS = "SERVCU032";
	public static final String TXN_AMOUNT_MIN_LENGTH_SHOULD_BE_ATLEAST_2_DIGITS = "SERVCU033";
	public static final String ATMID_MAX_LENGTH_SHOULD_BE_10_CHARACTERS = "SERVCU034";
	public static final String ATMID_MIN_LENGTH_SHOULD_BE_8_CHARACTERS = "SERVCU035";
	public static final String PREVIOUS_REQUEST_NUMBER_MAX_LENGTH_SHOULD_BE_12_CHARACTERS = "SERVCU036";
	public static final String PREVIOUS_REQUEST_NUMBER_MIN_LENGTH_SHOULD_BE_10_CHARACTERS = "SERVCU037";
	public static final String REASON_WITHDRAWAL_MAX_LENGTH_SHOULD_BE_50_CHARACTERS = "SERVCU038";
	public static final String REASON_WITHDRAWAL_MIN_LENGTH_SHOULD_BE_8_CHARACTERS = "SERVCU039";
	public static final String TXN_ID_MAX_LENGTH_SHOULD_BE_20_CHARACTERS = "SERVCU040";
	public static final String TXN_ID_MIN_LENGTH_SHOULD_BE_5_CHARACTERS = "SERVCU041";
	public static final String MERCHANT_NAME_MAX_LENGTH_SHOULD_BE_50_CHARACTERS = "SERVCU042";
	public static final String MERCHANT_NAME_MIN_LENGTH_SHOULD_BE_2_CHARACTERS = "SERVCU043";
	public static final String LANDLINE_NUMBER_MAX_LENGTH_SHOULD_BE_8_CHARACTERS = "SERVCU044";
	public static final String LANDLINE_NUMBER_MIN_LENGTH_SHOULD_BE_2_CHARACTERS = "SERVCU045";
	public static final String INVALID_LANDLINE_NUMBER = "SERVCU046";
	public static final String ONLY_ALPHABETS_ALLOWED = "SERVCU047";
	public static final String ONLY_ALPHABETS_SPACE_ALLOWED = "SERVCU048";
	public static final String ONLY_ALPHANUMERIC_ALLOWED = "SERVCU049";
	public static final String ONLY_ALPHANUMERIC_SPACE_ALLOWED = "SERVCU050";
	public static final String INVALID_PIN_LENGTH = "SERVCU051";
	public static final String FROM_DATE_SHOULD_BE_FIRST_DAY = "SERVCU052";
	public static final String SUBMISSION_DATE_IS_ONE_YEAR_OLD = "SERVCU053";
	public static final String FROM_DATE_INVALID_RDS = "SERVCU054";
	public static final String TO_DATE_SHOULD_BE_LAST_DAY = "SERVCU055";
	public static final String TO_DATE_SHUD_BE_PRIOR_TO_CURRENT_MONTH = "SERVCU056";
	public static final String FROM_DATE_SHUD_BE_PRIOR_TO_CURRENT_MONTH = "SERVCU057";
	public static final String IMPROPER_AMT_FOR_TITANIUM_CC_FD = "SERVCU058";
	public static final String IMPROPER_TENURE_FOR_TITANIUM_CC_FD = "SERVCU059";
	public static final String IMPROPER_AMT_FOR_PLATINUM_CC_FD = "SERVCU060";
	public static final String IMPROPER_TENURE_FOR_PLATINUM_CC_FD = "SERVCU061";
	public static final String INCORRECT_PAN_NUMBER = "SERVCU062";
	public static final String DOB_NOT_UPDATED_IN_SYSTEM = "SERVCU063";
	public static final String ACCT_BAL_INSUFFICIENT_FOR_FD = "SERVCU064";
	public static final String ACCT_BAL_INSUFFICIENT_FOR_RD = "SERVCU065";
	public static final String INVALID_RD_AMOUNT = "SERVCU066";
	public static final String MAX_TENURE_FOR_RD = "SERVCU067";
	public static final String MIN_TENURE_FOR_RD = "SERVCU068";
	public static final String INVALID_DAY_FOR_RD_SELECTED = "SERVCU069";
	public static final String INVALID_STD_LENGTH = "SERVCU070";

	public static final String MERCHANT_ID_MIN_LENGTH_SHOULD_BE_4_CHARACTERS = "SERVCU076";
	public static final String MERCHANT_ID_MAX_LENGTH_SHOULD_BE_10_CHARACTERS = "SERVCU077";
	public static final String CME_EMI_AMOUNT_INVALID = "SERVCU078";

	public static final String INCORRECT_TENURE_FOR_SPECIAL_FD = "SERVCU080";
	public static final String INCORRECT_TENURE_FOR_NORMAL_FD = "SERVCU081";
	public static final String INCORRECT_TENURE_FOR_PERIODIC_FD = "SERVCU082";
	public static final String MIN_TENURE_FOR_FD = "SERVCU083";
	public static final String MAX_TENURE_FOR_FD = "SERVCU084";
	public static final String INVALID_BALANCETRANSFERDDNO_LENGTH = "SERVCU085";
	public static final String INVALID_FDACCOUNTNO_LENGTH = "SERVCU086";
	public static final String INVALID_AMOUNT = "SERVCU087";
	public static final String INVALID_MAX_AMOUNT = "SERVCU088";
	public static final String INVALID_DATE_OF_BIRTH = "SERVCU089";
	public static final String INVALID_CARD_NUM_LENGTH = "SERVCU090";
	public static final String TYPE_OF_CC_REQUIRED = "SERVCU091";
	public static final String CITY_REQUIRED = "SERVCU092";
	public static final String TITLE_REQUIRED = "SERVCU093";
	public static final String STATE_REQUIRED = "SERVCU094";
	public static final String PINCODE_REQUIRED = "SERVCU095";
	public static final String ADDR_LINE_2_REQUIRED = "SERVCU096";
	public static final String ADDR_LINE_1_REQUIRED = "SERVCU097";
	public static final String NAME_ON_CC_REQUIRED = "SERVCU098";
	public static final String INVALID_QUERY_DESCRIPTION_LENGTH = "SERVCU099";
	public static final String INVALID_CASEID_LENGTH = "SERVCU100";
	public static final String INVALID_CUSTOMERNAME_LENGTH = "SERVCU101";
	public static final String INVALID_ADDRESS_WHERE_RQST_SUBMITTED_LENGTH = "SERVCU102";
	public static final String INVALID_AIRWAY_BILL_NO_LENGTH = "SERVCU103";
	public static final String INVALID_COURIER_NAME_LENGTH = "SERVCU104";
	public static final String INVALID_NAME_TO_BE_ADDED_LENGTH = "SERVCU105";
	public static final String INVALID_DATE = "SERVCU106";
	public static final String INVALID_MAX_AMOUNT_UNE = "SERVCU107";
	public static final String INVALID_MIN_AMOUNT_UNE = "SERVCU108";
	public static final String MAINTAIN_QUARTERLY_AVG = "SERVCU109";
	public static final String HOLD_NRE_SAVINGS_ACC = "SERVCU110";
	public static final String INVALID_CONTACT_NUMBER = "SERVCU111";
	public static final String AMT_LESS_THAN_100000 = "SERVCU112";
	public static final String INVALID_PAST_DATE_2DAYS = "SERVCU113";
	public static final String INVALID_DOB = "SERVCU114";
	public static final String ONLY_ALPHABETS_ALLOWED_FOR_NAME = "SERVCU115";
	public static final String INVALID_PRESET_LENGTH = "SERVCU116";
	public static final String INVALID_LENGTH_FOR_NAME = "SERVCU117";
	public static final String INVALID_PAST_DATE_3DAYS = "SERVCU118";
	public static final String INVALID_CHEQUE_NO_LENGTH = "SERVCU119";
	public static final String INVALID_DRAWEE_BANK_NAME_LENGTH = "SERVCU120";
	public static final String INVALID_EARLIER_SR_OR_CASE_ID_NO_LENGTH = "SERVCU121";
	public static final String CITY_IS_MANDATORY_IF_PLACE_OF_DEPOSIT_IS_BRANCH = "SERVCU122";
	public static final String INVALID_PAST_DATE_3DAYS_FROM_DEPOSIT = "SERVCU123";
	public static final String INVALID_PAST_DATE_5DAYS_FROM_DEPOSIT = "SERVCU124";
	public static final String TIME_OF_SUBMISSION_LIMIT = "SERVCU125";
	public static final String INVALID_PAST_DATE_4DAYS = "SERVCU126";
	public static final String AMOUNT_INVALID = "SERVCU127";
	public static final String INVALID_CREDITCRDNO_LENGTH = "SERVCU128";
	public static final String INVALID_DIRECT_CREDITCRDNO = "SERVCU129";
	public static final String INVALID_VIRTUAL_CREDITCRDNO = "SERVCU130";
	public static final String INVALID_ADD_ON_CREDITCRDNO = "SERVCU131";
	public static final String INVALID_CREDITCRDNO = "SERVCU132";
	public static final String INVALID_LOAN_ACCNT_NO_LENGTH = "SERVCU133";
	public static final String INVALID_FIRST_LOAN_ACCNT_NO = "SERVCU134";
	public static final String INVALID_LAST_LOAN_ACCNT_NO = "SERVCU135";
	public static final String INVALID_SAVINGS_ACCNT_NO = "SERVCU136";
	public static final String INVALID_DIRECT_SAVINGS_ACCNT_NO = "SERVCU137";
	public static final String INVALID_LENGTH_FOR_ATM_ID = "SERVCU1138";
	public static final String INVALID_LENGTH_FOR_TRAN_NO = "SERVCU1139";
	public static final String FIELDVALUE_SHOULD_NOT_BE_ZERO = "SERVCU165";
	public static final String AADHAAR_NUMBER = "SERVCU166";
	public static final String IMPROPER_AMT_FOR_PLATINUM_CHIP_CC_FD = "SERVCU248";//Added for CR231

	//Added for BULKMAILER batch
	public static final String PROCESSING_FAILED_IN_BULKMAILERUPLD_BATCH = "BATCUS013";
	public static final String USER_ID_CANNOT_BE_BLANK = "BATCUS014";
	public static final String ALIAS_ID_IS_INVALID = "BATCUS015";
	public static final String RECORD_NOT_FOUND_IN_CUSR = "BATCUS016";
	public static final String SUBJECT_CANNOT_BE_BLANK = "BATCUS017";
	public static final String MAILBODY_CANNOT_BE_BLANK = "BATCUS018";

	public static final String INVALID_REASON = "SERVCC101";
	public static final String INVALID_CONTACTNUMBER = "SERVCC102";
	public static final String INVALID_ADDONCARD = "SERVCC103";
	public static final String INVALID_CARDNUMBER = "SERVCC104";
	public static final String INVALID_CHECKBOX = "SERVCC105";
	public static final String INVALID_ACCOUNT_NUMBER = "SERVCC106";

	public static final String EMI_AMOUNT_INVALID = "SERVCU078";

	//Added for Demat custom vaidations
	public static final String SPECIAL_CHAR_NOT_ALLOWED_FOR_CMBC = "DMTCUS001";
	public static final String SPECIAL_CHAR_NOT_ALLOWED_FOR_SETLMNTAMT = "DMTCUS002";
	public static final String SPECIAL_CHAR_NOT_ALLOWED_FOR_DOCUMENTNO = "DMTCUS003";
	public static final String SPECIAL_CHAR_NOT_ALLOWED_FOR_ISIN = "DMTCUS004";

	//Added for Transaction Management
	public static final String ACCT_NOT_APPLICABLE_FOR_BILLER = "TRANCU001";
	public static final String PAYMENT_ALREADY_REVERSED = "TRANCU002";
	public static final String PAYMENT_CANNOT_BE_REVERSED = "TRANCU003";
	public static final String PID_IP_NOT_MATCHING = "TRANCU004";
	public static final String ONLINE_REVERSAL_UNSUCCESS = "TRANCU005";
	public static final String NO_MATCHING_RECS_FOR_TRACKING = "TRANCU006";

	//Added for RTGS address validations

	public static final String RTGS_ADDRESS_MANDATORY = "TRANCU007";
	public static final String RTGS_CITY_MANDATORY = "TRANCU008";
	public static final String RTGS_ZIP_MANDATORY = "TRANCU009";
	public static final String RTGS_STATE_MANDATORY = "TRANCU010";

	public static final String INVALID_CUSTOMERID = "SERVCU105";
	public static final String ONLY_ALPHANUMERIC_VEHICLENO_ALLOWED = "SERVCU106";

	public static final String INVALID_BENEFICIARYNAME_LENGTH = "SERVCU107";
	public static final String INVALID_BENEFICIARYADDRESS_LENGTH = "SERVCU108";
	public static final String INVALID_BENEFICIARYCITY_LENGTH = "SERVCU109";
	public static final String INVALID_BENEFICIARYSTATE_LENGTH = "SERVCU110";
	public static final String INVALID_BENEFICIARYPINCODE_LENGTH = "SERVCU111";

	public static final String INVALID_BENEFICIARYPHONE_LENGTH = "SERVCU1122";
	public static final String AMOUNT_INR_FOREIGN = "SERVCU1123";
	public static final String INVALID_AMOUNT_FOREIGN = "SERVCU1124";
	public static final String INVALID_AMOUNT_INR = "SERVCU1125";
	public static final String INVALID_NREACCOUNTNO_LENGTH = "SERVCU1126";

	public static final String INVALID_CONTACTNUMBER_LENGTH = "SERVCU1127";

	public static final String INVALID_FDAMOUNT_VAL = "SERVCU1129";
	public static final String INVALID_PAN_VAL = "SERVCU1130";
	public static final String INVALID_PAN_LEN = "SERVCU1131";

	public static final String INVALID_BILL_NAME = "SERVCU128";
	public static final String INVALID_DECIMAL_PATTERN = "SERVCU129";
	public static final String INVALID_ACCOUNT_NO = "SERVCU130";
	public static final String INVALID_ACCOUNT_NO_START = "SERVCU131";

	//Added for Login module
	public static final String MOB_NUM_ENTERED_NOT_MATCHED_WITH_REGISTERED_NUMBER = "USRCUS005";
	public static final String EMAILID_ENTERED_NOT_MATCHED_WITH_REGISTERED_ID = "USRCUS006";
	public static final String MOB_NUM_EMAILID_ENTERED_NOT_MATCHED_WITH_REGISTERED_MOB_NUM_EMAIL_ID = "USRCUS012";
	public static final String TABLE_OPERATOR_EXCEPTION_WHILE_FETCHING_FROM_CUSX = "USRCUS007";
	public static final String LOGIN_TXN_PWDS_CANT_CHANGE = "USRCUS008";
	public static final String PLZ_REGISTER_EMAILID = "USRCUS011";
	public static final String RECORD_NOT_FOUND_IN_AMPM = "USRCUS101";
	public static final String USER_NOT_LINKED_TO_MENUID = "USRCUS102";
	public static final String USR_NOT_FOUND_IN_UTML = "USRCUS103";
	public static final String INCONSISTENCY_PRODID_NUMBEROFPRODIDS = "USRCUS104";
	public static final String INCONSISTENCY_FEDID_NUMBEROFFEDIDS = "USRCUS105";
	public static final String INCONSISTENCY_CUSTID_NUMBEROFCUSTIDS = "USRCUS106";
	public static final String UNABLE_TO_FETCH_PORDTYPE_FOR_THE_FSID = "USRCUS107";

	//Added for Grid Card
	public static final String INITIATOR_ACOUNT_NOT_FOUND = "USRCUS108";
	public static final String NO_VALID_CARDS_FOUND_FOR_USER = "USRCUS109";
	public static final String NO_RESPONSE_FROM_HOST_FOR_AUTHENTICATING_CARD = "USRCUS110";
	public static final String FAILED_TO_PROCCESS_GRID_CARD_AUTH = "USRCUS111";
	public static final String UADT_TABLE_EXCEPTION = "USRCUS112";

	//added for issue id 306633
	public static final String NICKNAME_IS_ALPHANUMERIC = "ACCTCU001";

	//Added for Repatriation from NRE SB via Wire Transfer
	public static final String INVALID_LENGTH_FOR_BEN_NAME = "SERVCU073";
	public static final String INVALID_LENGTH_FOR_ACCT_NUM = "SERVCU074";
	public static final String INVALID_LENGTH_FOR_BEN_BANK_NAME = "SERVCU075";
	public static final String INVALID_LENGTH_FOR_BEN_BANK_ADDR = "SERVCU079";
	public static final String INVALID_LENGTH_FOR_AMT = "SERVCU138";
	public static final String INVALID_LENGTH_FOR_AMT_INR = "SERVCU139";

	//Added for Repatriation from FCNR / NRE FD via Wire Transfer
	public static final String INVALID_LENGTH_FOR_BENEFICIARY_NAME = "SERVCU140";
	public static final String INVALID_LENGTH_FOR_ACC_NUM = "SERVCU141";
	public static final String INVALID_LENGTH_FOR_BENEF_BANK_NAME = "SERVCU142";
	public static final String INVALID_LENGTH_FOR_BENEF_BANK_ADDR = "SERVCU143";
	public static final String INVALID_LENGTH_FOR_BENEF_NAME = "SERVCU144";
	public static final String DEPOSIT_CANNOT_BE_CLOSED_ON_MATURITY = "SERVCU145";
	public static final String INVALID_AMOUNT_NULL = "SERVCU146";

	// Added for Address Deletion not done
	public static final String INVALID_LENGTH_FOR_SRNUM = "SERVCU147";
	public static final String INVALID_CITY_NAME = "SERVCU148";
	public static final String INVALID_BRANCH_NAME = "SERVCU149";

	public static final String EMAIL_ID_MANDATORY = "SERVCU150";
	public static final String DISPATCH_EMAIL_LENGTH_CANNOT_EXCEED_50_CHARACTERS = "SERVCU151";
	public static final String INVALID_DISPATCH_EMAILID = "SERVCU152";
	public static final String INVALID_LENGTH_QUERY_DESCRIPTION = "SERVCU153";
	public static final String INVALID_AMOUNT_REQ_RCVD = "SERVCU154";
	public static final String INVALID_MIN_TXN_NUMBER = "SERVCU155";
	public static final String INVALID_LENGTH_ATM_ID = "SERVCU156";
	public static final String CHEQUE_NUMBER_AND_DATE_NOT_ENTERED = "SERVCU157";
	public static final String CHEQUE_NUMBER_NOT_ENTERED = "SERVCU158";
	public static final String CHEQUE_DATE_NOT_ENTERED = "SERVCU159";
	public static final String INVALID_FD_NUMBER = "SERVCU160";
	public static final String INVALID_PREMATURE_JOINT = "SERVCU161";

	//Added for view insurance summary usecase
	public static final String UNABLE_TO_FETCH_LIST_OF_POLICIES = "ACCNTCU001";

	//Added for MayIHelpYouValidation
	public static final String SUN_SAT_HOLIDAYS = "USRCUS009";
	public static final String TIME_OF_SUBMISSION = "USRCUS010";
	public static final String ERROR_IN_INSERTION_TO_CLOC = "BATCUS019";

	public static final String INVALID_PAST_DATE_5DAYS_FROM_CHEQUE_RETURN = "SERVCU1140";
	public static final String INVALID_CHEQUE_NUMBER_LENGTH = "SERVCU1141";

	public static final String SPECIAL_CHAR_NOT_ALLOWED_FOR_SETLMNTNO = "DMTCUS005";

	public static final String INVALID_MIN_ATM_ID = "SERVCU1180";
	public static final String BOTH_EMAIL_IDS_SHOULD_BE_SAME = "SERVCU162";

	//*For ISafe Portwise Integration-Start
	public static final String PWUD_INSERT_FAILED_DURING_USER_CREATION = "PWINTX0001";
	public static final String PWUD_UPDATE_FAILED_DURING_USER_CREATION = "PWINTX0002";
	public static final String COULD_NOT_SEND_URL_ALERT = "PWINTX0003";
	public static final String PWUD_UPDATE_FAILED_DURING_USER_STATUS_UPDATE = "PWINTX0004";
	public static final String INVALID_OTP = "PWINTX0005";
	public static final String PIN_CHANGE_FAILED = "PWINTX0006";
	public static final String UNABLE_TO_DELETE_PWUD_RECORD = "PWINTX0007";
	public static final String PWUD_SELECT_FAILED = "PWINTX0008";
	public static final String COULD_NOT_FETCH_CUSR_RECORD = "PWINTX0009";
	public static final String CUSR_TRAN_AUTH_SCHEME_UPDATE_FAILED = "PWINTX0010";
	public static final String NOT_REGISTERED_FOR_ISAFE_OTP_IN_UADT = "PWINTX0011";
	public static final String INVALID_OTP_WHILE_AUTHRIZE = "PWINTX00012";

	public static final String INPUT_PIN_LENGTH_MISMATCH = "PWINVZ0001";
	public static final String USER_NOT_ACTIVATED_FOR_ISAFE = "PWINVZ0002";


	public static final String RETRIEVE_MMID_FAIL = "FEBAHIF0025";

	//*Added for FORCE CONTACT FIELD validations

		public static final String INVALID_CITY  = "FRCCU001";
		public static final String INVALID_STATE = "FRCCU002";


        public static final String NRI_STATE_VALIDATION = "FRCCU0039";
		public static final String NRI_CITY_VALIDATION = "FRCCU0042";
		public static final String ONLY_ALPHABETS_ALLOWED_FOR_NRICITY="FRCCU0043";
		public static final String ONLY_ALPHABETS_ALLOWED_FOR_NRISTATE="FRCCU0044";


		public static final String ONLY_ALPHABETS_ALLOWED_FOR_STATE = "FRCCU005";
		public static final String ONLY_ALPHABETS_ALLOWED_FOR_CITY = "FRCCU006";
		public static final String ONLY_ALPHABETS_ALLOWED_FOR_SALUTATION = "FRCCU007";
		public static final String NAME_VALIDATION = "FEBAHIF0039";
		public static final String INVALID_ADDRESS="FCDADD0000";
		public static final String CONTAINS_ONLY_NUMBERS = "FEBAHIF0042";
		public static final String INVALID_SPECIAL_CHARACTERS="FEBAHIF0043";
		public static final String INVALID_ADDRESSLINE1="FEBAHIF0044";
		public static final String INVALID_ADDRESSLINE3="FEBAHIF0045";
		public static final String INVALID_ADDRESSLINE2="FEBAHIF0046";
		public static final String INVALID_EMAIL_ID_LENGTH="FEBAHIF0047";
		public static final String INVALID_REGISTERED_MOBILE_NUMBER_LENGTH="FEBAHIF0067";
		public static final String INVALID_NRI_REGISTERED_MOBILE_NUMBER="FRCCU0049";
		public static final String INVALID_REGISTERED_MOBILE_NUMBER="FEBAHIF0048";
		public static final String INVALID_PIN_LENGTH_NRI="FEBAHIF0049";
		public static final String INVALID_MINIMUM_PIN_LENGTH_NRI="FEBAHIF0050";
		public static final String INVALID_PAN_NUMBER="FEBAHIF0060";
		public static final String ONLY_ALPHABETS_FOR_FIRST_FIVE="FEBAHIF0061";
		public static final String ONLY_NUMBERS_FOR_NEXT_FOUR="FEBAHIF0062";
		public static final String FOURTH_ALBHABET="FEBAHIF0063";
		public static final String ONLY_ALPHABETS_FOR_LASTVALUE="FEBAHIF0064";
		public static final String NO_ACCOUNTS_PENDING_UPDATION="FEBAHIF0065";
		public static final String SELECT_ANOTHER_ACCOUNT="FEBAHIF0066";

		public static final String INVALID_CONTACT_PIN="FRCCU077";
	   public static final String INVALID_CONTACT_EMAIL_ID = "FRCCU004";
	   public static final String INVALID_CONTACT_CITY="FRCCU008";
	   public static final String INVALID_CONTACT_STATE="FRCCU009";


	   	public static final String CHECK_ADDRESS="FEBAHIF0091";
	   	public static final String CHECK_CITY="FEBAHIF0092";
	   	public static final String CHECK_BRANCH="FEBAHIF0100";
	   	public static final String CHECK_STATE="FRCCU093";
	   	public static final String CHECK_PIN = "FRCCU094";
	   	public static final String CHECK_PAN="FRCCU0095";
	   	public static final String CHECK_EMAIL="FRCCU096";
	public static final String CHECK_PHONE="FRCCU0097";
	public static final String PLEASE_SELECT_VALID_ACCOUNT_TYPE = "FRCCU0098";
	public static final String CHECK_SALUTATION = "FRCCU0099";
	    	//*Added for FORCE CONTACT FIELD validations end

	//Added for DTH SubscriberId validation fix

	public static final String INVALID_SUSCRIBER_ID = "SERVCU200";

	//Added for Admin validation
	public static final String INVALID_SELECTION = "ADMCUS001";
	public static final String DEMAT_BILL_NUMBER_MANDATORY = "DMTCUS006";
	public static final String INVALID_CREDITCRDDATE_LENGTH = "SERVCU201";
	public static final String INVALID_MONTH = "SERVCU202";
	public static final String INVALID_CREDITCRDYEAR = "SERVCU203";
	 public static final String NO_RECORDS_RETREIVED_FROM_SBMX = "SRLNTX0001";

	 //Added for mobile number validation in SRs
	 public static final String MOBILE_NUMBER_SHOULD_NOT_START_WITH_ZERO = "SERVCU204";

	 	 //Added for CustomSR10DaysPastDateVal
	 public static final String INVALID_PAST_DATE_10DAYS = "SERVCU206";

	 public static final String ICICI_CREDIT_CARD_NUMBER = "TRANCU011";
	 public static final String NO_OPEN_SRS_EXIST_FOR_USER="SERVCU205";
	 //Added for CIFDOWNLOAD - START
	 public static final String BACK_DATED_FILE_REQ_MAND = "BATCIF001";
	 public static final String FROM_DATE_TO_DATE_MAND =  "BATCIF002";
	 public static final String LAST_DWNLD_TIME_LIE_BTW_FROM_TO_DATES = "BATCIF003";
	 //Added for CIFDOWNLOAD - END

	//Added for ATMB validation
	public static final String NO_RECORD_IN_ATMB = "MOBCUS001";

	 //Added for View Credit Last Payment Status - START
		 public static final String CC_DETAILS_NOT_AVAILABLE = "FEBAHIF0026";
	 //Added for View Credit Last Payment Status - END

	  // Added for Bank Issue Observation : 25
		 public static final String MMID_SHOULD_BE_NUMERIC = "TRANCU015";
         public static final String INVALID_MMID_MOBILE_NUMBER = "TRANCU016";

		 public static final String BILLER_STATE_MANDATORY="BILLFG0002";
		 public static final String CITY_ZIP_COMBINATION_REQ = "TRANCU012";
		 public static final String SEND_INVALID_PINCODE = "TRANCU013";
		 public static final String REC_INVALID_PINCODE = "TRANCU014";
	// Added by Shyamamanjari
	public static final String TXN_AMOUNT_GREATER_THAN_BALANCE = "TXNSCU044";

	public static final String INVALID_ACCOUNT_NUMBER_LENGTH = "TXNSCU045";
	public static final String FIRSTTHREE_DIGITS_OF_ACCTNO_119_4THDIGIT_HYPHEN = "TXNSCU046";
	public static final String INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC = "TXNSCU047";

	//Added for biller amount field validations
	public static final String AMOUNT_SHD_NOT_CONTAIN_SPECIAL_CHARS_OR_NUMBERS = "TXNSCU048";
	public static final String ONLY_TWO_DIGITS_ALLOWED_AFTER_DECIMAL_POINT = "TXNSCU049";
	public static final String AMOUNT_SHOULD_BE_GREATER_THAN_ZERO = "TXNSCU050";

	public static final String INVALID_MOBILE_NO_START = "TXNSCU051";
	public static final String INVALID_READING_DAY_VALUE = "TXNSCU052";

	public static final String SPECIAL_CHARS_SPACES_NOT_ALLOWED_IN_PREMIUM_AMOUNT = "TXNSCU053";
	public static final String IDEA_CELLULAR_ACC_START_IMPROPER = "TXNSCU054";
	public static final String IDEA_CELLULAR_ACC_SHUD_NUMERIC = "TXNSCU055";
	public static final String AMERICAN_CREDIT_CARD_INVALID = "TXNSCU056";


	//Added for resend OTP
	public static final String NICK_NAME_INVALID = "TXNSCU057";

		//Added for Credit Card Hand pick Reward Points
	public static final String INSUFFICIENT_REWARD_POINTS = "SERVCU207";
	public static final String REDEMPTION_FAIL = "SERVCU208";
		//Added for iWish Manage Goals
	public static final String ERROR_WHILE_FETCHING_GOALS = "ACCTNC001";
	public static final String ERROR_WHILE_FETCHING_FED_ID = "ACCTNC002";

	public static final String INVALID_POLICY_NUMBER_BILLER = "TXNSCU058";
	//Added for Bank Issue : 324645
	public static final String INVALID_MOBILE_NUMBER_LENGTH = "TRANCU018";
	//added for set maximum limit for Virtual Credit Card
	public static final String INVALID_CC_RESET_LIMIT="SERVCU209";

	public static final String INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_SPACE = "TXNSCU059";
	//Added for Handpick Rewward Points
	public static final String NO_ITEM_SELECTED = "ACCTCCC001";

	//Added for CR 35
	public static final String INVALID_DUE_DATE="SERVCU210";

	//Added for 7th Nov tab. S No 45, 259 and 274
	public static final String BILLER_INVALID_DOB = "TXNSCU060";

	//Added for terms and conditions check in SR - CR 36
	public static final String TNC_CHECK = "SERVCU214";

	//Added for CR 88
	public static final String BILLER_POLICY_NUM_INVALID = "TXNSCU062";

	//Added for CR 81
	public static final String CA_NUMBER_ALL_DIGITS_ZERO = "TXNSCU063";

	public static final String MIN_LENGTH_FOR_NICKNAME_IS_3 = "TXNSCU064";
	public static final String MAX_LENGTH_FOR_NICKNAME_IS_12 = "TXNSCU065";
	public static final String ENTER_FIRST_4_DIGITS = "TXNSCU066";

	public static final String INVALID_FIELD_VALUE_SHOULD_CONTAIN_ALPHABETS = "SERVCU215";
	//Added for Payee format change done for VISA biller(ref ticket no: 329752)
	public static final String CREDIT_CARD_NUMBER_MATCH_INVALID = "TXNSCU067";

	public static final String NO_BILLER_REGISTRATIONS = "TXNSCU068";

		 // ADDED FOR OPERATIVE ACCOUNT ESTATEMENT BY EMAIL
	public static final String INVALID_OPTION_SELECTED = "TXNSCU075";
	public static final String INVALID_EMAILID_RECONFIRM_EMAILID = "TXNSCU076";
	public static final String INVALID_REQUEST = "TXNSCU077";

	public static final String INVALID_AMOUNT_PPF = "TXNSCU091";
	//Added for issue id 330262
	public static final String FUTURE_DATE_NOT_ALLOWED_FOR_FROMDATE = "TXNSCU092";
	public static final String FUTURE_DATE_NOT_ALLOWED_FOR_TO_DATE = "TXNSCU093";

	// Added for mobile sync
	public static final String COULD_NOT_INSERT_INTO_MNHT = "BATCUS023";
	public static final String COULD_NOT_UPDATE_SIDT_DURING_ACCEPTANCE="BATCUS024";
	public static final String COULD_NOT_INSERT_INTO_DULH="BATCUS025";
	public static final String COULD_NOT_UPDATE_MNHT="BATCUS0026";

	// Added for defect 329903
	public static final String INVALID_TENURE_DAYS = "SRQSDM01";

	//Added for channel Id validations  332934 and 332936
	public static final String CHANNEL_HAVING_SPL_CHARS="USERTX2001";
	public static final String CHANNEL_LENTH_LESS_THAN_FOUR="USERTX2002";

	public static final String FIELDVALUE_SHOULDBE_NUMERIC_COMMA_ALLOWED = "TXNSCU094";

	public static final String COULD_NOT_UPDATE_CSIP_DURING_ACCEPTANCE="BATCUS027";

	public static final String INVALID_DISPATCH_NAME = "SRQGCP01";
	public static final String INVALID_RECEIVER_NAME = "SRQGCP02";

    // Added For TAX26 AS
	public static final String PAN_NOT_UPDATED_IN_RECORDS = "FEBAHIF0050";

	public static final String BILLER_PAYEE_FORMAT_NOT_AVAIL = "TXNSCU095";
	/* Added for TO 328141 START */
	public static final String INVALID_PAYEE_ENTERED = "CRPMEX0083";
	/* Added for TO 328141 END */

	public static final String REGISTER_MOBILE_BEFORE_ADD_PAYEE="TXNSCU096";

	// Added For Form 15 G/H
	public static final String NO_FIXED_DEPOSITS_LINKED = "FRM15GH0001";
    public static final String DOB_NOT_UPDATED_IN_RECORDS = "FEBAHIF0051";
    public static final String CRITERIA_BLANK =  "SRCH990105";

    //Added for TO 331822,329893
    public static final String INVALID_APPLICANT_NAME = "SRQLRP01";
	//Added for TO:334786
    public static final String CTL_DOWN  = "ACCTCU012";

    //Added for the defect 338986
    public static final String TELEPHONE_NUMBER_MIN_LENGTH_SHOULD_BE_10_CHARACTERS = "SERVCU211";

    //Added for the defect 338985
    public static final String INVALID_DEALER_CONTACT_NUMBER = "SERVCU212";
    public static final String DEALERCONTACT_NUMBER_MAX_LENGTH_SHOULD_BE_15_CHARACTERS = "SERVCU213";
    public static final String DEALERCONTACT_NUMBER_MIN_LENGTH_SHOULD_BE_10_CHARACTERS = "SERVCU217";

	/*Added for UWID batch*/
	public static final String INSERTION_INTO_UWID_HAS_FAILED_ATMUPLD = "BATCUS028";
	public static final String ASSOCIATE_UWID_FIELD_HAS_FAILED_ATMUPLD = "BATCUS029";

	/*Added for 330266 and 330268*/
		public static final String INVALID_NUMBER_OF_CHARS_AFTER_DECIMAL = "SERVCU218";
		public static final String FROM_AND_TO_AMOUNT_MANDATORY = "SERVCU219";

    /*Added for 339888*/
	public static final String WIDGET_CAN_NOT_BE_REMOVED = "USERWID001";
	/*Added for 341470*/
	public static final String WIDGET_CAN_NOT_BE_ADDED = "USERWID002";

	/*Added for 341359*/
	public static final String INVALID_FIELD_VALUE_ONLY_ALPHABET_SPACE = "SERVCU220";
	/*Added for 341345 */
	public static final String INVALID_APPLICATION_NUMBER = "SERVCU221";
	  public static final String HOST_DOWN  = "ACCTCU013";
	  /*Added for 330300 AND 330299*/
	  public static final String GIFT_AMT_VAL="GIFTAMT001";

	   /*Added for TO 346940 start*/
	  public static final String IMPS_MOBILE_NUMBER_LENGTH_INVALID="TRANCU020";
	  public static final String IMPS_MOBILE_NUMBER_CONTAIN_ALPHABET_SPECIAL_CHARACTER="TRANCU021";
	  /*Added for TO 346940 end*/
	  /*Added for TO 341359 start*/
	  public static final String CREDIT_CARD_NUMBERS_NOT_MATCH="TRANCU022";

	  /*Added for TO 341359 end*/
	  /*Added for IMPS MMID start*/
		public static final String IMPS_MMID_SHOULD_BE_NUMERIC="TRANCU023";
		public static final String IMPS_MMID_NUMBER_LENGTH_INVALID="TRANCU024";
	/*Added for IMPS MMID start*/

		/*Added for admin verify url usecase Start */
		public static final String BILLER_ID_SHOULD_BE_NUMERIC = "SERVCU222";
		/*Added for admin verify url usecase End*/

		public static final String INVALID_MOTHER_MAIDEN_NAME="FPWDOFF0001";
		public static final String INVALID_PIN_CODE = "FPWDOFF0002";
			/*Added for Information Payee Details started*/

	public static final String SR_IPD_TRAN_DATE="SRIPDTRDATE";
	public static final String SR_IPD_VALID_CHQ_NO="SRIPDVACHQ";
	public static final String SR_IPD_NOT_EN_CHQ_NO="SRIPDNOCHQ";
	public static final String SR_IPD_VAL_AMT="SRIPDVALAMT";
	public static final String SR_IPD_VAL_DESC="SRIPDVALDESC";

	/*Added for Information Payee Details ended*/
		/*Added for Information Payee Details ended*/
		/* add for AGC  Start */
		public static final String INVALID_AGREEFLG = "SERVCU1001";
		public static final String INVALID_CREDITCARD_LENGTH = "SERVCU1002";
		/* add for AGC  End */
		 /* Add for Consolidated Investment Summary Start**/
		public static final String CONSOLIDATED_INVESTMENT_NULL = "ACCTSV099";

		  /* Add for Consolidated Investment Summary End**/
/*Added for Status on AdditionDeletion of MandateNominee Started*/
	public static final String SR_SMN_NMADRV="SRSMNNMADRV";
	public static final String SR_SMN_CRA_NAM="SRSMNCRANAM";
	public static final String SR_SMN_BILL_NO="SRSMNBILNO";
	/*Added for Status on AddtionDeletion of MandateNominee Ended*/
	/*Added for AMT Card on Mandate started*/
	public static final String SR_FRM_NAM_MANDATE="SRFRMNAMMAND";
	public static final String SR_FRM_CITY="SRFRMCITY";
	public static final String SR_FRM_STATE="SRFRMSTATE";
	public static final String SR_FRM_PINCOD="SRFRMPINCOD";
	public static final String SR_FRM_CONTACT_NO="SRFRMCONTACNO";
	/*Added for AMT Card on Mandate Ended*/

	  	  /* add for IFT start */
	public static final String INVALID_IFT_BACCNUMBER = "SERVCU226";
	public static final String INVALID_IFT_BBANKNAME = "SERVCU239";
	public static final String INVALID_IFT_AMTTRAN = "SERVCU240";
	public static final String INVALID_IFT_AmtTranDate = "IFTVCU235";

	public static final String INVALID_RCP_CARDHOLDERNAME = "SERVCU241";

	public static final String INVALID_OAA_BRANCH = "OAAVCU234";

	public static final String INVALID_RST_SBACCRYPE = "RSTVCU231";
	public static final String RST_INVALID_SAVINGACCT_PRODUCT_CATEGORY = "RSTVCU232";
	public static final String INVALID_RST_Amount1 = "RSTVCU233";
	public static final String INVALID_RST_Amount2 = "RSTVCU234";
	public static final String INVALID_RST_Amount3 = "RSTVCU235";
	public static final String INVALID_RST_Amount4 = "RSTVCU236";

	public static final String INVALID_IBP_BILLERNAME = "SERVCU242";
	public static final String INVALID_IBP_AMOUNT = "IBPVCU236";
	public static final String INVALID_IBP_PAYMENTDATE = "IBPVCU233";
	public static final String INVALID_IBP_PAYMENTID ="IBPVCU237";

	  /* add for RWT end */

    //Add for Request_FAI_UNSEC_NRI_LI_N_CashDepositedNC start
    public static final String SR_IPD_VALID_LO_AB="SRCDAVALOAB";
    public static final String SR_IPD_VALID_DR_BR="SRCDAVADRPR";
    public static final String SR_IPD_VALID_CHQ_AM="SRCDAVACHOAM";
    public static final String SR_IPD_VALID_PO_CD="SRCDAVAPOCD";
    public static final String SR_IPD_VALID_DW_CD="SRCDAVADWCD";
    public static final String SR_IPD_VALID_CHQ_NON="SRIPDVACHQN";
    public static final String SR_IPD_VALID_DR_BN="SRIPDVADRBN";
    public static final String SR_IPD_VALID_CHQ_AMM="SRIPDVACHQAMM";
    public static final String SR_CDA_VALID_placeO_fCD="SRCDAVAPLACEOFCD";
    public static final String SR_CDA_VALID_Date_WCD="SRCDAVADateWCD";
  //Add for Request_FAI_UNSEC_NRI_LI_N_CashDepositedNC end

	public static final String INVALID_BNU_BILLERNAME = "SERVCU227";
	public static final String INVALID_BNU_BILLNUMBER = "SERVCU228";
	public static final String INVALID_BNU_DUEDATE = "SERVCU229";
	public static final String INVALID_BNU_REGDATE1 = "SERVCU230";
	public static final String INVALID_BNU_REGDATE2 = "SERVCU231";
	public static final String INVALID_RBS_CUSTID = "SERVCU232";
	public static final String INVALID_RBS_TODATE = "SERVCU233";
	public static final String INVALID_RBS_FROMDATE1 = "SERVCU234";
	public static final String INVALID_RBS_FROMDATE2 = "SERVCU235";
	public static final String INVALID_SNR_STMT = "SERVCU236";
	public static final String INVALID_DNC_CAO = "SERVCU237";
	/* Added for to id 329910 Start*/
	 public static final String IMPS_VISIBILTY_CHECK = "SERVCU236";
	/* Added for to id 329910 end*/

	/* Added for CR145*/
	public static final String IS_PPF_EEC_ACCT_NO = "ACCTCU014";
	public static final String IS_PPF_EEC_HOT_TXNS = "ACCTCU015";
	public static final String IS_PPF_EEC_SCHD_TXNS = "ACCTCU016";


	//Added for SMO TO's
	public static final String REC_STATE_MANDATORY = "TXNSCU044";
    public static final String REC_CITY_MANDATORY = "TXNSCU045";
	public static final String REC_ADDR_MANDATORY = "TXNSCU046";
	public static final String REC_NAME_MANDATORY = "TXNSCU047";
	public static final String REC_ZIP_MANDATORY = "TXNZIP052";
	public static final String SEND_STATE_MANDATORY = "TXNSCU148";
	public static final String SEND_CITY_MANDATORY = "TXNSCU149";
	public static final String SEND_ADDR_MANDATORY = "TXNSCU150";
	public static final String SEND_NAME_MANDATORY = "TXNSCU151";
	public static final String SEND_ZIP_MANDATORY = "TXNZIP053";
/*Added by China team. Begins*/
 //ADD FOR Request_FAI_NRILI_InfonUpgradetoNRIEDGE
    public static final String SR_IUE_VALID_NM_PA="SRIUEVANMPA";
    public static final String SR_IUE_VALID_CON_NO="SRIUEVACONNO";
    	/*Added for Stop cheque Request started */
	public static final String SR_STC_RMK="SRSTCRMK";
	public static final String SR_STC_CHQ="SRSTCCHQ";
    public static final String SR_STC_CHQ_DIG="SRCHDIG";
	/*Added for Stop cheque Request ended*/
	//Add for CBN SR Request_FAI_UNSEC_NRI_LI_N_DelivrbleNotRecdChqBook
	public static final String SR_CBN_CHEQUE_BOOK_APPLIED_DATE = "SRCBN001";

	public static final String PLATINUM_CARD_NUMBER_ONLY_NUMERIC_ALLOWED = "PCLCUS001";
	public static final String SR_RSD_ONLY_NUMERIC_ALLOWED = "SERCU240";
	public static final String SR_RSD_NREACCOUNT_LENGTH = "SERCU239";
	//Added for PDC
  	public static final String CONTACT_NUMBER_MINIMUM_LENGTH = "RFPLDBC01";
  	public static final String CONTACT_NUMBER_ONLY_NUMERIC_ALLOWED="RFPLDBC02";
  	public static final String CONTACT_NUMBER_CANNOT_BE_NEGATIVE_OR_ZERO="RFPLDBC03";
  	public static final String IMPROPER_SAVING_ACCOUNT_NUMBER ="RFPLDBC04";
  	//Added for PDC
    //Added for RDR
    public static final String DB_ACCOUNT_NUMBER_ONLY_NUMERIC_ALLOWED = "REDISPODD01";
    public static final String DB_ACCOUNT_NUMBER_MINIMUM_LENGTH = "REDISPODD02";
    public static final String IMPROPER_DB_ACCNT_NO = "REDISPODD03";
    public static final String DD_ISSUE_DATE_INVALID_PAST_DATE_10DAYS = "REDISPODD04";
    public static final String IMPROPER_BENEFICIARYNAME_MIN_LENGTH = "REDISPODD05";
    public static final String IMPROPER_BENEFICIARYADDRESS_MIN_LENGTH = "REDISPODD06";
    public static final String IMPROPER_BENEFICIARYADDRESS_ONLY_ALPHABETS_ALLOWED= "REDISPODD07";
    public static final String IMPROPER_BENEFICIARYCITY_ONLY_ALPHABETS_ALLOWED = "REDISPODD08";
    public static final String IMPROPER_BENEFICIARYCITY_MIN_LENGTH = "REDISPODD09";
    //Added for RDR

    /* add for RWT start */
    public static final String INVALID_RWT_Repatriation_TOBECLOSE = "SRQRWT1001";
	  public static final String INVALID_FD_ACCOUNT = "SRQRWT1002";
	  public static final String INVALID_REPATRIATED_AUMOUNT = "SRQRWT1003";
    /* add for RWT End */
		/* add for UNR Start*/
	  public static final String UNR_AGREE_SELECT = "SRQUNR1001";
	  public static final String UNR_INVALID_SAVING_ACCT_STATUS = "SRQUNR1002";
	  public static final String UNR_INVALID_SAVINGACCT_PRODUCT_CATEGORY = "SRQUNR1003";
	  public static final String UNR_INVALID_SAVINGACCT_BALANCE1 = "SRQUNR1004";
	  public static final String UNR_INVALID_SAVINGACCT_BALANCE2 = "SRQUNR1005";
	  /* add for UNR end*/
	 public static final String INVALID_ORD_AMOUNT = "SERCU240";
	  public static final String INVALID_ORD_TENUREYEAR = "SERCU241";
	  public static final String INVALID_ORD_TENUREMONTH = "SERCU242";

	/*Added for NRI SR status on address change start*/
      public static final String DATES_WITHIN_8DAYS = "SRSAC001";
      public static final String DATES_WITHIN_3MONTHS = "SRSAC002";
      public static final String INVALID_BILL_NUMBER = "SRSAC003";
      public static final String INVALID_IBUSER_ID = "SRSAC004";
      /*Added for NRI SR status on address change end*/

      /*Added for NRI SR Status of cheque sent to NRI Services start*/
      public static final String DATES_AFTER_11DAYS = "SRCSS001";
      public static final String BANK_NAME_MIN_LEN_EXTEND = "SRCSS002";
      public static final String INVALID_CHQ_NUMBER = "SRCSS003";
      public static final String CHQ_SNET_NOT_BEFORE_TODAY ="SRCSS004";
      public static final String INVALID_CHQ_AMT = "SRCSS005";
      public static final String INVALID_COURIER_POST_NAME = "SRCSS006";
      public static final String INVALID_BILL_NO = "SRCSS007";
      public static final String INVALID_CHQ_AMT_RANGE = "SRCSS010";
      public static final String DATES_AFTER_18DAYS = "SRCSS011";
      public static final String DATES_AFTER_5DAYS = "SRCSS012";
      public static final String DATES_AFTER_3DAYS = "SRCSS013";
      public static final String DATES_AFTER_8DAYS = "SRCSS014";
      public static final String DATES_AFTER_21DAYS = "SRCSS015";
      public static final String DATES_AFTER_15DAYS = "SRCSS016";
      public static final String AWB_MAND = "SRCSS017";
      public static final String COURIER_NAME_MAND = "SRCSS018";
  	public static final String DATES_BEFORE_TODAY = "SRCSS019";
  	public static final String SR_VALUE = "SRCSS020";
      //public static final String INVALID_CHQ_AMT = "SRCSS008";
      /*Added for NRI SR Status of cheque sent to NRI Services end*/

      /*Added for LAR start*/
      public static final String NOT_WITHIN_2DAYS = "SRLAU001";
      public static final String NOT_WITHIN_8DAYS = "SRLAU002";
      public static final String NOT_WITHIN_15DAYS = "SRLAU003";
      public static final String MOD_IS_BLANK = "SRLAU004";
      public static final String COURIER_POSTNAME_IS_BLANK = "SRLAU005";
      public static final String BILL_NO_IS_INVALID = "SRLAU006";
      public static final String EARLIER_SRNO_IS_BLANK = "SRLAU007";
      public static final String INVALID_LINKED_ACCT = "SRLAU008";
      public static final String SUBMITED_DATE_IS_BLANK = "SRLAU009";
      public static final String INVALID_COURIER_POSTNAME ="SRLAU010";
      public static final String INVALID_EARLIER_SRNO ="SRLAU011";

      /*Added for LAU end*/
      public static final String INVALID_CFR_FDNUMBER = "SERCU243";
      public static final String INVALID_CFR_CLOSURETYPE = "SERCU244";
      public static final String INVALID_CFR_CLOSUREAMOUNT = "SERCU245";
      public static final String INVALID_CFR_SAVINGACOUNT = "SERCU246";
      public static final String INVALID_CFR_REQUEST = "SERCU247";
      public static final String INVALID_ORD_PAYID = "SERCU248";
      public static final String INVALID_BNU_AMOUNT = "SERCU249";
	  /*Added for OSD Start*/
	  public static final String ACCT_BAL_ZERO_NEGATIVE_FOR_FD = "SEQOSD001";
	  public static final String MINIMUM_FD_AMOUNT_ERROR = "SEQOSD002";
	  public static final String MAXIMUM_FD_AMOUNT_ERROR = "SEQOSD003";
	  public static final String AVAILABLE_BALANCE_INSUFFICIENT = "SEQOSD004";
	  public static final String TENURE_DAYS_MANDATORY = "SEQOSD005";
	  public static final String TYPE_OF_FD_MANDATORY = "SEQOSD006";
	  /*Added for OSD Start*/
	  //added for SR SFD start
	public static final String TENURE_YEARS_MANDATORY = "SEQSFD006";
	//added for SR SFD end
	//Added for CR 143 start
    public static final String TOBE_RENEWED_ON_POPULATOR_ERR = "TBRO001";
    public static final String TOBE_RENEWED_ON_BLANK = "TBRO002";
    //Added for CR 143 end
    //Added for TYA start
    public static final String TYA_BRANCH_MANDATORY = "SEQTYAO001";
    //Added for TYA end
/*Added by China team. Ends*/

	  /*Added for Login Clone id start*/

	  public static final String EXCEPTION_OCCURRED_DURING_CLDT_INSERTION="USERTX068";

      /*Added for Login Clone id start*/

	    /*Added for TO 353278 start*/
	   public static final String IMPS_MMT_SYSTEM_DOWN="TRANCU025";
	    /*Added for TO 353278 end*/

	    /*Added for TO 353284 start*/
			   public static final String IMPS_AMT_VALIDATION="TRANCU026";
			   public static final String AMT_IFSC_VALIDATION="TRANCU027";
			   public static final String AMT_IFSC_DECIMAL_VALIDATION="TRANCU028";
	    /*Added for TO 353284 end*/
// Added for FTA
	public static final String TERM_CONDITION_LINK = "SERVCU166";
	public static final String EITHER_FORIEGN_INR = "SERVCU167";
	public static final String ONLY_ONE_FRGN_INR = "SERVCU168";
	public static final String VALID_RELATION = "SERVCU169";
	public static final String STUDENT_NAME_ID = "SERVCU170";
	public static final String CURRENCY_BANK_ROUTING = "SERVCU171";
	public static final String BANK_SWIFT_CODE = "SERVCU172";
	public static final String BENEFICIARY_CORRESPONDANT_SWIFT_CODE = "SERVCU173";
	public static final String MANDATORY_CHARGE_SCHEDULE = "SERVCU175";
	public static final String STUDENT_NAME_INVALID = "SERVCU176";
	public static final String FTA_BENEFICAIRY_NAME_INVALID = "SERVCU177";
    public static final String FTA_BENEFICAIRY_ADDRESS_INVALID = "SERVCU995659";
	public static final String FTA_BENEFICAIRY_ADD_MAND = "SERVCU6608";
	public static final String FTA_SOURCE_OF_FUNDS_MAND = "SERVCU7777";
	public static final String FTA_PURP_REM__MAND = "SERVCU6602";
	public static final String FTA_ALPHA_NUMERIC_VAL = "SERVCU178";
	public static final String FTA_ALPHA_NUMERIC_BANK_NAME_VAL = "SERVCU180";
	public static final String FTA_ALPHA_NUMERIC_BANK_SWIFT_VAL = "SERVCU181";
	public static final String FTA_ALPHA_NUMERIC_BANK_ROUTING_VAL = "SERVCU182";
	public static final String FTA_ALPHA_NUMERIC_CORRESPONDENT_VAL = "SERVCU183";
	public static final String FTA_ALPHA_ROUTING_CORRESPONDENT_VAL = "SERVCU184";
	public static final String FTA_ALPHA_SWIFT_CORRESPONDENT_VAL = "SERVCU185";
	public static final String BANK_CORRESPONDANT_SWIFT_CODE = "SERVCU186";


	/*Added for Address Change SR - Start*/
	 	public static final String ACC_NOT_OLD_FOR_ADD_CHANGE = "SERVCU237";
		public static final String ACC_NOT_ACTIVE_FOR_ADD_CHANGE = "SERVCU238";
		public static final String ACC_NO_BAL_FOR_ADD_CHANGE = "SERVCU239";
	  /*Added for Address Change SR - End*/

	  /*Added for SR TDS - Start*/
	  public static final String CUSTID_VALUE_SHOULDBE_NUMERIC = "SERVCU245";
	  /*Added for SR TDS  - ends*/
	  /*Added for Apply for auto Invest Account - NRO Started*/
      public static final String SR_AIA_VALID_FD_YE="SRAIAFDYE";
      public static final String SR_AIA_VALID_FD_MO="SRAIAFDMO";
      public static final String SR_AIA_VALID_MI_AM="SRAIAMIAM";
      public static final String SR_AIA_VALID_MI_BA="SRAIAMIBA";
      public static final String SR_AIA_VALID_AC_DORMAT="SRAIAACDO";
      public static final String SR_AIA_VALID_AC_DEBIT="SRAIAACDE";
      public static final String SR_AIA_VALID_AC_ZERO="SRAIAACZE";
      public static final String SR_AIA_VALID_AC_SCH="SRAIAACSC";
      public static final String SR_AIA_VALID_AC_MOP="SRAIAACMOP";
      public static final String SR_AIA_VALID_FDDAY="SRAIAFD";
      public static final String SR_AIA_VALID_RNDAY="SRAIARN";
      /*Added for Apply for auto Invest Account - NRO Ended*/
	//Added for RFW
    public static final String INVALID_STATE_NAME = "FCNRNREFD01";
    public static final String INVALID_BENEFICIARY_PHONE_NUMBER = "FCNRNREFD02";
    public static final String INVALID_FD_ACCOUNT_NUMBER_ZERO_NEGATIVE = "FCNRNREFD03";
    public static final String INVALID_FD_ACCOUNT_NUMBER_DEBIT_FREEZE = "FCNRNREFD04";
    public static final String INVALID_FD_ACCOUNT_NUMBER_NRO = "FCNRNREFD05";
    public static final String INVALID_FD_ACCOUNT_NUMBER_CLOSURE_OF_FD = "FCNRNREFD06";
    //Added for RFW
    //Added for RDR
  	public static final String INVALID_DD_ISSUE_DATE= "REDISPODD10";
  //Added for RDR


	  public static final String INVALID_DATE_BIRTH_ON_PAN ="PANVCU000";

	  public static final String INSERTION_FAILED_IN_ESAFE = "ESAFE001";
	  /*Added for 349832*/
	  public static final String MAILBODY_CANNOT_HAVE_SPACES = "MAILCUS001";
	  //Added for New CR
	  public static final String INVALID_PAYMENT_ID="SERVCU174";

	/*Added for NBR Debit Card Hotlisting ----Start*/
	public static final String INVALID_BLOCKING_REASON = "SERVCU247";
	public static final String RECORD_NOT_FOUND = "SERVCU246";
	/*Added for NBR Debit Card Hotlisting ----End*/

		/* Added for error messages from IMPS system start */
	 public static final String IMPS_MMT_INVALID_BENEFICIARY_MOBILE_NUMBER_MMID="TRANCU029";
	   public static final String IMPS_MMT_AMOUNT_LIMIT_EXCEEDED="TRANCU030";
	   public static final String IMPS_MMT_ACCOUNT_BLOCKED_FROZEN="TRANCU031";
	   public static final String IMPS_MMT_NRE_ACCOUNT="TRANCU032";
	   public static final String IMPS_MMT_ACCOUNT_CLOSED="TRANCU033";
	   public static final String IMPS_MMT_LIMIT_EXCEEDED_FOR_MEMBER_BANK="TRANCU034";
	   public static final String IMPS_MMT_INVALID_PAYMENT_REFERENCE="TRANCU035";
	   public static final String IMPS_MMT_FUNCTIONALITY_NOT_SUPPORTED_BY_ISSUING_BANK="TRANCU036";
	   public static final String IMPS_MMT_FUNCTIONALITY_NOT_SUPPORTED_BY_BENEFICIARY_BANK="TRANCU037";
	   public static final String IMPS_MMT_INVALID_OTP="TRANCU038";
	   public static final String IMPS_MMT_OTP_EXPIRED="TRANCU039";
	   public static final String IMPS_MMT_ISSUER_NODE_OFFLINE="TRANCU040";
	   public static final String IMPS_MMT_INVALID_REMITTER="TRANCU041";
	   public static final String IMPS_MMT_INVALID_NBIN_IFSC_CODE_OF_BENEFICIARY="TRANCU042";
	   public static final String IMPS_MMT_INVALID_MPIN="TRANCU043";

	   public static final String IMPS_MMT_OTP_TRANSACTION_LIMIT_EXCEEDED="TRANCU044";
	   public static final String IMPS_MMT_ISSUING_BANK_CBS_NODE_OFFLINE="TRANCU045";
	   public static final String IMPS_MMT_DUPLICATE_TRANSMISSION="TRANCU046";
	   public static final String IMPS_MMT_RECONCILE_ERROR="TRANCU047";
	   public static final String IMPS_MMT_UNABLE_TO_PROCESS="TRANCU048";
	   public static final String IMPS_MMT_HOST_UNREACHABLE="TRANCU049";
	   	/* Added for error messages from IMPS system end */
		/*Added for 349809*/
		public static final String MAIL_BODY_CANNOT_BE_BLANK = "MAILCUS002";
  //Added for RST --start



	//Added for FRA --start
    public static final String NAME_OF_CUSTOMER_ON_FRA = "SRQFRA001";
    public static final String TYPE_OF_ACCOUNT_ON_FRA = "SRQFRA002";
    public static final String DATE_OF_EARLIER_REQUEST_ON_FRA = "SRQFRA003";
	//Added for FRA --end
	//Added for RST --end

	/*Added for CR 57 - start*/
	public static final String INVALID_PWD_RESET_3DAYS = "USRCUS113";
	public static final String UNIQUE_NO_INCORRECT = "USERCU114";
	public static final String UNIQUE_NO_CANT_BE_GENERATED = "USERCU115";
	public static final String UNIQUE_NO_NOT_GENERATED = "USERCU116";
	public static final String INVALID_USER_ID = "USERCU117";
	public static final String LOGIN_DISABLED_FOR_USER = "USERCU118";
	public static final String ENTERED_UNIQUE_NO_INCORRECT = "USERCU119";
	public static final String UNIQUE_NO_MANDATORY = "USERCU120";
	/*Added for CR 57 - End*/

	   /*Added for grid card data entry validation start*/
	   public static final String GRID_CARD_VALUES_SHOULD_BE_NUMERIC="TRANCU050";
	   public static final String GRID_CARD_VALUES_BLANK="TRANCU051";
	   /*Added for grid card data entry validation end*/
	//Added for RTC--start
    public static final String PAN_NUMBER_NO_UPDATED = "SRQRTC001";
    public static final String RTC_CHECK = "SRQRTC002";
    public static final String FINANCIAL_YEAR_ON_RTC = "SRQRTC003";
	//Added for RTC --end

	 //Added for CFD --start
    public static final String FD_ACCOUNT_MATURITYDATE_ON_CFD= "SRQCFD001";
    public static final String FD_ACCOUNT_BALANCE_ON_CFD = "SRQCFD002";
    public static final String INVALID_Beneficiary_OF_PHONENO_ON_CFD = "SRQCFD003";
    public static final String INVALID_PINCODE_ON_CFD = "SRQCFD004";
	public static final String INVALID_FD_ACCOUNT_NUM_ON_CFD = "SRQCFD005";
	public static final String SR_CFD_AMT_MAX_DIGIT="SRCF006";
	public static final String SR_CFD_PH_NO="SRCFD007";
	public static final String SR_CFD_AMT_NOT_NEG="SRCFD008";
	//Added for CFD --end
//Added for PDC
  	public static final String IMPROPER_CUSTOMER_NAME_LENGTH="RFPLDBC05";
  //Added for PDC

		/*Added for Personalize transaction limit Dropdown valdation START*/
	   public static final String PERSONALIZE_TXN_LIMIT_DROPDOWN_SHOULD_NOT_BE_EMPTY="TRANCU979";
	   /*Added for Personalize transaction limit Dropdown valdation END*/

	   /*Added for MayIHelpYou start*/
	   	public static final String MAYIHELP_URL_NULL = "USERTX098";
	   /*Added for MayIHelpYou end*/

   /* Added for Know your User ID start */
	public static final String KYUID_INVALID_ACCOUNT_NUMBER = "TXNSCU097";
public static final String KYUID_INVALID_EMAILID = "TXNSCU098";
public static final String KYUID_ACCOUNT_NUMBER_MANDATORY = "TXNSCU100";
	public static final String EMAILID_IS_MANDATORY ="TXNSCU101";
public static final String MOBILENUMBER_IS_MANDATORY ="TXNSCU102";
public static final String KYUID_MOBILE_NUMBER_COUNTRYCODE="USRCUS009";
	public static final String KYUID_MOBILE_NUMBER_LENGHT="USRCUS008";
	public static final String KYUID_MOBILE_NUMBER_VALIDCOUNTRYCODE="USRCUS007";
	public static final String KYUID_MOBILE_NUMBER_NOT_REGISTERED="USRCUS010";
	public static final String KYUID_MOBILE_NUMBER_DEOSNT_MATCH="USRCUS005";
	public static final String KYUID_EMAILID_NOT_REGISTERED="USRCUS012";
public static final String KYUID_EMAILID_DOESNT_MATCH="USRCUS006";

 /* Added for Know your User ID end */



     /*Added for SMO TO's */
     public static final String FIELDVALUE_SHOULDBE_ALPHABETS = "SERVCU250";
     public static final String ADDR_LENGTH_SHOULDBE_GREATER_THAN_THREE = "SERVCU254";
	public static final String LENGTH_OF_NAME_SHOULDBE_GREATER_THAN_THREE = "SERVCU255";

     /* Added for CR 141 start */
     	public static final String REQUEST_TYPE = "SERVCU249";
     	public static final String ATTACH_FILE = "SERVCU253";
        public static final String IMPROPER_FILE_CONTENTTYPE = "SERVCU251";
        public static final String MANDATORY_DOCUMENT_LIST = "SERVCU252";
     /* Added for CR 141 end */


      /* Added for Message Center */
   		 public static final String RESPONSE_NULL = "USERTX099";

   		 //Added for CR 177//
	   	public static final String UNABLE_TO_FETCH_LIST_OF_DEMAT_ACCOUNTS = "ACCNTCU0011";
	   	/*Added for TO 377284*/
	   	public static final String NO_DEMAT_ACCOUNTS_LINKED = "ACCNTCU0010";
	   	//Added by Suma
	   	    public static final String PAN_NUMBER_NOT_UPDATED = "SRQRTC001";
	   	    /*Added for Privilege Banking- Start*/
	   	 public static final String THERE_ARE_NO_PAYEE_REGISTERED_FOR_PAY_ANY_VISA_CREDIT_CARD = "SRQRTC010";
				  public static final String  FEEDBACK_SUCCESS = "PBFFW000";
				 	  public static final String  FEEDBACK_DUPLICATE = "PBFFW001";
				 	  public static final String  FEEDBACK_FAILURE = "PBFFW002";
	  public static final String  FEEDBACK_MANDATORY= "PBFFW003";
	  /*Added for Privilege Banking- End*/
				public static final String PWUD_TABLE_OPERATOR_EXCEPTION = "PWINTX00013";
				public static final String PORTWISE_REGISTERED_USER = "PWINTX00014";

	/*Added for UEN date validation*/
		        public static final String INVALID_DATE_RANGE_SELECTED= "SRUEN001";

	 /* Added for CR 149 */
	  public static final String  GTP_FACILITY_CHECK= "GTPSR001";
	  public static final String  GTP_FACILTY_ALERT_ALREADY_SENT= "GTPSR002";
	  public static final String  GTP_PASSCODE_EXPIRED= "GTPSR003";
	  public static final String  GTP_INVALID_PASSCODE= "GTPSR004";
	  public static final String  COULD_NOT_UPDATE_INTO_STFT= "GTPSR005";
	  public static final String  GTP_DEBITCARD_STATUS_INACTIVE= "GTPSR006";
	  public static final String  INVALID_PASSCODE_LENGTH= "GTPSR007";
	  public static final String NO_RECORDS_RETREIVED_FROM_PWDH = "GTPSR016";
	  public static final String NO_RECORDS_RETREIVED_FROM_DUSR= "PCK0001";
	  public static final String NO_RECORDS_RETREIVED_FROM_STFT = "GTPSR017";
	  public static final String USER_ID_MANDATORY = "GTPFG005";
	  public static final String USERID_FACILITY_ALREADY_ENABLED = "GTPSRV027";
	  public static final String USERID_FACILITY_ALREADY_DISABLED="GTPSRV028";
	  public static final String INVALID_USERID="GTPSRV029";



	/* Added for Defect 355850 SMO start */
		public static final String ZIP_CODE_CHK = "TXNZIP000000";
	/* Added for Defect 355850 SMO end */


		// Added for SMO TO
		public static final String AMT_IN_MUTLIPLES_OF_HUNDRED = "TXNSMO1001" ;
		public static final String CITY_LENGTH_SHOULDBE_GREATER_THAN_THREE = "TXNSMO005";

	// Added by Soumya for Open PPF
	public static final String NO_SB_ACCNT_LINKED ="PPF001";
	public static final String PPF_AMT_VAL="PPF002";
	public static final String SERIAL_NO_ERR="PPF003";
	public static final String PAN_NO_FETCH_ERR="PPF004";
	public static final String PPF_AMT_VAL2="PPF005";

	/*Added for CR Query on non receipt of Mobile alerts */
	public static final String MOBILE_NOT_REGISTERED_FOR_ALERTS="SRARNA001";
	public static final String MOBILE_REGISTERED_FOR_ALERTS="SRARNA002";
	public static final String MOBILE_NUMBER_NOT_REGISTERED="SRARNA003";
	public static final String MOBILE_NUMBER_NOT_REGISTERED_FOR_TRANSACTION_ALERT="SRARNA004";
	public static final String MOBILE_NUMBER_NOT_REGISTERED_FOR_INTERNET_ALERT="SRARNA005";
	/*Added for CR Query on non receipt of Mobile alerts */

	/* Added for Defect 355856(SMO landing page) start */
	public static final String AMNT_FIELD_BLANK= "TXNSMO001";
	public static final String INIT_ACCNT_FIELD_BLANK= "TXNSMO002";
	/* Added for Defect 355856(SMO landing page) SMO end */

	/* Added for Manage Mandates ?Hari start */
	public static final String NO_RECORDS_FOUND = "BTCHEX1017";
	public static final String MANDATE_REGISTRATION_FAILURE = "TXNSV0001";
	/* Added for Manage Mandates ?Hari end */

	/*Added for 339391 */
	public static final String INVALID_AMOUNT_OF_SALARY_LENGTH = "SERVCU220";

	//Added for Receive Funds - START
	public static final String INVALID_CREDIT_DATE="SERVCU176";
	public static final String INVALID_TRANSACTION_AMOUNT="SERVCU175";
	public static final String INVALID_NO_OF_INSTALLMENTS="SERVCU177";
	public static final String MANDATE_DEREGISTRATION_FAILURE = "TXNSV0004";
	public static final String INVALID_AMOUNT_RF="SERVCU179";
	//Added for Receive Funds - END

	//Added by neha_kerkar for 341113
	public static final String LOGIN_PWD_CHANGED_SUCCESS = "USERCU121";
	public static final String TRANSACTION_PWD_CHANGED_SUCCESS = "USERCU122";
	public static final String INVALID_RSD_CCYAMT = "USERSD110";

	 //Added for RDR
  	public static final String IMPROPER_DEMAND_DRAFT_AMOUNT= "REDISPODD11";
     //Added for RDR

     //Added for isafe pin validation
	   	public static final String SPECIAL_CHAR_NOT_ALLOWED_IN_PIN = "USERSD111";
     //Added for isafe pin validation

	// Added for OPEN PPF - by Mirunaline_S and Soumya_shivam
	public static final String PANNO_MANDATORY="PPF007";
	public static final String MOBNO_MANDATORY="PPF008";
	public static final String NEG_MOBNO="PPF009";
	public static final String INVALID_MOBNO="PPF010";
	  public static final String PANNO_ALPHA1="PPF011";
	  public static final String PANNO_ALPHA2="PPF012";
	  public static final String PANNO_ALPHA3="PPF013";
	  public static final String PANNO_NUMERIC="PPF014";
  public static final String PANNO_ALPHA4="PPF015";
 public static final String PPF_TRAN_REM_VAL="PPF016";
	  public static final String INVALID_PANNO="PPF017";


	//Added for Mandates - for Dhivya
	public static final String MANDATE_DELETE_FAILURE = "TXNSV0006";

	//Added for RDR
  	public static final String BENEFICIARY_NAME_MANDATORY= "REDISPODD12";
  	public static final String BENEFICIARY_CONTACT_NUMBER_MANDATORY= "REDISPODD13";
  	public static final String DD_DATE_BEFORE_THREE_MONTHS= "REDISPODD14";
     //Added for RDR

	 /*Added for shopping mall payment start*/
	public static final String SHOPPINGMALL_INITIATOR_ACCOUNT_NUMBER_MANDATORY= "SHPACN0006";
	/*Added for shopping mall payment end*/
	public static final String INVALID_DDN_NUMLENTH= "USEDDN111";
	/*Added for Tax Payment Start*/
	  	public static final String CHALLAN_NUMERIC = "TXNSV0005";
	  	public static final String DATE_MORE_MONTHS = "TXNSV0006";
  	/*Added for Tax Payment End*/


  		/*Added for USRDTL- START*/
		public static final String USER_ID_DEACTIVATED = "USERIDDEACT4001";
		public static final String USER_ID_GENERATED = "USERIDGEN4002";
		public static final String FORGOT_USER_ID = "USERIDFRGT4003";
		/*Added for USRDTL- END*/
	/* Added for NRI SR status on address change start */
	public static final String DATES_WITHIN_3DAYS = "SRSAC005";
	public static final String DATES_WITHIN_15DAYS = "SRSAC006";
	public static final String DATES_WITHIN_21DAYS = "SRSAC007";
	/* Added for NRI SR status on address change end */

	/*Added for RFW */
  	public static final String NAME_OF_BENEFICIARY_MANDATORY="FCNRNREFD07";
	public static final String BENEFICIARY_ADDRESS_MANDATORY="FCNRNREFD08";
  	/*Added for RFW */

	/* Added for TO:362860,362299 */
	public static final String BILLER_ID_LENGTH = "SERVCU223";
	public static final String CHECK_YN_FLAG = "SERVCU225";
	/* Added for TO:361738  */
	 public static final String INVALID_AMOUNT_ENTERED="SHPACN0007";

	/* Added for TO:364436  */
	public static final String FD_TENURE_ON_BLANK = "SROSD001";


	//Added by neha_kerkar for CONVERT_TO_EMI
	public static final String CONVERT_TO_EMI_SUCCESS = "ACCNTCU0012";

	public static final String BRANCH_NOT_REGISTERED_FOR_RTGS = "TXNSV0011";

      //Added by SAkthi-DebitCard
      public static final String DPG_FACILITY_CHECK="DPGSR020";
      public static final String INVALID_URN_LENGTH="DPGSR021";
      public static final String DPG_URN_EXPIRED="DPGSR022";
      public static final String DPG_INVALID_URN="DPGSR023";
      public static final String DPG_URN_NOT_GENERATED="DPGSR024";
      public static final String DPG_INVALID_EMAILID="DPGSR025";
      public static final String DPG_EMAILID_MANDATORY="DPGSR026";
      public static final String DPG_INVALID_MOBILENUM="DPGSR027";
      public static final String DPG_MOBILENUM_MANDATORY="DPGSR028";
      public static final String DEBITCARD_PINGEN_FACILITY_DISABLED="USRCUS125";
      public static final String DPG_FACILTY_URN_ALREADY_SENT="DPGSR029";
      public static final String DEBIT_PIN_HOST_FAILED="DPGSR030";
      public static final String DEBITCARD_PIN_LENGTH_INVALID="DPGSR031";
      public static final String DEBITCARD_PIN_NO_SPACES="DPGSR031";
      public static final String DEBITCARD_PIN_NOT_MATCHED="DPGSR032";
      //Start: Added by devika for Integra Grid card validation
	   public static final String GRID_CARD_VALIDATION_NOT_SUCCESSFUL="TRANCU052";
	   //End: Added by devika for Integra Grid card validation



	 //Added for ULDT Table errors:START

	 public final static String ULDT_LICENCE_INSERTION_FAILED = "ULDT51001";
	 public final static String ULDT_DUPLICATE_LICENCE_INSERTION_FAILED = "ULDT51002";
	 public static final String ULDT_LICENCE_UPDATE_FAILED="ULDT51003";
	 public final static String ULDT_MAX_ACTIVE_DEVICES = "ULDT51004";
	 public final static String ULDT_STATUS_DEACTIVATED = "ULDT51006";
	 public final static String ULDT_STATUS_STOLEN = "ULDT51007";
	 public final static String ULDT_STATUS_AUTODEACTIVATE = "ULDT51008";
	 public static final String ULDT_NO_RECORDS_FOUND = "ULDT0";

	 //Added for ULDT Table errors:END
	//Added for FRDT Table errors:START
	 public final static String FRDT_INSERTION_FAILED = "FRDT51005";
	//Added for FRDT Table errors:END

	//Added for  OTPV
	public static final String OTP_EXPIRED ="OTPEXP001";
	public static final String OTP_USED ="OTPUSED001";

	//Added for  INVMPIN
	public static final String INVALID_QUERY_CRITERIA ="INVQUE001";

//added for name filed validation

 public static final String ONLY_ALPHABETS_SPACE_ALLOWED_FOR_DRAWEEBANK = "SERVCU300";
      public static final String ONLY_ALPHABETS_SPACE_ALLOWED_FOR_DRAWEEBRANCH = "SERVCU301";
      public static final String ONLY_ALPHABETS_SPACE_ALLOWED_FOR_CARDHOLDER_NAME = "SERVCU302";
public static final String NO_BILLS_PENDING="TXNSV032";
	//Added for RFW
	public static final String TO_BE_CLOSED_ON_MANDATORY= "FCNRNREFD11";
	public static final String REPATRIATION_OPTION_MANDATORY = "FCNRNREFD12";
	public static final String RFW_FD_ACCOUNT_NUMBER_MANDATORY = "FCNRNREFD13";
	//Added for RFW
	//Added for CFD
	public static final String CFD_TOBECLOSEON_MANDATORY = "SEQCFD007";
	public static final String CFD_DEP_TOBECLOSED_MANDATORY = "SEQCFD008";

/* Added for TO:338253  */
	public static final String INVALID_FUTURE_DATES_RNT = "SRRTN001";
	public static final String INVALID_DATES_WITHIN_21DAYS_RTN = "SRRTN002";
	public static final String INVALID_TYPE_OF_CONVERSION_ON_RTN = "SRRTN003";
/*Added for Tax Payment Reconcilation Menuoption*/
	public static final String TAX_PAYMENT_NO_RECORD_FOUND = "SERVCU303";
	public static final String TXND_TABLE_OPERATOR_EXCEPTION = "SERVCU304";
	public static final String TXN_ALREADY_RECONCILED = "SERVCU306";

/*Added for TO 361725 */
	      public static final String SALARY_CREDITED_DATE = "SERVCU305";

/*Added for NBR Debit Card Hotlisting ----Start*/
    public static final String INVALID_DEBIT_CARD_NUMBER = "SERVCU307";
/*Added for NBR Debit Card Hotlisting ----End*/
//Added for sr SIB
	 public static final String SR_SIB_VALID_DO_YQ="SRSIBVADOYQ";
	 public static final String SR_SIB_VALID_CI_TYS="SRSIBVACITYS";
	 public static final String SR_SIB_VALID_DA_TE="SRSIBVADATE";
	 public static final String SR_SIB_VALID_BR_CHS="SRSIBVABRCHS";
	 public static final String SR_SIB_VALID_CI_TYT="SRSIBVACITYT";
	 public static final String SR_SIB_VALID_BR_CHT="SRSIBVABRCHT";

	 public static final String NO_RD_DETAILS="ACCNTCU099";

	 public static final String MAX_NO_RECORDS_EXCEEDED = "USRCUS840";

	//CreditCard URN - START
	public static final String WRONG_URN_FOR_TXN= "USERTX1001";
	public static final String URN_HAS_EXPIRED= "USERTX1002";
	//CreditCard URN - END


	//Added for Buy Gold

	public static final String BUY_GOLD_NO_RECORDS_FETCHED= "INVBG1000";

	//Added for iWish Accounts

	public static final String NO_IWISH_ACCOUNTS="ACCNTCU100";

	/*Added for NBR - SR Validations*/
	public static final String INVALID_CARD_NUMBER = "SERVCU308";
	public static final String INVALID_CARD_HOLDER_NAME = "SERVCU309";
	public static final String CARD_STATUS_OPEN = "SERVCU310";
	public static final String CARD_STATUS_CLOSED = "SERVCU311";
	public static final String MOBILE_NUMBER_NOT_MATCH_CUSR = "SERVCU312";
	public static final String EMAIL_ID_NOT_MATCH_CUSR = "SERVCU313";
	public static final String ACCOUNT_NUMBER_NOT_FOUND_UEDT = "SERVCU314";
	public static final String CITY_NOT_MATCH_CUSR = "SERVCU315";
	public static final String CC_EXPIRY_DATE_NOT_MATCH = "SERVCU316";
	public static final String ACCOUNT_LESS_THAN_SIX_MONTH_OLD = "SERVCU317";
	public static final String DORMANT_ACCOUNT = "SERVCU318";
	public static final String ACCOUNT_DEBIT_FROZEN = "SERVCU319";
	public static final String ACCOUNT_LIEN_MARKED = "SERVCU320";
	public static final String NRI_ACCOUNT = "SERVCU321";
	public static final String ZERO_BALANCE = "SERVCU322";
	public static final String PAN_NOT_FOUND = "SERVCU323";
	public static final String PAN_NOT_MATCH = "SERVCU324";
	public static final String ACCOUNT_CREDIT_FROZEN = "SERVCU325";

	//Added for tenure validations in Standard FD
	public static final String INCORRECT_TENURE_CUMMULATIVE_FD = "SERVCU251";
	public static final String INCORRECT_TENURE_MONTHLY_FD = "SERVCU252";
	public static final String INCORRECT_TENURE_QUARTERLY_FD = "SERVCU253";

	public static final String MAXIMUM_FD_AMOUNT_SPECIAL_CHARACTER = "SEQOSD007";

	/*Added for TO ID 379673  - START*/
	 public static final String CHEQUE_NUMBER_REQUIRED = "SERVCU751";
	 public static final String ECS_FAVORING_TO_REQUIRED = "SERVCU752";
	 /*Added for TO ID 379673  - END*/
	 /*Added for TO ID 381012  - START*/
	 public static final String ONLY_CAP_ALPHABETS_FOR_FIRST_FIVE="SERVCU995005";
	 public static final String SIXTH_TO_NINTH_TOBE_NUMERIC="SERVCU995006";
	 public static final String ONLY_CAP_ALPHABETS_FOR_LAST_ONE="SERVCU995007";
	 /*Added for TO ID 381012  - END*/

	 /*Added for Buy Gold Fixes - Start*/
	 public static final String GOLD_NOT_AVAILABLE = "SERVCU326";
	 /*Added for Buy Gold Fixes - End*/
	 public static final String RTGS_REMARKS_MANDATORY = "TXSS058";
	 public static final String INVALID_RWT_REPATRIATION_AMOUNT = "SERVCU390";

	/*Added for TO ID 381377- START*/
		   	    public static final String INVALID_COURIER_DATE  = "SERVCU391";
				public static final String INVALID_HAND_DELIVERY_DATE  = "SERVCU392";
				public static final String INVALID_PO_BOX_AMOUNT  = "SERVCU393";
	/*Added for TO ID 381377- END*/
	/*Added for TO ID 387244- START*/
	public static final String INVALID_REGISTERED_POST_DATE  = "SERVCU395";
	/*Added for TO ID 387244- END*/

	/*Added for TO ID 380222- START*/
		   	    public static final String INVALID_LOCATION  = "SERVCU394";

	/*Added for TO ID 380222- END*/
	/*Added for TO ID 385641- START*/
	 public static final String RECURRING_TRANSACTION_MODIFY_NOTALLOWED = "TXSS059";
	 /*Added for TO ID 385641- END*/

	  /* Added for TO ID 389204 START*/
	 public static final String BILL_DEFAULTED = "BILDF001";
	  /* Added for TO ID 389204 END*/
	 /* Added for TO ID 388493 START*/
	 public static final String NO_RECORD_FOUND = "USRMNT009";
	  /* Added for TO ID 388493 END*/
	 public static final String AMOUNT_NOTIN_MULTIPLES_100 = "SERVVA0001";

	  /* Added for TO ID 387812 END*/
	 public static final String FD_RECEIPT_TAXSAVER_FD_NOT_ALLOWED = "ACCNTCU0012";
	 public static final String MICR_CODE_INVALID = "TXSS060";
	 public static final String GRID_TRAN_DISABLED = "USRCUS121";
	 public static final String MOBILE_NUMBER_EXISTS = "USRMNT001";
	 public static final String CVV_NUMBER_INVALID = "SRSERV0001";
	 public static final String CH_CHECK = "SERVCU216";
	public static final String CLICK_HERE_LINK = "SERVCU217";
	public static final String DEMAT_LINKED_TO_SAVINGS = "ACCNTSBA0000";

	//Added for dyna cache refresh on start up
	public static final String STARTUP_CACHE_REFRESH_ERROR = "CACH001";
	public static final String STARTUP_CACHE_REFRESH_CRST_SELECT_ERROR = "CACH002";
	public static final String STARTUP_CACHE_REFRESH_CRST_UPDATE_ERROR = "CACH003";

//Added for issue 384768
	public static final String MIN_NO_OF_MONTHS_IS_10 = "SERVCU370";
	public static final String MAX_NO_OF_MONTHS_IS_120 = "SERVCU371";
	public static final String MAX_NO_ALLOWED_YEARS_EXCEEDED = "SERVCU372";
	//added for issue 394371

	public static final String CUSTOM_INVALID_NRE_ACCOUNT = "SERVCU375";
	public static final String EMAIL_UPDATE_FAIL = "USRCUS122";

	//added for issue 386287
	public static final String PREMATURE_CLOSURE_FD_NOT_ALLOWED="SERVCU367";
	public static final String SIDT_UPDATE_FAILED = "BATCUS032";
	public static final String UADT_UPDATE_FAILED = "BATCUS033";
	public static final String MAX_WIDGET_COUNT_REACHED = "USRCU098";
	public static final String REMOVE_WIDGET_COUNT = "USRCU099";

    public static final String DMT_NO_TXN = "NOREC001";

    //Added for shopping mall reversal
    public static final String SHPMALL_REVERSAL_DISABLED = "SHPREV001";
    public static final String SHPMALL_LATE_REQUEST = "SHPREV002";
    public static final String SHPMALL_INVALID_URL_TIME = "SHPREV003";
	public static final String WRONG_PARAMS_IN_REVREQ = "SHPREV004";
	public static final String PID_LEN_INVALID_IN_REVREQ = "SHPREV005";
    public static final String TXNTIME_LEN_INVALID_IN_REVREQ = "SHPREV006";
    public static final String CRN_LEN_INVALID_IN_REVREQ = "SHPREV007";
	public static final String ITC_LEN_INVALID_IN_REVREQ = "SHPREV008";
	public static final String PRN_LEN_INVALID_IN_REVREQ = "SHPREV009";
	public static final String REVERSAL_FAILURE = "SHPREV010";
	/*Added for Remarks CR *Start*/
 	public static final String INVALID_REMARKS_FIELD = "TXSS061";
 	/*Added for Remarks CR *End*/
 	public static final String FIELD_VALIDATION = "USRCU100";
	public static final String INVALID_NEW_PIN_CODE = "SERVCU0100";
	public static final String INVALID_PIN_LENGTH_CCA = "SERVCU0101";

	public static final String EMAILID_CHK = "OTPTOEMAIL01";
	public static final String OTP_ENABLED = "OTPTOEMAIL02";
	public static final String DELETE_CHK = "OTPTOEMAIL03";
	public static final String MOBNO_CHK = "OTPTOEMAIL04";
	public static final String NRI_CHK = "OTPTOEMAIL05";
	public static final String UTML_CHK = "OTPTOEMAIL06";
	public static final String PWD_CONTAINS_USERID ="PWD001";
	public static final String FIELD_SHOULD_CONTAIN_ONLY_ALPHANUMERICDOT = "BV001";
	public static final String FIELD_SHOULD_CONTAIN_ONLY_UPPERCASE_LETTERS_AND_NUMBERS = "BV002";
	public static final String FIELD_SHOULD_CONTAIN_ONLY_ALPHANUMERICHYPHEN9 = "BV003";
	public static final String FIELD_SHOULD_CONTAIN_NUMBER_AND_HYPHEN = "BV004";

	//Added for Welcome Page CR
	public static final String CONFIRM_MOBILE_NUM = "USER993226";
	public static final String RTGS_INVALID_DATE = "TXNSCU105";
	//Added for TO 409128
	public static final String INVALID_FD_MOP = "USER993227";

	//Added for :NEFT Holiday Validation
	public static final String NEFT_BANK_HOLIDAY = "NEFT000001";
	//Added for :NEFT Holiday Validation

	//Added for CR 411688
	public static final String INVALID_ASSESSMENT_YEAR = "INVALIDYEAR001";
	public static final String TDS_NOT_GENERATED = "TDS001";
	public static final String TECH_ERROR = "TDS002";
	//Added for iMobile Batch
	public static final String USERID_CANNOT_BE_BLANK = "BATCU993223";
	public static final String PROCESSING_FAILED_IN_IMOBILEUPLD_BATCH ="BATCU993222";

	public static final String NOT_ABLE_TO_FETCH_ALL_ACCNT_DET ="ACCNTALL100";

	/* Added for 418735 start */

			 public static final String DP_FROM_DATE="DP993267";
			 public static final String DP_TO_DATE="DP993277";

	//Added for NRI Validations CR
	public static final String ADDRESS_RECENTLY_UPDATED = "SR993211";
	public static final String DUPLICATE_ADDRESS_CHANGE_REQUEST = "SR993212";
	public static final String ADDRESS_CHANGE_REQUEST_OPEN_STATUS = "SR993213";

	/*Added for SR68538060*/
	public static final String MANDATE_REGISTRATION_DUPLICATION = "TXNSV0009";

	//added for RTGS Scheduling CR

	public static final String RTGS_SCHEDULE_NOT_ALLOWED_BEYOND_GIVEN_RANGE = "TXSS099";

	//added for bill payments

	public static final String BLP_CC_MAKEPAYMET = "BLPCC0001";

	//Added for Service Request-RWT
	public static final String RWT_REPAT_AMT_MANDATORY = "SERVCU359";

	//Added for SR68953251
	public static final String REWARD_ITEMS_MAX_LIMIT_REACHED = "ACCTCCC002";

	 //Added for RPDT Table errors
	public final static String RPDT_INSERTION_FAILED = "RPDT51009";

	public static final String CLICK_CHK_PRCD = "TXNSV0021";

	public static final String ONLY_ALPHABETS_SPACE_HYPHEN_DOT_COMMA_ALLOWED = "SERVCU071";
	public static final String INVALID_FIELD_VALUE_ONLY_NUMERIC_HYPHEN_DOT = "TXNSCU106";
	public static final String INVALID_FIELD_VALUE_ONLY_ALPHANUMERIC_HYPHEN_DOT = "TXNSCU107";
	public static final String INVALID_PWD_RESET_MOB_COOLING = "USER993228";
	public static final String CC_LENGTH = "REGBILL001";
	/*Added for NRI PRO/Premia SR-start*/
	public static final String NPP_SAVING_ACCT_MANDATORY = "SR618";
	public static final String NPP_INVALID_SAVING_ACCT_STATUS ="SR6667";
	public static final String NPP_DEBIT_FREEZE = "SR6666";
	public static final String NPP_INVALID_COUNTRY = "SR6671";
	public static final String NPP_INVALID_COUNTRYCODE = "SR6663";
	public static final String NPP_LIEN_MARKED = "SR6664";
	public static final String NPP_INACTIVE_ACCOUNT = "SR6665";
	/*Added for NRI PRO/Premia SR-end*/

	/* Added for SR73653446 */
	public static final String INVALID_PWD_RESET_0DAYS = "USER993229";
	/* Added for SR73653446 */
	public static final String CCRT_INVALID_PAYEE_ID = "ADMBE995602";
	public static final String PMMT_INVALID_BANK_ID = "FTMBE995603";
	public static final String PMMT_INVALID_BRANCH_NAME = "FTMBE995604";
	public static final String PMMT_INVALID_ZIP = "FTMBE995605";
	public static final String PMMT_INVALID_ZIP_EXTN = "FTMBE995606";

	/* Added for CR-2054-56545_smsNcash */
		public static final String MOBILE_NUMBER_NOT_REGISTERED_SNC = "TXNSCU108";
		public static final String SPACES_IN_REGISTERED_MOBILE_NUMBER = "TXNSCU109";

	/* Added for CR-2054-56545_smsNcash */
		/*added for payee name and senders name validation in neft cc */
		public static final String CC_LENGTH_PAYEE ="NEFTCC101";

		/* Downtime message on RIB for iCore migration */
		public static final String ICORE_DOWNTIME ="USER993230";
		/* Downtime message on RIB for iCore migration */

		public static final String CARD_STATUS_LOST = "SERVCU327";

		 public static final String CREDITCARD_LINKED_USERID = "SERVCU1003";
		 public static final String ACCOUNT_LINKED_USERID = "SERVCU1004";
		 public static final String LOAN_LINKED_USERID = "SERVCU1005";
	   public static final String RECEIVE_FUNDS_FAIL ="RECV995610";
	    public static final String RECEIVE_FUNDS_TRAN_FAIL ="RECV995611";

	     public static final String DEBITCARD_ALREADY_LINKED = "SERVCU328";
	     /* Added for CR-2054-58289 */
		public static final String INVALID_LPG_NO = "SERVCU329";
		public static final String INVALID_IFSC_CODE = "SERVCU330";
		/* Added for CR-2054-58289 */

		/* Added for CR-2054-56545 */
		public static final String ICASH_TIMEOUT = "TXNSCU110";
		/* Added for CR-2054-56545 */
		public static final String IS_FD_RD_IWISH_HOT_TXNS = "TXNSCU111";
		public static final String IS_FD_RD_IWISH_SCHD_TXNS = "TXNSCU112";
		public static final String IS_FD_RD_IWISH_ACCT_NO = "TXNSCU113";

		/* Added for Favorite transactions for PMR/DTH */
		public static final String FAV_PAYEE_DUPLICATE = "TXNSCU114";
		public static final String FAV_SUBSCRIBER_ID_DUPLICATE = "TXNSCU115";

	public static final String NO_FAV_FETCHED = "AD6669";
	 public static final String CARD_TYPE_UAD_MANDATORY = "SERVCU1006";


	public static final String INVALID_DATE_9DAYS = "SRDB001";

	/*Added for Income Tax e-Filing CR -Start*/
	public static final String No_ACCNT_SELECTED = "TXN6675";
	public static final String PAN_NOT_FETCHED = "TXN6676";
	public static final String PAN_RESPONSE_NOT_RECEIVED = "TXN6677";
	/*Added for Income Tax e-Filing CR -End*/

	/* Added for SR80162034 */
	public static final String ADDR2_FIRST_CHAR_SHOULD_NOT_BE_NUMERIC = "SERVCU400";
	/* Added for SR80162034 */
		public static final String MOBILENUMBER_IS_MANDATORY_IMOBILE ="IMOB001";
		public static final String INVALID_MOBNO_IMOBILE ="IMOB002";

		/*Added for GridCard Validation*/
		public static final String GRID_VALUES_NOT_FETCHED ="TXNGR9957";
		public static final String GRID_EXCEPTION ="TXNGR9958";
		public static final String GRID_VALIDATION_FAILED ="TXNGR9959";
		public static final String INVALIDCREDIT_CARDNO = "SERVCU1008";
		/* Added By ALOK for generate Credit Card Pin Online */
		public static final String CARDTYPE_INVALID ="SERCPG9960";
		public static final String BLOCK_CODE_INVALID ="SERCPG9961";
		public static final String SELECT_REMITTANCE_SCHEME = "SER764469";
		public static final String TERMS_N_CONDITIONS = "SER764468";

		public static final String ACT_CODE_INVALID = "SERCPG9962";
		public static final String CVV_INVALID_ATTEMPTS_CASE ="SRCPG9963";
		public static final String NO_CC_ROWS_FETCHED ="SRCPG764470";
		public static final String PIN_NOT_GENERATED ="SRCPG9965";
		public static final String PIN_GENERATED_SUCCESSFULLY ="SRCPG9966";
		public static final String CREDITCARD_PIN_LENGTH_INVALID ="SRCPG9967";
		public static final String CREDITCARD_PIN_NO_SPACES ="SRCPG9968";
		public static final String CREDITCARD_PIN_MANDATORY ="SRCPG9969";
		public static final String CREDITCARD_PIN_NOT_MATCHED ="SRCPG9970";
		public static final String NEW_RECORD_UPDATED_SUCCESSFULLY ="SRCPG9971";
		public static final String CPG_PINGEN_HOST_SUCCESS ="SRCPG9972";
		public static final String CPG_PINGEN_FACILITY_DISABLED ="SRCPG9974";
		public static final String ACCOUNT_AGE_DAYS = "SER995663";
		   public static final String FTA_PAN_UPDATE_MAND = "SERVCU995660";
		public static final String CPG_PINGEN_FACILITY_BLOCKED ="SRCPG9975";
		/*Added for Pradhan Mantri Bima SR's*/
		public static final String GENDER_MANDATORY = "SERSBY9980";
		public static final String NOMINEE_NAME_MANDATORY = "SERSBY9981";
		public static final String NOMINEE_REL_MANDATORY = "SERSBY9983";
		public static final String NOMINEE_ADDR_MANDATORY = "SERSBY9982";
		public static final String INVALID_NOMINEE_NAME = "SERSBY9984";
		public static final String INVALID_NOMINEE_REL = "SERSBY9985";
		public static final String INVALID_GUARDIAN_NAME = "SERSBY9986";
		/*Added for Pradhan Mantri Bima SR's*/
		public static final String CONSUMER_CODE_INVALID = "TXNCCO9989";
		/*Added for Quick CheckOut */
		public static final String USER_NOT_REGISTERED_QUICKCHECKOUT = "TXNQCO9990";
		public static final String POCKETS_MONTH_INVALID ="PCKB001";

		public static final String INCORRECT_IFSC_CODE = "TXSS111";

		public static final String CAR_FAILURE_ACTCODE = "SERVCU995664";
		public static final String LIVE_ASST_SESSION = "COBR9951";
		public static final String IFSC_NOT_VERIFIED = "IFSC9953";
		public static final String IFSC_MANDATORY = "IFSC9954";

		public static final String ONE_REQUEST_ALLOWED_PER_DAY="MAY107770";
		/*Added for Favourite Payee CR*/
		public static final String USER_REGISTERED_AS_FAVOURITE = "TXNFV995711";
		public static final String NO_FAVOURITE_AVAILABLE = "TXNFV995712";

		/*Added for RD Alliance  CR*/

public static final String INVALID_RD_ALLIANCE_AMOUNT = "SERVCU995801";
public static final String MIN_FD_ACCOUNT_BALANCE = "SERVCU995806";
public static final String INVALID_WITHDRAWAL_AMOUNT = "SERVCU995807";
public static final String MAND_WITHDRAWAL_AMOUNT = "SERVCU995808";
		public static final String IMPS_FUNCTIONALITY_NOT_AVAILABLE = "TXNFV995804";
		public static final String MAX_NO_FAVOURITE = "TXNFV995805";
		public static final String CRD_SERVICE_REQUEST_SUCCESS_MESSAGE = "SERVCU995809";
		public static final String PAYEE_ALREADY_FAV = "TXNFV995810";
		public static final String BILLER_ALREADY_FAV = "TXNFV995811";


		//Added for CR-2054-70834 SR for IB payment status enquiry.

		public static final String PAYID_NOT_WEEK_OLD = "SERVCU995812";
		public static final String NEFT_RTGS_PAY_ID = "SERVCU995813";
		public static final String NEFT_ON_HOLIDAY="TXN9931";
		public static final String RTGS_ON_HOLIDAY="TXN9932";

		//Added for Rewards enroll CR
	public static final String LOOKUP_MANDATORY="SERVCU995816";
		public static final String ENROLL_FAILED = "ACCTCU2001";

//Added for gold bonds CR

    public static final String UNITS_OUT_OF_LIMIT = "SERVCU996033";
	public static final String UNITS_SHOULD_NOT_HAVE_DECIMAL = "SERVCU996015";
	public static final String INVALID_DOB_SGB = "SERVCU996016";
	public static final String DPID_SGB_INVALID = "SERVCU996017";
	public static final String ACCT_BAL_INSUFFICIENT_FOR_SGB="SERVCU996018";
	public static final String ACCOUNT_MANDATORY="SERVCU33061";
	public static final String USER_MOBILE_MISMATCH="SERVCU996034";
	public static final String USER_EMAIL_MISMATCH="SERVCU996035";
	public static final String INVALID_DP_ID_LENGTH="SERVCU996031";
	public static final String INVALID_DP_CLIENT_ID_LENGTH="SERVCU996032";
	public static final String FUTURE_DOB="SERVCU996030";
	//added for CRD_SERVICE_REQUEST_FAILURE_MESSAGE
		public static final String DIG_REG_FAIL = "DR001";
		public static final String DIG_DREG_FAIL = "DR002";

	public static final String LIEN_MARKED_CRD = "SR996019";
	public static final String FDRD_ACCOUNT_FREEZE = "SR996020";
	public static final String SB_ACCOUNT_FREEZE = "SR996021";
	public static final String FD_LINKED = "SR996022";
	public static final String CLOSED_FDRD_ACCOUNT="SR996023";
	public static final String CLOSED_SYS_ERROR="SR996024";
	public static final String FI_VISIT_BRANCH="SR996025";
	public static final String FI_REPAY_ACCOUNT_NOT_SAME="SR996026";
	public static final String FI_CLOSURE_OF_ACCOUNT="SR996027";
	public static final String FI_CLOSURE_DATE_CANT_BE_LATER_THAN_BOD="SR996028";

	public static final String EMAS_HOST_NOT_AVAILABLE = "DIG996072";
	public static final String CERTIFACTE_DEREGISTRATION_FAILED = "DIG996073";
	public static final String CERTIFACTE_ALREADY_REGISTERED = "DIG996074";
	public static final String CUSTOMER_ALREADY_EXISTS = "DIG996075";
	public static final String REGISTRATION_FAILED = "DIG996076";
	public static final String NOT_REGSITERED_FOR_DIGITAL_CERTIFICATE = "DIG996071";
	public static final String CERTIFICATE_NOT_MATCHING = "DIG996077";
	public static final String CERTIFICATE_VERIFICATION_FAILED = "DIG996078";

	//Added for APY CR
	public static final String MANDATORY_SPOUSE_NAME="SERVCU996090";
	public static final String MANDATORY_GUARDIAN_NAME="SERVCU996091";
	public static final String SPOUSE_NAME_NOT_VALID="SERVCU996096";
	public static final String GUARDIAN_NAME_NOT_VALID="SERVCU996097";
	public static final String NOMINEE_NAME_NOT_VALID="SERVCU996098";
	public static final String NOMINEE_RELATION_FORMAT_NOT_VALID="SERVCU996099";
	public static final String INVALID_AGE_RANGE="SERVCU996105";
	public static final String MANDATORY_GUARDIAN_NAME_APY="SERVCU996106";
	public static final String MANDATORY_SPOUSE_NAME_APY="SERVCU996107";
	public static final String NOMINEE_RELATION_APY="SERVCU999931";

		/*Added for CR-2054-72328*/
		public static final String INSUFFICIENT_BALANCE = "SERSBY1708";
		/*Added for CR-2054-72328-end*/

		//Added for CR-2054-76859
	public static final String ACC_STAT_CHECK="SERVCU996082";
	// FD Closure
	public static final String MIN_WITHDRAWAL_AMOUNT="SERVCU98665";
	public static final String AMOUNT_WITHDRAWAL_RENGE="SERVCU98666";

	//Added for CR-2054-70314 SR Validation - start
	public static final String SIX_MONTHS_OLD_ACCOUNT="SRSB999200";
	public static final String SB_INACTIVE_ACCOUNT="SRSB999201";
	public static final String SB_DORMANT_ACCOUNT="SRSB999202";
	public static final String SB_FROZEN_ACCOUNT="SRSB999203";
	public static final String SB_CURRENT_ACCOUNT="SRSB999204";
	public static final String SB_LIEN_ACCOUNT="SRSB999205";
	public static final String SB_DEBIT_BALANCE="SRSB999206";
	public static final String TRANSACTIONS_WERE_FOUND_FOR_THIS_ACCOUNT="SRSB999208";

	public static final String INVALID_FIELD_FOR_MATURITY_PROCEEDS_FD = "SRFD999100";
	public static final String INSTANCE_CC_AGAINST_FD_FOR_JA_NOT_POSSIBLE = "SRFD999101";
	public static final String INSTANCE_CC_AGAINST_FD_FOR_MINOR_NOT_POSSIBLE = "SRFD999102";
	public static final String DOB_NOT_UPDATED = "SRFD999103";

	public static final String NRI_ACC_INVALID_STATUS="SRNRI999207";
	//Added for CR-2054-70314 SR Validation - end
public static final String CSIP_UPDATE_ERROR = "DR003";
public static final String DEBITCARD_PIN_NO_SPECIAL_CHAR = "DPGSR033";

	//Added for Search Box
	public static final String SEARCH_STRING_LESS_THAN_THREE = "SRCH993";

	//Added For CR-2054-78471 - CUSR DEL Flag Update
	public static final String EXCEPTION_UPDATE_CUSR_FLAG = "UTMLEX0044";

	//Added For CR-2054-78471 - CUSR Password Flag Update
	public static final String EXCEPTION_UPDATE_CUSR_PWD_FLAG = "UTMLEX0045";

	public static final String PRINCIPAL_DUES_ERROR = "SRLOAN995832";
	public static final String MATURITY_DATE_ERROR = "SRLOAN995833";

	public static final String SEQUENCE_NOT_GENRATED_PROPERLY = "SR107619719 ";

	public static final String FD_MATURITY_CLOSURE_ERROR = "SRFD996201";
	public static final String FD_RENEWED_MATURITY_CLOSURE_ERROR = "SRFD996202";

		//Added for shoppingmall amount mismatch case for amount to be debited and requested by merchnat
		public static final String AMOUNT_MISMATCH_MANIPULATED="TRAN31051";
		public static final String PAN_NO_NOT_FETCHED = "SR110426500 ";
		public static final String INVALID_EQUITY="SERVCU999952";
     public static final String INVALID_ASSET="SERVCU999953";
     public static final String FATHER_NAME_NOT_VALID="PROD999954";


	   //added for  operator name
	    public static final String OPERATOR_NAME_NULL="TXNFV996901";


	  //Added by rajababu
	  public static final String FIELDVALUE_SHOULDBE_ALPHABET = "TXNSCUB904";
	  public static final String FIELDVALUE_SHOULDBE_LENGTH = "TXNSCUB900";
	  public static final String SPECIAL_CHAR_NOT_ALLOWED = "TXNSCUB901";
	  public static final String ONLY_HYPEN_ALLOWED = "TXNSCUB902";
	  public static final String ONLY_NUMBERS = "TXNSCUB903";
	  //end by rajababu
		//added for CR_78920_Value added RD
	public static final String INVALID_RD_ALLIANCE_AMOUNT_TEXT = "SERVCU995899";
	public static final String INVALID_COMMON_CODE = "SERVCU995864";
	public static final String INVALID_CODE_TYPE = "SERVCU995865";
	public static final String INVALID_CODE_DESC = "SERVCU995866";
	public static final String INVALID_SPECIAL_CHARS_CODE_TYPE = "SERVCU995867";
	public static final String INVALID_SPECIAL_CHARS_COMMON_CODE = "SERVCU995868";
	public static final String INVALID_FIELD_VALUE_ONLY_ALPHANUMERICALPHA_HYPHEN_NUMERIC = "TXNSCU103";
	public static final String LIEN_FD_ACCOUNT = "CR205470314 ";
	public static final String ISIN_LIST_NOT_AVAILABLE="DMTISIN001";
	    //Added for Pay on Delivery messages in API call
	    public static final String INVALID_PRODUCT_DETAILS="TRAN960";
	    public static final String INVALID_IP_ADDRESS="TRAN968";
		public static final String PAYMENT_EXPIRED = "TRAN962";
		public static final String INVALID_OTP_ENTERED_COD = "TRAN963";
		public static final String COD_OTP_EXPIRED = "TRAN964";
		public static final String PRODUCT_MISMATCH_OTPGEN_PAYMENT = "TRAN965";
		public static final String PMT_ALREADY_DONE = "TRAN966";
		public static final String INVALID_AMOUNT_COD = "TRAN967";
		public static final String NOTMANDATORY_GUARDIAN_NAME_NPR="SERVCU999947";
		public static final String MANDATORY_GUARDIAN_NAME_NPR="SERVCU996106";
//added for debit card limits
public static final String IDD_DOMESTIC = "TXNSCUB999944";

public static final String DOMESTIC_INTERNATIONAL_LIMITS ="SERVCU999993";
public static final String PERMANENT_TEMPORARY_ENTRY="SERVCU999984";
public static final String DESIRED_LIMIT_FOR_CASH="SERVCU999985";
public static final String DESIRED_LIMIT_FOR_MERCHANT="SERVCU999986";
public static final String DESIRED_LIMIT_FOR_ONLINE="SERVCU999987";
public static final String INTERNATIONAL_PERMANENT_TEMPORARY_ENTRY="SERVCU999988";
public static final String INTERNATIONAL_DESIRED_LIMIT_FOR_ONLINE="SERVCU999989";
public static final String INTERNATIONAL_DESIRED_ONLINE__TRANSACTION="SERVCU999990";

//end debit card limits

public static final String USER_NOT_IN_SESSION="USER996212";
public static final String ACCOUNT_NOT_AVAILABLE="USER996213";
public static final String ACCOUNT_STATUS="SERVCU996106";

		public static final String DECIMAL_AMOUNT = "RECH99956";
		public static final String CIRCLE_INVALID = "RECH99957";

		public static final String SCHEDULEID_DISABLED = "TRAN99969";
public static final String NO_RECORDS_FETCHED_FROM_DGLK = "SERVCU996023";

public static final String DIGI_LOCKER_CALLBACK_FAILED = "SERVCU996024";

public static final String AADHAR_VALIDATION = "SRADH8888881";
/*Added for CR-2054-76630 Quick Checkout API - start*/
public static final String QUICK_CHECKOUT_API_ENABLE = "TRAN7659";
public static final String QUICK_CHECKOUT_MERCHANT_ENABLE = "TRAN7679";
public static final String QUICK_CHECKOUT_MERC_ENABLE = "TRAN8643";
public static final String INSERTION_FAILED_TO_QCAT = "TRAN3110";
public static final String QUICK_CHECKOUT_OTP_EXPIRED = "TRAN3114";
public static final String QUICK_CHECKOUT_INVALID_DETAILS ="TRAN3113";
public static final String QUICK_CHECKOUT_PAYMENT_DONE ="TRAN3112";
public static final String QUICK_CHECKOUT_NO_RECORD ="TRAN3115";
public static final String QUICK_CHECKOUT_INVALID_OTP ="TRAN3116";
public static final String QUICK_CHECKOUT_FUNTIONALITY ="TRAN3111";
public static final String QUICK_CHECKOUT_MOBILE_ENABLE = "TRAN8644";

/*Added for CR-2054-76630 Quick Checkout API - end*/
	//Added For Bill Pay Through SMS START
	public static final String BILLPAY_MORETHAN_ONEPRESENTMENT="USER888888";
	public static final String BILLPAY_NO_PRESENTMENT_BILLS="USER888889";
	//Added For Bill Pay Through SMS END
	//CR-2054-86484
	public static final String LOANPAY_PAYMENT_PRODUCTID ="USER996092";
	public static final String LOAN_PRODUCTID_LIST_NOT_AVAILABLE="USER995208";
	//CR-2054-86484



      public static final String AMOUNT_BELOW_SIXTY="TXNSCUB910";
      public static final String AMOUNT_SIXTY_EIGHTY="TXNSCUB911";
      public static final String AMOUNT_EIGHTY="TXNSCUB912";
      public static final String INVALID_FORMAT="TXNSCUB913";
   public static final String RECORD_NOT_FOUND_IN_BAFT = "USRCUS420";
public static final String EMANDATE_AVAILABLE_BALANCE = "TRAN14045";
 public static final String MAX_ATTEMPTS_EXCEED = "TXNSCU104";
public static final String BILLPAY_AUTOFLAG_PRESENTMENT_BILLS="USER888884";
public static final String ITRACK_NO_RECORD_FOUND = "ITRACK0008";
public static final String BILL_CYCLE_NOT_ACCEPTED="USER888887";
public static final String BILL_CYCLE_DATE_NOT_VALID="USER888886";
public static final String BILL_CYCLE_DATE_INVALID="USER888885";
public static final String BILL_CYCLE_CHOOSING_DATE_INVALID="USER888883";
public static final String TOKEN_NOT_VALID="TOKEN996219";

public static final String INVALID_AGE_RANGE_NPR="SERVCU200020";
public static final String INVALID_BRNACH_NPR="SERVCU200021";

public static final String YEAR_MANDATORY_FIELD="USER996093";
		/*Added for LOMBARD Payment CR-2054-84963 -start*/
		public static final String INSERTION_FAILED_TO_LPDT = "TRAN3117";
		public static final String LOMBARD_OTP_EXPIRED = "TRAN3118";
		public static final String LOMBARD_INVALID_DETAILS ="TRAN3119";
		public static final String LOMBARD_INVALID_OTP ="TRAN3120";
		public static final String LOMBARD_PAYMENT_DONE ="TRAN3121";
		public static final String LOMBARD_NO_RECORD ="TRAN3122";
		public static final String LOMBARD_INVALID_PRIMARY_ACC ="TRAN3123";
		/*Added for LOMBARD Payment CR-2054-84963 -end*/

 public static final String FUNCTIONALITY_NOT_AVAIL_CREDITCARD = "PKR99970";
public static final String INVALID_MOBILENO_NPR = "SERVCU9994";
public static final String INVALID_TRAVELCARD_NO ="SERLTC9994";
 public static final String FAVOURITE_UBPS_DOWN= "FAV99971";

public static final String MOTHER_NAME_NOT_VALID="SERVCU999936";

      public static final String RESIDENTIAL_STATUS = "TRAN3124";
      public static final String VISA_TYPE = "TRAN3125";
      public static final String VISA_EXPIRY = "TRAN3126";
      public static final String PIO_CHECKBOX = "TRAN3127";
      public static final String SIGN_DOC_CHECKBOX = "TRAN3128";
      public static final String VISA_ISSUE = "TRAN3131";
      public static final String INVALID_PASSPORT_NUMBER = "SERVCU999937";
      public static final String INVALID_PLACE_OF_ISSUE = "SERVCU999938";
      public static final String FUTURE_DOI = "SERVCU999939";
      public static final String PAST_DOE = "SERVCU999940";
      public static final String INVALID_MOBILE_NUMBER = "SERVCU999941";
	  public static final String SBN_SBN_TAI = "SERVCU1222";
	public static final String SBN_SBN_TNAI = "SERVCU1223";
	public static final String SBN_SBN_DATE = "SERVCU1224";
	public static final String SBN_SBN_PAN_ACK = "SERVCU1225";
	public static final String SBN_SBN_TAI_NUMERIC = "SERVCU1226";
	public static final String SBN_SBN_TNAI_NUMERIC = "SERVCU1227";

public static final String LOANBRANCH_ALREADY_EXISTS="USER888880";
public static final String WRONG_MAIL_ID_FORMAT="WMF3142";

public static final String BLANK_MOBILE_NUMBER = "SERVCU999943";
public static final String BLANK_CONTACT_NUMBER = "SERVCU999944";
public static final String FIELD_MAND_CODE = "SERVCU100257";
public static final String JHA_NO = "SERVCU3132";
public static final String JHA_NO_MAN = "SERVCU3133";
public static final String SBN_PAN_CHECK = "SERVCU1228";
public static final String SBN_PAN_VAL = "SERVCU1229";
public static final String COMPANY_MAN = "SERVCU3134";
public static final String COUNTRY_MAN = "SERVCU3135";
public static final String FROM_DATE_BLANK="TXN3215";
public static final String TO_DATE_BLANK="TXN3216";
public static final String SPECIAL_CHARS_SBN_NOT_ALLOWED = "SER3136";
public static final String SBN_PAN_DATE = "SERVCU1230";

public static final String DATEOFBIRTH_CHECK_ERROR = "SERVCU777777";
public static final String SBN_PDF_VISA = "SERVCU1231";

public static final String HOME_LOAN_ACCOUNT_LENGTH ="SERVCU996197";
public static final String INVALID_HOME_LOAN_ACCOUNT="SERVCU996198";
public static final String HOME_LOAN_SHOULD_CONTAIN_ONLY_ALPHANUMERIC="SERVCU996199";
public static final String OMNIDOCS_FAILURE = "SERVCU96571";
//added for travel card start
	public static final String TRAVELCARD_DEACTIVE = "FXTC3150";
	public static final String TRAVELCARD_TRADE_STATUS_DEACTIVE = "FXTC3151";
	public static final String TRAVELCARD_PRODUCT_STATUS_DEACTIVE = "FXTC3152";
	public static final String TRAVEL_CARD_TRAVEL_VAL_DAY = "TRAN3159";
	public static final String TRAVEL_CARD_PASSPORT_EXPIRY = "TRAN3160";
	public static final String TRAVELCARD_TRADE_STATUS_CURR_TRADE_STATUS_DEACTIVE = "FXTC3161";
	public static final String TRADE_STATUS_DOWN_CURR_TRADE_STATUS_UP = "FXTC3162";
	public static final String TRADE_STATUS_UP_CURR_TRADE_STATUS_DOWN = "FXTC3163";
	public static final String TRAVEL_CARD_RETURN_DAY = "TRAN3153";
	public static final String TRAVEL_CARD_TRAVEL_DAY = "TRAN3154";
	public static final String PROMO_CODE_INVALID = "TRAN3157";
	public static final String TRAVELCARD_CURRENCY_UNIT_INVALID = "FXTC3158";
	public static final String TRA_DATE_NULL = "TRAN100257";
	public static final String PRODUCT_STATUS_DOWN_CURR_PRODUCT_STATUS_UP = "FXTC3164";
	public static final String PRODUCT_STATUS_UP_CURR_PRODUCT_STATUS_DOWN = "FXTC3165";
	public static final String CURRENCY_PRODUCT_STATUS_INACTIVE = "FXTC3166";
	public static final String TRAVEL_CARD_PRODUCT_STATUS_INACTIVE = "FXTC3167";
	public static final String TRAVEL_CARD_PCMS_PASS_PORT = "TRAN3168";
	public static final String TRAVEL_CARD_CURRENCY_INACTIVE = "FXTC3169";
	public static final String PRODUCT_STATUS_DOWN_CURR_PRODUCT_STATUS_DOWN = "FXTC3170";
	public static final String TRAVEL_CARD_CURRENCY_UNITS = "TRAN3171";
	public static final String TRAVEL_CARD_PASSPORT_EXPIRY_CHECK = "TRAN3172";
	public static final String TRAVEL_CARD_DOB_CHECK = "TRAN3173";
	public static final String TRAVEL_CARD_DYNAMIC_ERROR_MESSAGE = "FXTC3174";
	public static final String TRAVEL_CARD_PASSPORT_EXPIRY_CHECK_RETURNDATE = "TRAN3175";

	//added for travel card End
//country restrict
public static final String SBN_COUNTRY_RESTRICT = "SERVCU3137";

//JH restrict
public static final String SBN_JH_RESTRICT = "SERVCU3138";

//upload format validation
public static final String SBN_UPLOAD_FORMAT_RESTRICT = "SERVCU3139";

public static final String MAN_DETAILS = "SERVCU9960";
public static final String CONFORM_LOAN_ACCOUNT_LENGTH="SERVCU996195";
public static final String LOAN_ACCOUNT_RE_ENTER_LOAN_ACCOUNT="SERVCU996196";
public static final String VEHICLE_LOAN_ACCOUNT_LENGTH ="SERVCU998649";
public static final String INVALID_VEHICLE_LOAN_ACCOUNT="SERVCU998650";
public static final String VEHICLE_LOAN_SHOULD_CONTAIN_ONLY_ALPHANUMERIC="SERVCU998651";

public static final String VEHICLE_ACCOUNT_RE_ENTER_LOAN_ACCOUNT="SERVCU998648";
public static final String AADHAR_UPLOADED_FILE_MAX_SIZE="SRNAC888879";
public static final String NAMEONCARD = "SR996670";
/*Added for NPS E-sign -start*/
public static final String ESIGN_UPLOAD_FORMAT_RESTRICT = "SERVCU3240";
/*Added for NPS E-sign -end*/
public static final String PINCODE_EXISTS = "SR996669";

/*Added for FATCAnCRS_Validation_Updated */
public static final String INVALID_LENGTH_ID ="SERFTC996231";
public static final String CHAR_NOT_ALLOWED ="SERFTC996232";
public static final String NUMBER_NOT_ALLOWED ="SERFTC996233";
public static final String SPL_CHAR_NOT_ALLOWED ="SERFTC996234";
public static final String INVALID_ID ="SERFTC996235";
public static final String CTFD_LIST_VALUE ="SERFTC996236";

public static final String CIBIL_REPORT_MANDATORY="SERVCU996035";
public static final String INVAL_TIN_NUM ="SERFTC996237";

public static final String SPL_NUMBER_NOT_ALLOWED ="SERFTC996238";
public static final String JOINT_ACCOUNT_AS_REDEMPTION_NOT_ALLOWED ="SERFTC996239";
public static final String SIDT_ALREADY_UPDATED = "SERVCU1230";
public static final String PG_TO_EMI_CONVERT_ELIGIBILTY = "TRAN3177";
public static final String AMOUNTLESS_INVALID_GPR = "RECH999961";
public static final String AMOUNTMORE_INVALID_GPR = "RECH999962";


public static final String INVALID_ECOL_PAYEE ="ECOL2000058";
public static final String CFR_FD_GUADIAN_CODE_VAL="SRFD996696";

public static final String INSERTION_FAILED_TO_PACT = "TRAN3181";
public static final String OFFICE_EXTN_NOT_VALID = "SERVCU200024";
public static final String INSURANCE_NOT_ALLOWED_FOR_AGE ="TRAN3180";


 public static final String NSDL_SERVER_DOWN = "SERVCU8169";
    public static final String FI_SERVER_DOWN = "SERVCU8170";
    public static final String ONLY_CAP_ALPHABETS_FOR_FOURTH_ONE = "SERVCU8172";

public static final String GPR_PAYMENT_PROCESS_FAL = "REC814405";
public static final String GPR_PAYMENT_FAL = "REC814405";

	public static final String SPL_CHAR_IPO = "IPO200054";

public static final String IPAY_INVALID_PRIMARY_ACC="CUST996241";
public static final String NSDL_PANNO_WORNG = "SERVCU8182";
public static final String TC_TO_DATE_ERR = "TC0002";

public static final String ACTIVE_DORMANT_ACCOUNT="SERVCU996674";
public static final String ACTIVE_INACTIVE_ACCOUNT="SERVCU996675";

public static final String TC_MOB_EMPTY="TCMOB001";
public static final String TC_EMAIL_EMPTY="TCEMAIL001";
public static final String INVALID_LOAN_ID="CUST888871";
public static final String ILOAN_DETAILS_NOT_FETCH="CUST888872";

public static final String HEALTH_INSURANCE_MANDATORY = "HIPCU200601";
public static final String HEALTH_INSURANCE_ADULT_DOB = "HIPCU200602";
public static final String HEALTH_INSURANCE_INVALID_PLAN_CODE = "HIP9002";
public static final String HEALTH_INSURANCE_PIN_CODE_MANDATORY = "HIP9003"; 

/* Added for Add Payee */
public static final String ADD_PAYEE_RESTRICTED_ACC_STATUS = "TXNSS3191";
public static final String RESTRICT_NON_RESIDENT_INDIA="SERVCU8199";

/* Added for CCEmpowerment */
public static final String FEBATX0019 = "FEBATX0019";
public static final String RVISA_TYPE="SERFTC8193";
public static final String RKC_COUNTRY ="SERFTC8191";

//userId Password added by Naidu
public static final String USPWD_DEBITCARD_NUMBER_MANDATORY = "SERVCU999859";
public static final String USPWD_DEBIT_CARD_NUMBER_INVALID = "SERVCU999858";
public static final String REST_OTHER_THAN_INDIA_FOR_RESIDENT="SERVCU8129";

public static final String COUNTRY_PER_BANK_SEL_COUNTRY_MATCH="SERVCU7161";
	public static final String PAYEMENT_DATE_MANDATORY = "SERVCU3789";
public static final String IWISH_ADDFUNDS_MANDITORY = "SERVCU8200";
public static final String IWISH_ADDFUNDS_ONLY_CHARACTERS = "SERVCU8201";
public static final String IWISH_ADDFUNDS_AVAILABLE_BAL = "SERVCU8202";
public static final String IWISH_ADDFUNDS_TARGETAMOUNT_BAL = "SERVCU8203";
public static final String FILE_PASSWORD_PROTECTED = "SERVCU399";
public static final String IWISH_AMOUNTVAL_CHECK = "SERVCU996707";
public static final String STATUS_OF_TRANSACTION_DATE="CUST996359";
public static final String IWISH_RECURRING_DEPOSIT_VAL = "TXNSCU8220";
public static final String IWISH_INTIALAMOUNTVAL = "TXNSCU8215";
public static final String IWISH_RECURRING_VAL = "TXNSCU8208";
public static final String ACCOUNT_IS_DORMANT_STATUS="SERVCU8012";
public static final String ACCOUNT_IS_INACTIVE_STATUS="SERVCU8013";
public static final String ACCOUNT_HAVE_INSUFF_BAL="SERVCU8014";
public static final String IS_SIP_DOWN_TIME="SERVCU996267";
public static final String LOGOUT_FEEDBACK_SUBMISSION="CRLOGOUT1234";
public static final String UNABLE_TO_FETCH_PORTFOLIO="SERVCU996268";
public static final String UNABLE_TO_FETCH_PROFILE="SERVCU996269";
public static final String PLCC_WTL_OFFER_NOT_ELIGIBLE="PWTL12345";
public static final String COINTRIBE_SERVER_DOWN = "SERVCU996278";
public static final String CAR_MOP = "SERVCU996280";
public static final String ADA_FI_SUCCESS="SERADA996276";
public static final String ADA_FI_FAILURES="SERADA9000";
public static final String ADA_NO_ACCOUNTS="SERADA996280";

public static final String INVALID_RD_MONTHLY_AMOUNT = "SERVCU995469";
public static final String MAX_TENURE_FOR_RD_MONTHLY = "SERVCU995470";
public static final String MIN_TENURE_FOR_RD_MONTHLY = "SERVCU995471";
public static final String MAXIMUM_FDMI_AMOUNT_SPECIAL_CHARACTER = "SERVCU995475";
public static final String MAXIMUM_FDMONTHLY_AMOUNT_ERROR = "SERVCU995476";
public static final String MAXIMUM_FDMITENURE_ERROR = "SERVCU995477";
public static final String MANDATORY_MOBILENO ="USER996299";
public static final String INVALID_MOBILENO ="USER997250";
public static final String UPDATED_MOBILENO_SUCCESS="USER996297";
public static final String UPDATED_MOBILENO_FAILURE="USER996298";
public static final String PLCC_BT_OFFER_NOT_ELIGIBLE="PLBT12345";
public static final String TWLOAN_CIBIL_FAILURE="TWLOAN12345";
public static final String TWLOAN_CONNECTION_ERROR = "TWLOAN12346"; 
public static final String TCS_CIBIL_FAILURE = "TWLOAN12347"; 
public static final String TCS_CITY_REQ_FAILURE = "TWLOAN12348"; 
public static final String TCS_DEALER_FETCH_FAILURE = "TWLOAN12349";

public static final String PAY_ACC = "SERVCU996292";

public static final String SELECT_ACCOUNT_NUMBER="TXN8466";
public static final String REMITTER_NAME_MANDATORY="TXN8467";
public static final String INVALID_REMITTER_NAME = "TXN8468";
public static final String SELECT_COUNTRY_NAME = "TXN8469";
public static final String REMITTER_EMAILID_MANDATORY = "TXN8470";
public static final String RQST_AMOUNT_MANDATORY = "TXN8471";
public static final String INVALID_REQUEST_AMOUNT = "TXN8472";
public static final String MORE_OPEN_STATUS_REQUEST = "TXN8473";


public static final String STIR_SUCCESS_RESPONSE="TXN8441";
public static final String STIR_FAILURE_RESPONSE="TXN8442";
public static final String INVALID_FIRST_NAME = "TXN8443";
public static final String INVALID_ACCOUNT_NUMBER_FIFTH_DIGIT = "TXN8444";
public static final String INVALID_COUNTRY_CODE = "TXN8445";
public static final String RESP_INVALID_STATE = "TXN8446";
public static final String RESP_INVALID_ADDRESS1 = "TXN8447";
public static final String RESP_INVALID_CITY = "TXN8448";
public static final String RESP_INVALID_ZIPCODE="TXN8449";
public static final String RESP_INVALID_LANDLINE="TXN8450";
public static final String RESP_INVALID_MOBILENO = "TXN8451";
public static final String RESP_INVALID_EMAIL = "TXN8452";
public static final String RESP_INVALID_NICKNAME = "TXN8453";
public static final String RESP_INVALID_CHANNELID = "TXN8454";
public static final String INVALID_SRNO = "TXN8455";
public static final String RESP_INVALID_REMITTER_NAME = "TXN8456";
public static final String RESP_INVALID_PROCESSDATE="TXN8457";
public static final String RESP_INVALID_INITIATEDATE="TXN8458";
public static final String RESP_INVALID_STATUS = "TXN8459";
public static final String RESP_INVALID_LASTNAME = "TXN8460";
public static final String RESP_PARAMETERS_NULL = "TXN8461";
public static final String INVALID_RQST_AMOUNT = "TXN8462";
public static final String ALREADY_EXISTS_ACCOUNTNUMBER = "TXN8463";
public static final String INVALID_REMITTER_EMAILID = "TXN8464";
public static final String REMITTER_EMAILID_ALREADY_EXISTS = "TXN8465";

public static final String INVALID_STIR_RESPONSE = "TXN8474";
public static final String RQSTMONEY_CONNECTION_ERROR = "TXN8475";
public static final String PURPOSE_OF_REQ_MAND ="TXN8477";
public static final String UNIQUE_EMAIL_ID_MAND ="TXN8478";
public static final String XSERVICE_INVALID_LOP_RESPONSE = "CUST999927";
public static final String CLOSED_ACCOUNT_STATUS="SERVCU642";
public static final String DORMANT_ACCOUNT_STATUS="SERVCU899008";
public static final String MANDATORY_EMPLOYERLIST="SERVCU435";

public static final String RMS_CUST_NAME = "SERVCU996326";
public static final String RMS_PRU_NAME = "SERVCU996327";
public static final String RMS_CUS_NAME = "SERVCU996328";
public static final String RMS_EMI_AMOUNT = "SERVCU996329";
public static final String PRE_EMI = "SERVCU996330";
public static final String SR_DUE_DATE = "SERVCU996336";
public static final String ROBO_INVALID_REDEMPTION_ACCOUNT ="CUST996369";
public static final String ROBO_INVALID_TOKEN="CUST996370";
public static final String TWO_COUNTRYS_SHOULD_MATCH = "SERVCU8299";
public static final String OADT_INSERTION_FAILED = "OADT12349";
public static final String ALPHANUMERIC_ZIP_CODE = "SERVCU8226";


public static final String INSTAHL_LAN_NOT_ACTIVE = "INHL996337";
public static final String INSTAHL_INVALID_RESPONSE = "INHL996338";

     public static final String INVALID_MINOR_DOB="SERVCU8601";
     public static final String INVALID_MAJOR_DOB="SERVCU8602";
     public static final String INVALID_SENIOR_DOB="SERVCU8603";
     public static final String RKU_SINGLE_FILE_SIZE="SERVCU8605";
     public static final String RKU_MUL_FILE_SIZE="SERVCU8606";
     public static final String RKU_EMAILID="SERVCU8607";
     public static final String RKU_MOBILE="SERVCU8608";
     public static final String RKU_CHECKBOX="SERVCU8609";
     public static final String RKU_DOB="SERVCU8610"; 
     public static final String RKU_PAN_DOB="SERVCU8611";
     public static final String RKU_ADDRESS="SERVCU8612";
     public static final String RKU_DOB_EDIT="SERVCU8613";
     public static final String RKU_EDIT_ADDRESS="SERVCU8614";
     public static final String RKU_EDIT_PINCODE="SERVCU8615";
     public static final String RKU_PHOTO="SERVCU8616";
     public static final String RKU_FILE_ERROR="SERVCU8617";

	 

public static final String MAXIMUM_FDMI_AMOUNT_ERROR = "SERVCU995476";
public static final String IPRU_BALANCE_VAL="SERVCU8805";
 //added by shraddha for direct tax payment challan number exceeds
	public static final String CHALLAN_SERIAL_NUMBER_EXCEEDS ="DTPCSNE2203";
	public static final String RKU_IMPROPER_FILENAME="SERVCU8618";
	public static final String NRI_KYC_INVALID_ACCOUNT_ID = "SERVCU8225";
	
	    public static final String IPRU_MAX_BALANCE_VAL ="SERFTC996629";
    public static final String APPONITE_NAME_CHECK ="SERFTC996630";
    public static final String APPONITE_DOB_CHECK ="SERFTC996631";
    public static final String NOMINEE_DOB_CHECK ="SERFTC996632";
    public static final String APPONITE_NAME_ONLY_ALPHABETS ="SERFTC996633";
   
public static final String RKU_AADHAR_CHECKBOX="SERVCU8619";

	public static final String INPUT_INVALID = "CDRCRR"; 
	public static final String DEPXSER_ACCOUNTNO_MANDITORY ="SERFTC996639";
     public static final String DEPXSER_ID_MANDITORY ="SERFTC996640";
     public static final String DEPXSER_TY_MANDITORY ="SERFTC996641";
     public static final String DEPXSER_TM_MANDITORY ="SERFTC996642";
     public static final String DEPXSER_TD_MANDITORY ="SERFTC996643";
	 public static final String COMP_FLY_ENC_ERROR = "ENCP001";
	 public static final String DEPXSER_RD_MUTLTYOFTHREE ="SERFTC996643";

	 
	//added for home loan balance transfer fetching location by shraddha
	public static final String NOT_VALID_LOCATION = "HLNVLOC0801"; 
	                public static final String DMT_MOBILE = "SERVCU200107";
                public static final String DMT_EMAIL = "SERVCU995990";
                public static final String DMT_RADIO_BOX = "SERVCU8620";
                public static final String DMT_RADIO_NO = "SERVCU8621";

	public static final String DBT_COMMON_ERROR="SERVCU996431";
public static final String DBT_AADHAR_NUM="SERVCU996432";
public static final String DBT_AADHAR_LEN="SERVCU996433";
public static final String DBT_INVALID_OTP_CONTENT="SERVCU996434";
public static final String DBT_INVALID_OTP_LENGTH="SERVCU996435";
public static final String DBT_INVALID_OTP_ERROR="SERVCU996436";
public static final String DBT_OTP_SUCCESSFUL="SERVCU996437";
public static final String DBT_DATA_MATCHED="SERVCU996438";
public static final String DBT_DATA_NOT_MATCHED="SERVCU996439";
public static final String DBT_INVALID_AADHAAR="SERVCU996440";
public static final String DBT_RADIO_BOX="SERVCU996441";
	  public static final String DBT_AADHAR_ALREADY_MAPPED="SERDBT996444";
//added for quickcheckout account authentication START
public static final String QUICK_CHECKOUT_ACC_VERIFICATION = "TRAN432"; 
//added for quickcheckout account authentication END

public static final String RKU_AADHAAR = "SERVCU8626";

public static final String OAP_URLGEN_ERROR = "OAPNW002";


public static final String ED_URLGEN_ERROR = "ELNW002";
public static final String TXN_LMT_UPDATE_LMTSCH_MANDATORY = "LMT500000";

	//for ROI processing 
	public static final String UNABLE_TO_FETCH_ROI = "SRFORROI1234";
	public static final String NO_RECORD_FROM_OTFT = "ADMINOTFT1234";
	public static final String INVALID_DATE_BBPS_PAYMENT = "BBPSDATE01234";
	
	//for BBPS payment response error
	public static final String BBPS_PAYMENT_ERROR_FROM_RESPONSE="BBPS500002";
	public static final String IMPS_FT_INVALID_TO_ACCOUNT="IMPS500003";
	public static final String BBPS_REG_MOD_FAILURE="BBPS994056";
	public static final String BBPS_SI_MOD_FAILURE="BBPS369";
	public static final String BBPS_MOD_FAILURE="BBPS994052";
	public static final String BBPS_STP_FAILURE="BBPS994054";
	public static final String BBPS_INVALID_ACCOUNT = "BBPS500004";
	public static final String BBPS_PAYMENT_FAILURE = "BBPS203";	
	public static final String BBPS_PAYMENT_INCORRECT_STATUS = "BBPS309";
	//for deleting payee from admin
	public static final String ERROR_OCCURED_WHILE_DELETING_PAYEE = "ADMOTFT500028";
	public static final String OTFT_TXN_PROCESSED_ALREADY = "ADMOTFT500035";
	//added for block debit card
	public static final String SR_BLOCK_CARD_BLOCKTYPE = "SRBDC500036";
	public static final String SR_BLOCK_CARD_BLOCKREASON = "SRBDC500037";
	
	public static final String MAX_MULTI_TXN ="MEMI202";
	public static final String MAX_MULTI_AMT = "MTEA202";
	public static final String CARD_MULTI_TXN = "MTEC202";
	public static final String TENURE_MULTI_TXN = "MTET202";
	//mutual funds
	public static final String SIPINVEST_SERVICE_UNAVAILABE = "MFRVMP999711";
	

}
