package com.custom.ebanking.users.api.retail.v2.resources;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

//import com.infosys.ebanking.types.valueobjects.SBAcctAddVO;
import com.custom.ebanking.users.api.retail.v2.pojo.CustomAddUserInputVO;
import com.custom.ebanking.users.api.retail.v2.pojo.CustomUserContactListDetailsVOV2;
import com.custom.ebanking.users.api.retail.v2.pojo.CustomUserContactsListDetailsResponseVOV2;
import com.icici.ebanking.common.validators.CustomIDDEmailIdVal;
import com.infosys.ebanking.rest.common.v1.ResourceAuthenticator;
import com.infosys.ebanking.rest.common.v2.ResourcePathsV2;
import com.infosys.ebanking.types.CustomTypesCatalogueConstants;
import com.infosys.ebanking.types.valueobjects.CustomUserSearchDetailsVO;
import com.infosys.ebanking.types.valueobjects.CustomUserSearchEnquiryVO;
import com.infosys.feba.framework.common.MethodInfo;
import com.infosys.feba.framework.common.ServiceInfo;
import com.infosys.feba.framework.common.exception.BusinessException;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.commonweb.context.IOpContext;
import com.infosys.feba.framework.interceptor.rest.pojo.Header;
import com.infosys.feba.framework.interceptor.rest.pojo.RestCommonSuccessMessageHandler;
import com.infosys.feba.framework.interceptor.rest.pojo.RestResponseErrorCodeMapping;
import com.infosys.feba.framework.interceptor.rest.service.RestResourceManager;
import com.infosys.feba.framework.service.ServiceUtil;
import com.infosys.feba.framework.service.stub.client.IClientStub;
import com.infosys.feba.framework.transaction.common.TransactionConstants;
import com.infosys.feba.framework.transaction.util.TransactionContextFactory;
import com.infosys.feba.framework.types.primitives.FEBAUnboundString;
import com.infosys.feba.framework.types.valueobjects.FEBAAVOFactory;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;



@Api(value = "User Contact")
@Path("/v2/banks/{bankid}/users/{userid}/usercontacts")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@ServiceInfo(moduleName = "PWAY")
@ApiResponses(value = { @ApiResponse(code = 401, message = ResourcePathsV2.HTTP_ERROR_401, response = Header.class),
		@ApiResponse(code = 404, message = ResourcePathsV2.HTTP_ERROR_404, response = Header.class),
		@ApiResponse(code = 405, message = ResourcePathsV2.HTTP_ERROR_405, response = Header.class),
		@ApiResponse(code = 415, message = ResourcePathsV2.HTTP_ERROR_415, response = Header.class),
		@ApiResponse(code = 500, message = ResourcePathsV2.HTTP_ERROR_500, response = Header.class) })
		
		public class CustomUserContactRetailResourceV2 extends ResourceAuthenticator {

	@Context
	HttpServletRequest request;
	//CustomCounterPartyUtilV2 CounterPartyUtilV2 = new CustomCounterPartyUtilV2();
	@Context
	HttpServletResponse httpResponse;
	
	/**
	 * This method is used to fetch the list of all counterparties based on a
	 * criteria.
	 *
	 * @return Response which is having the CustomCounterPartyListDetailsVOV2 as
	 *         entity.
	 */
	@GET
	@ApiOperation(value = "Fetch list of all user contacts", response = CustomUserContactsListDetailsResponseVOV2.class)
	@MethodInfo(uri = "/v2/banks/{bankid}/users/{userid}/usercontacts", auditFields = { "userId:userId"})
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "List of user contacts are successfully retrieved", response = CustomUserContactsListDetailsResponseVOV2.class),
			@ApiResponse(code = 400, message = ResourcePathsV2.HTTP_ERROR_400, response = Header.class) })
	public Response fetchUserContactListRequest(
			@ApiParam(value = "User ID") @QueryParam("userName") String userName) {

		IOpContext OpContext = (IOpContext) request.getAttribute("OP_CONTEXT");
		//String httpHeader = (String) request.getAttribute(FEBAConstants.CUSTOM_HEADER);

	//	OpContext.setInContextData(CustomTransactionHIFConstants.CHANNEL_CONTEXT, new FEBAUnboundString(httpHeader));

		CustomUserContactsListDetailsResponseVOV2 userContactListDetailsResponseVO = new CustomUserContactsListDetailsResponseVOV2();
		
		ArrayList<CustomUserContactListDetailsVOV2> data = new ArrayList<>();
		try {

			//isUnAuthenticatedRequest();

			CustomUserSearchEnquiryVO usrEnquiryVO = (CustomUserSearchEnquiryVO) FEBAAVOFactory
					.createInstance(CustomTypesCatalogueConstants.CustomUserSearchEnquiryVO);

			if(userName!=null)
			{
				usrEnquiryVO.getCriteria().setUserId(userName);
			}
			
			final IClientStub service = ServiceUtil.getService(new FEBAUnboundString("CustomUserSearchService"));

			service.callService(OpContext, usrEnquiryVO, new FEBAUnboundString("searchUsers"));


			for (int i = 0; i < usrEnquiryVO.getResultList().size(); i++) {

				CustomUserSearchDetailsVO usrDetailsVO =  (CustomUserSearchDetailsVO)usrEnquiryVO.getResultList().get(i);
				
				CustomUserContactListDetailsVOV2 usrContactListVO= new CustomUserContactListDetailsVOV2();
			
				usrContactListVO.setUserName(usrDetailsVO.getUserId().toString());
				usrContactListVO.setMobNum(usrDetailsVO.getMobileNumber().toString());
				usrContactListVO.setEmailId(usrDetailsVO.getEmailId().toString());
				data.add(usrContactListVO);
			}
			
			userContactListDetailsResponseVO.setUserList(data);
			
			
			RestResourceManager.updateHeaderFooterResponseData(userContactListDetailsResponseVO, request, httpResponse,
					0);
			userContactListDetailsResponseVO.setHeader(null);
			userContactListDetailsResponseVO.setFooter(null);
		

		} catch (Exception e) {
			e.printStackTrace();

			RestResourceManager.handleFatalErrorOutput(request, httpResponse, e, restResponseErrorCodeMapping());

		}

		return Response.ok().entity(userContactListDetailsResponseVO).build();
	}

	@MethodInfo(uri = "/v2/banks/{bankid}/users/{userid}/usercontacts", auditFields = {"userId:User ID","mobNum:Mobile Number","emailId:Email ID"})
	@POST
	@ApiOperation(value = "To add a user", response = CustomUserContactListDetailsVOV2.class)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Successfully created the user", response = CustomUserContactListDetailsVOV2.class)
						})
	public Response createUser(CustomAddUserInputVO inputDetails) {
		
		CustomUserContactListDetailsVOV2 outputVO = new CustomUserContactListDetailsVOV2();
			
		IOpContext opContext = (IOpContext) request.getAttribute("OP_CONTEXT");
		FEBATransactionContext context = TransactionContextFactory.getInstance(TransactionConstants.EB_TXN_CONTEXT);
		int responseStatus = 201;
		RestCommonSuccessMessageHandler wrapper = new RestCommonSuccessMessageHandler();
		
		CustomUserSearchDetailsVO ucVO = (CustomUserSearchDetailsVO) FEBAAVOFactory
				.createInstance(CustomTypesCatalogueConstants.CustomUserSearchDetailsVO);
		try {
			
			
			ucVO=mapInputVOtoImplVO(opContext,inputDetails);
			CustomIDDEmailIdVal validateEmailId = new CustomIDDEmailIdVal();
			
			validateEmailId.validate(context, ucVO.getEmailId());
			final IClientStub service = ServiceUtil.getService(new FEBAUnboundString("CustomUserSearchService"));
			
			service.callService(opContext, ucVO, new FEBAUnboundString("addUser"));
			
			
			//if service call is success moves to next line  else moves to catch
			outputVO.setResponse("SUCCESS");
			}
		catch(BusinessException businessException){
       		RestResourceManager.handleFatalErrorOutput(request, response,businessException, restResponseErrorCodeMapping());	
        }
		catch(Throwable ex){
			RestResourceManager.handleFatalErrorOutput(request, response, ex, restResponseErrorCodeMapping());
		}
		
		//if (responseStatus == 401) {
		//	return Response.status(responseStatus).entity(outputVO).build();
	//	} else {
			//to set header
			RestResourceManager.updateHeaderFooterResponseData(wrapper, request, response, 1);
			
			// output vo is set to json and send as response - framework files are used
			return Response.status(responseStatus).entity(outputVO).build();
		//}
	}

	public static CustomUserSearchDetailsVO mapInputVOtoImplVO(IOpContext pObjContext,CustomAddUserInputVO inputDetails) throws BusinessException{
		CustomUserSearchDetailsVO userVO = (CustomUserSearchDetailsVO) FEBAAVOFactory
					.createInstance(CustomTypesCatalogueConstants.CustomUserSearchDetailsVO);
		userVO.setUserId(inputDetails.getUserName());
		userVO.setMobileNumber(inputDetails.getMobNum());
		userVO.setEmailId(inputDetails.getEmailId());
		
		return userVO;
	}
	

	
	protected List<RestResponseErrorCodeMapping> restResponseErrorCodeMapping() {
		List<RestResponseErrorCodeMapping> restResponceErrorCode = new ArrayList<RestResponseErrorCodeMapping>();
		return restResponceErrorCode;
		}



}
