/**
 * UCDTInfoKey.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */    
package com.infosys.ebanking.tao.infokey;

import com.infosys.feba.framework.types.FEBATypeSystemException;
import com.infosys.feba.framework.types.IFEBAType;
import com.infosys.feba.framework.types.FEBAStringBuilder;
import com.infosys.feba.framework.types.primitives.FEBAAChar;
import com.infosys.feba.framework.types.primitives.FEBAAString;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.feba.framework.tao.FEBAAInfoKey;
import com.infosys.feba.utils.FEBAStringUtility;
import com.infosys.feba.framework.common.ErrorCodes;
import java.sql.Timestamp;


import com.infosys.feba.framework.types.primitives.FEBAUnboundString;


/**
 * This class is an implementation of FEBAAInfoKey.
 * 
 * 
 * @author TAOGenerator
 * @version 1.0, Mon Mar 18 16:46:47 IST 2019
 * @see com.infosys.feba.framework.tao.FEBAAInfoKey
 * @since FEBA 2.0
 */
public class UCDTInfoKey extends FEBAAInfoKey<UCDTInfoKey> {
  private FEBAUnboundString userId;
     
    /**
     * Empty constructor. 
     */   
    public UCDTInfoKey() throws FEBATypeSystemException {
        initialize();
    }
    
    /**
     * Intializes the value object with default values specified for the members. 
     */
    public final void initialize() throws FEBATypeSystemException {
	userId =  null; 

    }

    /**
     * This method copies the values of the memeber variables of the parameter UCDTInfoKey 
     * object 'param' to the corresponding member variables of this object.
     * 
     * @param param an object of class 'UCDTInfoKey'
     * @return the result of the validation as a boolean value.
     * @throws FEBATypeSystemException     
     */    
   public final void set(UCDTInfoKey param) throws FEBATypeSystemException {
        if (param == null){
            throw new FEBATypeSystemException("Invalid value object has been passed, object is null",ErrorCodes.INVALID_VALUE_OBJECT);
        } else if (!(param instanceof UCDTInfoKey)) {
            throw new FEBATypeSystemException("Invalid value object has been passed, object is not an instance of UCDTInfoKey",ErrorCodes.INVALID_VALUE_OBJECT);
        } else if (this == param) {
			return;
		}
		  
setUserId(param.getUserId());
	
    }
    
    /**
     * This method returns the String representation of the key for this value object.
     * The String is of the following format
     * [^keyField1=value^keyField2=value ...] 
     *
     * @return a String representation of the key for this value object
     */
     public final String getAuditInfo() {
			 FEBAStringBuilder stringBuf = new FEBAStringBuilder(14);

	 stringBuf.append("^");
	 stringBuf.append(userId.toString().trim()).append("^");


	 return stringBuf.toString();
     }  
   
    
    /**
     * This method validates the member variable values of 'this' object,
     * against their own type constraints.
     * 
     * @return the result of the validation as a boolean value.
     */
    public final boolean isValid() {    

	if (userId == null || !userId.isValid()){
	   return false;
	}       
        return true;
    }    
    
    /**
     * This method performs the following operations on the parameter UCDTInfoKey 
     * object 'param'
     * 1.Checks if the object is same as 'this' object if it is returs true,else continues.
     * 2.Checks if the values of the param object's member variables  are equal to  
     * the values of the member variables of this object, if it is return true, else returns false.
     * 
     * @param param an object of class 'UCDTInfoKey'
     * @return the result of the validation as a boolean value.
     */
    public final boolean equals(UCDTInfoKey param)  {
        if (this == param) {
            return true;
        } else if (!(param instanceof UCDTInfoKey)) {
            return false;
        }      

	if (!userId.equals(param.getUserId())) {
	   return false;
	}
	
        return true;
    } 
    
    /**
     * This method returns the String representation of this value object.
     * The String is of the following format
     * InfoKey={
     *      field1:value;
     *      field2:value;
     * } 
     * No indentation is specified.
     *
     * @return a String representation of this value object.
     */
    public final String toString() {
        return toString("UCDTInfoKey", "");
    }
    
    /**
     * This method returns the String representation of this value object.
     * The String is of the following format
     * InfoKey={
     *      field1:value;
     *      field2:value;
     * } 
     * The indentation for the fields is as many tabs as specifed by the
     * String param 'indentation'.
     *
     * @return a String representation of this value object.
     */
    public final String toString(String fieldName, String indentation) {
	 FEBAStringBuilder stringBuf = new FEBAStringBuilder(21);
	 FEBAStringBuilder newIndentation = new FEBAStringBuilder("\n");

	 newIndentation.append(indentation).append("\t");
	 stringBuf.append(indentation).append(fieldName).append("={");
	 stringBuf.append(newIndentation).append("userId:").append(this.userId);
	 stringBuf.append("\n").append(indentation).append("}");

	 return stringBuf.toString();
    }   
    
    /**
     * This method returns the String representation of this value object for logging.
     * The String is of the following format
     * InfoKey={
     *      field1:value;
     *      field2:value;
     * } 
     * No indentation is specified.
     * @return a String representation of this value object for logging.
     */
    public final String toDebugString() {
        return toDebugString("UCDTInfoKey", "");
    }
    
    /**
     * This method returns the String representation of this value object for logging.
     * The String is of the following format
     * InfoKey={
     *      field1:value;
     *      field2:value;
     * } 
     * The indentation for the fields is as many tabs as specifed by the
     * String param 'indentation'.
     * @return a String representation of this value object for logging.
     */
    public final String toDebugString(String fieldName, String indentation) {
	 FEBAStringBuilder stringBuf = new FEBAStringBuilder(21);
	 FEBAStringBuilder newIndentation = new FEBAStringBuilder("\n");

	 newIndentation.append(indentation).append("\t");
	 stringBuf.append(indentation).append(fieldName).append("={");
	 stringBuf.append(newIndentation).append("userId:");if (userId!= null)stringBuf.append(this.userId.toDebugString());
		 stringBuf.append("\n").append(indentation).append("}");

	 return stringBuf.toString();
    }

    /**
     * This method returns the String representation of the key for this value object.
     * The String is of the following format
     * [^keyField1:value^keyField2:value ...] 
     *
     * @return a String representation of the key for this value object
     */
    public final String getKeyString() {
	 FEBAStringBuilder stringBuf = new FEBAStringBuilder(14);

	 stringBuf.append("^");
	 stringBuf.append(userId.toString().trim()).append("^");


	 return stringBuf.toString();
    }  
    
    /**
     * This method creates a clone of 'this' value object 
     * and returns it.
     * 
     * @return a UCDTInfoKey representing a copy of 'this' value object.
     * @throws FEBATypeSystemException
     */
    public final UCDTInfoKey clone() throws FEBATypeSystemException {
        UCDTInfoKey valueObject =  new UCDTInfoKey();

        valueObject.set(this);

        return valueObject;
    }

    /**
     * This method creates a clone of 'this' value object 
     * and returns it.
     * 
     * @return a UCDTInfoKey representing a copy of 'this' value object.
     * @throws FEBATypeSystemException
     */
    public final UCDTInfoKey getClone() throws FEBATypeSystemException {
        return clone();
    }
    
    public final String getFieldName(IFEBAType febaType){
	 if(userId == febaType) {
		return "userId";
	 }	 return null;
   
   	}
   
    public final IFEBAType getFieldByName(String voFieldNameParam){
return getFieldByHashcode(FEBAStringUtility.generateHashCode(voFieldNameParam));   
   	}

    public final IFEBAType getFieldByHashcode(int voFieldNameParam){
	 switch (voFieldNameParam) {

		case -836030906: 
			return getUserId();
		default : 
		 throw new FEBATypeSystemException("No Field found for the hashcode provided"+voFieldNameParam, ErrorCodes.NO_FIELD_PROVIDED);
	 }   
   	}
    public final void setFieldByName(String voFieldNameParam, IFEBAType param){
setFieldByHashcode(FEBAStringUtility.generateHashCode(voFieldNameParam),param);   
   	}
    
    public final void setFieldByHashcode(int voFieldNameParam, IFEBAType param){
	 switch (voFieldNameParam) {

		case -836030906: 
			 setUserId((FEBAUnboundString)param);
		 break;
	default : 
		 throw new FEBATypeSystemException("No Field found for the name provided"+voFieldNameParam, ErrorCodes.NO_FIELD_PROVIDED);
	}   
   	}  
    


    /**
     * This method copies value of FEBAUnboundString param object
     * object passed to it to the member variable 'userId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public final void setUserId(FEBAUnboundString param) throws FEBATypeSystemException {
        if(param == null){
            this.userId = null;
        }
        else if(userId == null)
        {
	    if( FEBAAString.class.isAssignableFrom(param.getClass()))
	    {
		FEBAUnboundString FEBAUnboundStringClone = (FEBAUnboundString) param.clone();  
		String FEBAUnboundStringValue = String.valueOf(FEBAUnboundStringClone.getValue()).toUpperCase();
		this.userId =  new FEBAUnboundString(FEBAUnboundStringValue);                           
	    }else if( FEBAAChar.class.isAssignableFrom(param.getClass()))
	    {
		FEBAUnboundString FEBAUnboundStringClone = (FEBAUnboundString) param.clone();  
		String FEBAUnboundStringValue = String.valueOf(FEBAUnboundStringClone.getValue()).toUpperCase();
		this.userId =  new FEBAUnboundString(FEBAUnboundStringValue);                           
	    }
	    else
	    {
		this.userId = (FEBAUnboundString) param.clone();                           
	    }
        }
        else
        {
	    if( FEBAAString.class.isAssignableFrom(param.getClass()))
	    {
		String FEBAUnboundStringValue = String.valueOf(param.getValue()).toUpperCase();        
	        this.userId.set(new FEBAUnboundString(FEBAUnboundStringValue));
	    }else if( FEBAAChar.class.isAssignableFrom(param.getClass()))
	    {
		String FEBAUnboundStringValue = String.valueOf(param.getValue()).toUpperCase();        
	        this.userId.set(new FEBAUnboundString(FEBAUnboundStringValue));
	    }
	    else
	    {
		    this.userId.set(param);
	    }
        }
    }        

    /**
     * This method copies value of String param object
     * object passed to it to the member variable 'userId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public final void setUserId(String param) throws FEBATypeSystemException {
        if(param == null){
            this.userId = null;
        } else if(userId == null){
            this.userId = new FEBAUnboundString(param);                             
        } else{
            this.userId.set(param);
        }
    }             

 
    /**
     * This method gets value of the member variable 'userId'
     * of this object.   
     */
    public final FEBAUnboundString getUserId () {
        return this.userId;
    }
    
    
}
