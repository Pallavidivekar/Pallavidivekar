/**
 * UCDTTAO.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2008 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */    
package com.infosys.ebanking.tao;

import com.infosys.feba.framework.common.exception.FatalException;
import com.infosys.feba.framework.common.ErrorCodes;
import com.infosys.feba.framework.common.ErrorConstants;
import com.infosys.feba.framework.tao.FEBAATAO;
import com.infosys.feba.framework.tao.FEBAAInfo;
import com.infosys.feba.framework.tao.FEBAAInfoKey;
import com.infosys.feba.framework.tao.FEBATableOperator;
import com.infosys.feba.framework.tao.FEBATableOperatorException;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.types.FEBATypesConstants;
import com.infosys.feba.framework.types.IFEBAType;
import com.infosys.feba.framework.types.primitives.FEBATableName;
import com.infosys.feba.utils.FEBAStringUtility;
import com.infosys.feba.utils.insulate.HashMap;
import com.infosys.feba.framework.types.FEBAStringBuilder;
import com.infosys.ebanking.tao.dao.UCDTDAO;
import com.infosys.ebanking.tao.info.UCDTInfo;
import com.infosys.ebanking.tao.infokey.UCDTInfoKey;
import com.infosys.feba.framework.types.primitives.FEBAUnboundString;


/**
 * This class is an implementation of FEBAATAO.
 * 
 * 
 * @author TAOGenerator
 * @version 1.0, Mon Mar 18 16:46:46 IST 2019
 * @see com.infosys.feba.framework.tao.FEBAATAO
 * @since FEBA 2.0
 */
public class UCDTTAO extends FEBAATAO {
  private FEBAUnboundString userIdAssociation;
  private FEBAUnboundString mobNumAssociation;
  private FEBAUnboundString emailIdAssociation;
     
    /**
     * Empty constructor. 
     * This constructor is deprecated. Please start using the constructor which takes transaction context
     * as parameter
     * @deprecated 
     */   
    public UCDTTAO() throws FatalException {
        super(new FEBATableName("UCDT"), UCDTDAO.getInstance());
    }
    
    /**
     * Intializes the value object with default values specified for the members.
     * Please start using the initialize method which takes transaction context
     * as parameter 
     * @deprecated  
     */
    public final void initialize() {
        febaCookieAssociation = null;
	userIdAssociation =  null; 
	mobNumAssociation =  null; 
	emailIdAssociation =  null; 

    }

    /**
     * Constructor.
     * @param FEBATransactionContext transaction context 
     */   
    public UCDTTAO(FEBATransactionContext tc) throws FatalException {
        super(new FEBATableName("UCDT"), UCDTDAO.getInstance());
        initialize(tc);
    }
    
    /**
     * Intializes the value object with default values specified for the members and values 
     * read from the transaction context.
     * @param FEBATransactionContext transaction context      
     */
    public final void initialize(FEBATransactionContext tc) {
        febaCookieAssociation = null;
	userIdAssociation =  null; 
	mobNumAssociation =  null; 
	emailIdAssociation =  null; 

    }
    
    public static final UCDTInfo select(FEBATransactionContext tc,FEBAUnboundString userId) throws FEBATableOperatorException {
        UCDTTAO tao = new UCDTTAO(tc);
        FEBATableName tblName = new FEBATableName("UCDT");
        

	tao.associateUserId(userId);
        
        FEBATableOperator.openInquiry(tc, tblName, UCDTDAO.getInstance());

        FEBAAInfoKey infoKey = tao.createInfoKey();

        FEBAAInfo info = FEBATableOperator.select(tc, infoKey, tblName);
        
        return (UCDTInfo)info;
    }
   
            
      
    
    /**
     * This method validates the member variable values of 'this' object,
     * against their own type constraints.
     * 
     * @return the result of the validation as a boolean value.
     */
    public final boolean isValid() {    

	if (userIdAssociation == null || !userIdAssociation.isValid()){
	   return false;
	}
	if (mobNumAssociation != null && !mobNumAssociation.isValid()){
	   return false;
	}
	if (emailIdAssociation != null && !emailIdAssociation.isValid()){
	   return false;
	}       
        return true;
    }
    
    /**
     * This method returns the String representation of this value object.
     * The String is of the following format
     * TAO={
     *      field1:value;
     *      field2:value;
     * } 
     * No indentation is specified.
     *
     * @return a String representation of this value object.
     */
    public final String toString() {
        return toString("UCDTTAO", "");
    }

    /**
     * This method returns the String representation of this value object for logging.
     * The String is of the following format
     * TAO={
     *      field1:value;
     *      field2:value;
     * } 
     * No indentation is specified.
     *
     * @return a String representation of this value object for logging.
     */
    public final String toDebugString() {
        return toDebugString("UCDTTAO", "");
    }
	
    /**
     * This method returns the String representation of this value object.
     * The String is of the following format
     * TAO={
     *      field1:value;
     *      field2:value;
     * } 
     * The indentation for the fields is as many tabs as specifed by the
     * String param 'indentation'.
     *
     * @return a String representation of this value object.
     */
    public final String toString(String fieldName, String indentation) {
	 FEBAStringBuilder stringBuf = new FEBAStringBuilder(121);
	 FEBAStringBuilder newIndentation = new FEBAStringBuilder("\n");

	 newIndentation.append(indentation).append("\t");
	 stringBuf.append(indentation).append(fieldName).append("={");
	 stringBuf.append(newIndentation).append("userIdAssociation:").append(this.userIdAssociation);
	 stringBuf.append(newIndentation).append("mobNumAssociation:").append(this.mobNumAssociation);
	 stringBuf.append(newIndentation).append("emailIdAssociation:").append(this.emailIdAssociation);
	 stringBuf.append("\n").append(indentation).append("}");

	 return stringBuf.toString();
    }   
    
    /**
     * This method returns the String representation of this value object for logging.
     * The String is of the following format
     * TAO={
     *      field1:value;
     *      field2:value;
     * } 
     * The indentation for the fields is as many tabs as specifed by the
     * String param 'indentation'.
     *
     * @return a String representation of this value object for logging.
     */
    public final String toDebugString(String fieldName, String indentation) {
	 FEBAStringBuilder stringBuf = new FEBAStringBuilder(121);
	 FEBAStringBuilder newIndentation = new FEBAStringBuilder("\n");

	 newIndentation.append(indentation).append("\t");
	 stringBuf.append(indentation).append(fieldName).append("={");
	 stringBuf.append(newIndentation).append("userIdAssociation:");if (userIdAssociation!= null)stringBuf.append(this.userIdAssociation.toDebugString());
		 stringBuf.append(newIndentation).append("mobNumAssociation:");if (mobNumAssociation!= null)stringBuf.append(this.mobNumAssociation.toDebugString());
		 stringBuf.append(newIndentation).append("emailIdAssociation:");if (emailIdAssociation!= null)stringBuf.append(this.emailIdAssociation.toDebugString());
		 stringBuf.append("\n").append(indentation).append("}");

	 return stringBuf.toString();
    }   

    /**
     * This method returns the String representation of the key for this value object.
     * The String is of the following format
     * [^keyField1:value^keyField2:value ...] 
     *
     * @return a String representation of the key for this value object
     */
    public final String getKeyString() {     
	 FEBAStringBuilder stringBuf = new FEBAStringBuilder(38);

	 stringBuf.append("[^");
	 stringBuf.append("userIdAssociation:").append(userIdAssociation).append("^");

	 stringBuf.append("]");

	 return stringBuf.toString();
    }      
   
    protected FEBAAInfo createInfo() {
        UCDTInfo info = new UCDTInfo();
        
        
	if (userIdAssociation!= null ) {
		info.setUserId(userIdAssociation);
	}
	if (mobNumAssociation!= null ) {
		info.setMobNum(mobNumAssociation);
	}
	if (emailIdAssociation!= null ) {
		info.setEmailId(emailIdAssociation);
	}

        return info;
    }

    protected void updateInfo(FEBAAInfo param) throws FEBATableOperatorException {
        UCDTInfo info = (UCDTInfo)param;
    
        
	if (userIdAssociation!= null ) {
		info.setUserId(userIdAssociation);
	}
	if (mobNumAssociation!= null ) {
		info.setMobNum(mobNumAssociation);
	}
	if (emailIdAssociation!= null ) {
		info.setEmailId(emailIdAssociation);
	}
    }

    protected FEBAAInfoKey createInfoKey() {
        UCDTInfoKey key = new UCDTInfoKey();    
        
	if (userIdAssociation!= null) {
		key.setUserId(userIdAssociation);
	}
	return key;   
    }

    protected void populateVO(FEBAAInfo param) {
        UCDTInfo info = (UCDTInfo)param;       
      
        
	if (userIdAssociation!= null && info.getUserId() != null) {
		userIdAssociation.set(info.getUserId());
	}
	if (mobNumAssociation!= null && info.getMobNum() != null) {
		mobNumAssociation.set(info.getMobNum());
	}
	if (emailIdAssociation!= null && info.getEmailId() != null) {
		emailIdAssociation.set(info.getEmailId());
	}    
    }
    /**
     * This method gets the table name.
     * 
     */ 
    protected String getTableName() {     
     return "USER_CONTACT_DETAILS_TABLE";
    }
    
    
     /**
     * This method stores febatypes correspond to each column in a hashmap.
     * 
     * 
     */ 
    public HashMap getFebaTypes(){
    	 HashMap febatypesMap=new HashMap();
    	 febatypesMap.put("DB_TS","FEBADatabaseTimeStamp");
    	 febatypesMap.put("R_CRE_ID","FEBARecordUserId");
    	 febatypesMap.put("R_CRE_TIME","FEBADate");
    	 febatypesMap.put("R_MOD_ID","FEBARecordUserId");
    	 febatypesMap.put("R_MOD_TIME","FEBADate");
    	 febatypesMap.put("USER_ID","FEBAUnboundString");            
         febatypesMap.put("MOB_NUM","FEBAUnboundString");            
         febatypesMap.put("EMAIL_ID","FEBAUnboundString");            
         

    	return febatypesMap;
    }
    
    public final void associateByFieldName(String voFieldNameParam, IFEBAType param) throws FEBATableOperatorException {
			 switch (FEBAStringUtility.generateHashCode(voFieldNameParam)) {

		case -836030906: 
		 associateUserId((FEBAUnboundString)param);
		 break;
		case -1068880794: 
		 associateMobNum((FEBAUnboundString)param);
		 break;
		case -1638015529: 
		 associateEmailId((FEBAUnboundString)param);
		 break;
	default : 
		 throw new FEBATableOperatorException("No Field found for the name provided"+voFieldNameParam, ErrorCodes.NO_FIELD_PROVIDED);
	}
    }
    

    /**
     * This method associates FEBAUnboundString param object
     * object passed to it to the member variable 'userIdAssociation' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     */
    public final void associateUserId(FEBAUnboundString param) {      
        this.userIdAssociation = param;
    }


    /**
     * This method associates FEBAUnboundString param object
     * object passed to it to the member variable 'mobNumAssociation' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     */
    public final void associateMobNum(FEBAUnboundString param) {      
        this.mobNumAssociation = param;
    }


    /**
     * This method associates FEBAUnboundString param object
     * object passed to it to the member variable 'emailIdAssociation' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     */
    public final void associateEmailId(FEBAUnboundString param) {      
        this.emailIdAssociation = param;
    }
    
}
