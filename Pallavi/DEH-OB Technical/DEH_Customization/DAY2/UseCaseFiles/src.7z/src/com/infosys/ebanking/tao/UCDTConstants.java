/**
 * UCDTConstants.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */    
package com.infosys.ebanking.tao;


/**
 * This class is a constants file representing all table column names.
 * 
 * @author TAOGenerator
 * @version 1.0, Mon Mar 18 16:46:47 IST 2019
 * @see com.infosys.feba.framework.tao.FEBAAInfo
 * @since FEBA 2.0
 */
public class UCDTConstants {public static final String USER_ID = "USER_ID";public static final String MOB_NUM = "MOB_NUM";public static final String EMAIL_ID = "EMAIL_ID";
 }
