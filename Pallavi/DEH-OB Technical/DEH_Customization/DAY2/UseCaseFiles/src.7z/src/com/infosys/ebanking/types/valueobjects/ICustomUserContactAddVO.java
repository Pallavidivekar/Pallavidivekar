/**
 * ICustomUserContactAddVO.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */    
package com.infosys.ebanking.types.valueobjects;

import com.infosys.feba.framework.types.FEBATypeSystemException;
import com.infosys.feba.framework.types.IFEBAType;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.feba.framework.types.primitives.FEBAUnboundString;

import com.infosys.feba.framework.types.VOFieldPrimitiveMetaInfo;
/**
 * This class is an implementation of IFEBAValueObject.
 * 
 * 
 * @author VOGenerator
 * @version 1.0, Fri Feb 01 17:08:48 IST 2019
 * @see com.infosys.feba.framework.types.valueobjects.IFEBAValueObject
 * @since FEBA 2.0
 */
  
public interface ICustomUserContactAddVO<T extends ICustomUserContactAddVO<T>> extends IFEBAValueObject<T> {     
    /**
     * This method copies value of FEBAUnboundString param object
     * object passed to it to the member variable 'emailId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public void setEmailId(FEBAUnboundString param) throws FEBATypeSystemException ;

    /**
     * This method gets value of the member variable 'emailId'
     * of this object.   
     */
    public FEBAUnboundString getEmailId () ;    

    

    /**
     * This method copies value of String param object
     * object passed to it to the member variable 'emailId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public void setEmailId(String param) throws FEBATypeSystemException ;
     
    /**
     * This method copies value of FEBAUnboundString param object
     * object passed to it to the member variable 'mobNum' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public void setMobNum(FEBAUnboundString param) throws FEBATypeSystemException ;

    /**
     * This method gets value of the member variable 'mobNum'
     * of this object.   
     */
    public FEBAUnboundString getMobNum () ;    

    

    /**
     * This method copies value of String param object
     * object passed to it to the member variable 'mobNum' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public void setMobNum(String param) throws FEBATypeSystemException ;
     
    /**
     * This method copies value of FEBAUnboundString param object
     * object passed to it to the member variable 'userId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public void setUserId(FEBAUnboundString param) throws FEBATypeSystemException ;

    /**
     * This method gets value of the member variable 'userId'
     * of this object.   
     */
    public FEBAUnboundString getUserId () ;    

    

    /**
     * This method copies value of String param object
     * object passed to it to the member variable 'userId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public void setUserId(String param) throws FEBATypeSystemException ;
  
  	/**
     * This method copies value of IFEBAValueObject param object
     * passed to it to the member variable 'extensionVO' of this object.
     * 
     * @param param an object of IFEBAValueObject class.
     * @throws FEBATypeSystemException     
     */
    public void setExtensionVO(IFEBAValueObject param) throws FEBATypeSystemException ;
     
     /**
     * This method gets value of the member variable 'extensionVO'
     * of this object.   
     */
    public IFEBAValueObject getExtensionVO () ;   
      
  	/**
     * This method copies value of IFEBAValueObject param object
     * passed to it to the member variable 'componentVO' of this object.
     * 
     * @param param an object of IFEBAValueObject class.
     * @throws FEBATypeSystemException     
     */
    public void setComponentVO(IFEBAValueObject param) throws FEBATypeSystemException ;
     
     /**
     * This method gets value of the member variable 'componentVO'
     * of this object.   
     */
    public IFEBAValueObject getComponentVO () ;   
    
    
}
