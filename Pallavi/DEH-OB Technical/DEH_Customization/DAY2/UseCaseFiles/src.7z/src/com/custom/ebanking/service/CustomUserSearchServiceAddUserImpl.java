package com.custom.ebanking.service;

import com.infosys.ebanking.common.EBTransactionContext;
import com.infosys.ebanking.common.EBankingErrorCodes;
import com.infosys.ebanking.tao.UCDTTAO;
//import com.infosys.ebanking.types.valueobjects.AddUserContactVO;
import com.infosys.ebanking.types.valueobjects.CustomUserSearchDetailsVO;
import com.infosys.feba.framework.common.exception.BusinessConfirmation;
import com.infosys.feba.framework.common.exception.BusinessException;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.tao.FEBATableOperatorException;
import com.infosys.feba.framework.transaction.pattern.AbstractLocalUpdateTran;
import com.infosys.feba.framework.types.primitives.FEBAUnboundInt;
import com.infosys.feba.framework.types.primitives.FEBAUnboundString;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.feba.framework.valengine.FEBAValItem;

/**
* The invoke method of this transaction pattern calls ten template methods.
* 1. getTransactionWM() - fetches the Value Object implementing
* IFEBAValueOject representing the working memory for passing data between
* the template methods. 2. validateData() - validates inputs to the
* transaction. 3. validateBusinessRules() - executes business rules. 4.
* raiseFinalConfirmation - raises the confirmation 5. createWorkflowVO() -
* instantiates the workflowVO. 6. populateWorkflowVO() - populates the
* input criteria required for workflow processing. 7.isWorkflowRequired() -
* verifies if the service wants to invoke workflow. 8. establishWFMode() -
* validates and determines the workflow mode applicable for the
* transaction. 9. process() - Updates data in local DB by invoking a DAO.
* 10. processWorkflow() - updates the workflow and transaction history
* tables
*
* @see com.infosys.feba.framework.transaction.pattern.ITransaction#invoke(TransactionContext,
* IFEBAValueObject, HashMap)
*/

public class CustomUserSearchServiceAddUserImpl extends AbstractLocalUpdateTran {
//methods declared in AbstractLocalUpdateTran
	//to add extra validations , inbuilt validations
	public FEBAValItem[] prepareValidationsList(FEBATransactionContext arg0,
			IFEBAValueObject arg1, IFEBAValueObject arg2)
			throws BusinessException, BusinessConfirmation, CriticalException {

		return null;

	}
//checks which txn pattern is extended -> it has an inbuilt flow -> validations , then process , post process
	//ebtransactioncontext / opcontext - cust details during login 
	//VO -default object -objInputOutput
	// objTxnWM?
	//
	public void process(FEBATransactionContext objContext,
			IFEBAValueObject objInputOutput, IFEBAValueObject objTxnWM)
			throws BusinessException, BusinessConfirmation, CriticalException {

		// Type cast the objInputOutput
		CustomUserSearchDetailsVO ucVO = (CustomUserSearchDetailsVO) objInputOutput;
		// Type cast the context object
		EBTransactionContext ebContext = (EBTransactionContext) objContext;
		//TAO /DAL / logic in utility file 
		// if Host call ->there might be-> post process- >to manipulate response from hostdb 
		// TAO -CRUD  operations - create read update delete 
		// DAL - criteria based
		final UCDTTAO UCDTTAO = new UCDTTAO(ebContext);
		UCDTTAO.associateUserId(ucVO.getUserId());
		UCDTTAO.associateMobNum(ucVO.getMobileNumber());
		UCDTTAO.associateEmailId(ucVO.getEmailId());
		try {
			//
			UCDTTAO.insert(ebContext);
		} catch (FEBATableOperatorException e) {
			throw new BusinessException(objContext,
			"RQSTSV0007",
					"Error during insertion into UCDT table",50198, e);

		}
		objContext.addBusinessInfo(new FEBAUnboundInt(
				EBankingErrorCodes.CAFW_INSERT_SUCCESS), new FEBAUnboundString(
				"Insert Successful"), new FEBAUnboundString(
				"Record Inserted Successfully"));
				
	}

}