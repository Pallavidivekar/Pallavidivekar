package com.custom.ebanking.users.api.retail.v2.pojo;



import java.util.List;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author Nidhi
 * This is the VO which holds the input fields for the user details.
 *
 */
@ApiModel(value="User Details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)

public class CustomUserContactListDetailsVOV2 {
	
	@ApiModelProperty(value = "This field holds user id")
	private String userName;

	@ApiModelProperty(value = "This field holds emailId")
	private String emailId;

	@ApiModelProperty(value = "This field holds mob num")
	private String mobNum;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobNum() {
		return mobNum;
	}

	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}
	
	@ApiModelProperty(value="Specifies the response")
	@Size(min=0,max=32)
	private String response;
	

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
}