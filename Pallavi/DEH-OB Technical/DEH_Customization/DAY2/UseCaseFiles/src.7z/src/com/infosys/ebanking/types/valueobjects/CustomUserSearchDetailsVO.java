/**
 * CustomUserSearchDetailsVO.java
 *
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */    
package com.infosys.ebanking.types.valueobjects;

import com.infosys.feba.framework.types.FEBATypeSystemException;
import com.infosys.feba.framework.types.IFEBAType;
import com.infosys.feba.framework.types.FEBAStringBuilder;
import com.infosys.feba.framework.types.valueobjects.FEBAAVOFactory;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.feba.utils.FEBAStringUtility;
import com.infosys.feba.framework.common.ErrorCodes;
import com.infosys.feba.framework.types.valueobjects.FEBAVOUtility;
import com.infosys.feba.framework.common.ExtensionMetaInfo;
import com.infosys.feba.framework.common.ComponentMetaInfo;

import com.infosys.ebanking.types.TypesCatalogueConstants;
	
import com.infosys.feba.framework.types.FEBAVODefinition;
import com.infosys.feba.framework.types.FEBAVODefinitionUtility;
import com.infosys.feba.framework.types.FEBAVODefinitionUtility.VODefinitionBuilder;

import com.infosys.feba.framework.types.primitives.FEBAUnboundString;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;

import com.infosys.feba.framework.types.VOFieldPrimitiveMetaInfo;

/**
 * This class is an implementation of IFEBAValueObject.
 * 
 * 
 * @author VOGenerator
 * @version 1.0,Wed Jan 02 11:51:51 IST 2019
 * @see com.infosys.feba.framework.types.valueobjects.IFEBAValueObject
 * @since FEBA 2.0
 */

public class CustomUserSearchDetailsVO implements ICustomUserSearchDetailsVO<CustomUserSearchDetailsVO>{

	/** VO Extension meta details * */
    private static ExtensionMetaInfo extensionMetaInfo = FEBAVOUtility
            .getExtensionMetaInfo("CustomUserSearchDetailsVO");
	/** VO Component meta details * */		
			 private static ComponentMetaInfo componentMetaInfo = FEBAVOUtility
            .getComponentMetaInfo("CustomUserSearchDetailsVO");
   /**Serial Version UID*/
   private static final long serialVersionUID = 1L;
   
/** mobile number field in details VO */
  private FEBAUnboundString mobileNumber;
/** email ID in details VO */
  private FEBAUnboundString emailId;
/** user Id field in Details VO */
  private FEBAUnboundString userId;
/**  Extension VO  */
  private IFEBAValueObject extensionVO;
/**  Component VO  */
  private IFEBAValueObject componentVO;
     
   /** VO Definition */
   private transient FEBAVODefinition voDefinition;
     

    /**
     * Empty constructor. 
     */   
    protected CustomUserSearchDetailsVO() throws FEBATypeSystemException {
        initialize();
    }


    /**
     * Intializes the value object with default values specified for the members. 
     */
    public final void initialize() throws FEBATypeSystemException {
	mobileNumber = new FEBAUnboundString();
	emailId = new FEBAUnboundString();
	userId = new FEBAUnboundString();
	if (extensionMetaInfo != null
	&& extensionMetaInfo.getInstantiateFlag().equals(
		ExtensionMetaInfo.INSTANTIATE_YES)) {
	extensionVO = FEBAAVOFactory.createInstance(extensionMetaInfo.getExtensionVOFullName());
	 }	if (componentMetaInfo != null
	&& componentMetaInfo.getInstantiateFlag().equals(
		ComponentMetaInfo.INSTANTIATE_YES)) {
	componentVO = FEBAAVOFactory.createInstance(componentMetaInfo.getComponentVOFullName());
	 }
    }

    /**
     * This method copies the values of the memeber variables of the parameter CustomUserSearchDetailsVO 
     * object 'param' to the corresponding member variables of this object.
     * 
     * @param param an object of class 'CustomUserSearchDetailsVO'
     * @return the result of the validation as a boolean value.
     * @throws FEBATypeSystemException     
     */    
   public final void set(CustomUserSearchDetailsVO param) throws FEBATypeSystemException {
        if (param == null){
            throw new FEBATypeSystemException("Invalid value object has been passed, object is null",ErrorCodes.INVALID_VALUE_OBJECT);
        } else if (!(param instanceof CustomUserSearchDetailsVO)) {
            throw new FEBATypeSystemException("Invalid value object has been passed, object is not an instance of CustomUserSearchDetailsVO",ErrorCodes.INVALID_VALUE_OBJECT);
        } else if ( this == param){
        	return;
        }
setMobileNumber(param.getMobileNumber());
	setEmailId(param.getEmailId());
	setUserId(param.getUserId());
	setExtensionVO(param.getExtensionVO());
	setComponentVO(param.getComponentVO());
	
    }
    
    /**
     * This method performs the following operations on the parameter CustomUserSearchDetailsVO 
     * object 'param'
     * 1.Checks if the object is same as 'this' object if it is returs true,else continues.
     * 2.Checks if the values of the param object's member variables  are equal to  
     * the values of the member variables of this object, if it is return true, else returns false.
     * 
     * @param param an object of class 'CustomUserSearchDetailsVO'
     * @return the result of the validation as a boolean value.
     */
    public final boolean equals(CustomUserSearchDetailsVO param)  {
        if (this == param) {
            return true;
        } else if (!(param instanceof CustomUserSearchDetailsVO)) {
            return false;
        }      

	if (!this.getMobileNumber().equals(param.getMobileNumber())) {
	   return false;
	}
	
	if (!this.getEmailId().equals(param.getEmailId())) {
	   return false;
	}
	
	if (!this.getUserId().equals(param.getUserId())) {
	   return false;
	}
	
	if ( this.getExtensionVO()==null) {
		if (param.getExtensionVO()!=null) {
			return false;
		}
	}else if(!this.getExtensionVO().equals(param.getExtensionVO())) {
		return false;
	}
	
	if ( this.getComponentVO()==null) {
		if (param.getComponentVO()!=null) {
			return false;
		}
	}else if(!this.getComponentVO().equals(param.getComponentVO())) {
		return false;
	}
	
        return true;
    } 
    
    /**
     * This method returns the String representation of this value object.
     * The String is of the following format
     * VO={
     *      field1:value;
     *      field2:value;
     * } 
     * No indentation is specified.
     *
     * @return a String representation of this value object.
     */
    public final String toString() {
        return toString("CustomUserSearchDetailsVO", "");
    }

    /**
	 * This generated method code will return the string representation for logging.
     * Fields will have have proper value if they not set as 'SecureField', else each field will return "NOT AVAILABLE" as output.
     * The String is of the following format
     * VO={
     *      field1:value;
     *      field2:value;
     * } 
     * No indentation is specified.
     *
     * @return a String representation of this value object for logging.
     */
    public final String toDebugString() {
        return toDebugString("CustomUserSearchDetailsVO", "");
    }
    
    /**
     * This method creates a clone of 'this' value object 
     * and returns it.
     * 
     * @return a CustomUserSearchDetailsVO representing a copy of 'this' value object.
     * @throws FEBATypeSystemException
     */
    public final CustomUserSearchDetailsVO clone() throws FEBATypeSystemException {
        CustomUserSearchDetailsVO valueObject =  new CustomUserSearchDetailsVO();

        valueObject.set(this);

        return valueObject;
    }
    
    /**
     * This method validates the member variable values of 'this' object,
     * against their own type constraints.
     * 
     * @return the result of the validation as a boolean value.
     */
    public final boolean isValid(){    

	if (mobileNumber != null && !mobileNumber.isValid()){
	   return false;
	}
	if (emailId != null && !emailId.isValid()){
	   return false;
	}
	if (userId != null && !userId.isValid()){
	   return false;
	}
	if (extensionVO != null && !extensionVO.isValid()){
	   return false;
	}
	if (componentVO != null && !componentVO.isValid()){
	   return false;
	}       
        return true;
    }    
    
    /**
     * This method returns the String representation of this value object.
     * The String is of the following format
     * VO={
     *      field1:value;
     *      field2:value;
     * } 
     * The indentation for the fields is as many tabs as specifed by the
     * String param 'indentation'.
     *
     * @return a String representation of this value object.
     */
    public final String toString(String fieldName, String indentation) {
	 FEBAStringBuilder stringBuf = new FEBAStringBuilder(119);
	 String newIndentation = indentation+"\t";

	 stringBuf.append(indentation).append(fieldName).append("={");
	 stringBuf.append("\n").append(newIndentation).append("mobileNumber:").append(this.mobileNumber);
	 stringBuf.append("\n").append(newIndentation).append("emailId:").append(this.emailId);
	 stringBuf.append("\n").append(newIndentation).append("userId:").append(this.userId);
	if(extensionVO !=null){
	 stringBuf.append("\n").append(indentation).append(this.extensionVO.toString("extensionVO", newIndentation));
	}
	if(componentVO !=null){
	 stringBuf.append("\n").append(indentation).append(this.componentVO.toString("componentVO", newIndentation));
	}
	 stringBuf.append("\n").append(indentation).append("}");

	 return stringBuf.toString();
    }   
    
    /**
     * This method returns the String representation of this value object for logging.
     * The String is of the following format
     * VO={
     *      field1:value;
     *      field2:value;
     * } 
     * The indentation for the fields is as many tabs as specifed by the
     * String param 'indentation'.
     *
     * @return a String representation of this value object for logging.
     */
    public final String toDebugString(String fieldName, String indentation) {
	 FEBAStringBuilder stringBuf = new FEBAStringBuilder(119);
	 String newIndentation = indentation+"\t";

	 stringBuf.append(indentation).append(fieldName).append("={");
	if(mobileNumber !=null){
	 stringBuf.append("\n").append(newIndentation).append("mobileNumber:").append(this.mobileNumber.toDebugString());
	}
	if(emailId !=null){
	 stringBuf.append("\n").append(newIndentation).append("emailId:").append(this.emailId.toDebugString());
	}
	if(userId !=null){
	 stringBuf.append("\n").append(newIndentation).append("userId:").append(this.userId.toDebugString());
	}
	if(extensionVO !=null){
	 stringBuf.append("\n").append(indentation).append(this.extensionVO.toDebugString("extensionVO", newIndentation));
	}
	if(componentVO !=null){
	 stringBuf.append("\n").append(indentation).append(this.componentVO.toDebugString("componentVO", newIndentation));
	}
	 stringBuf.append("\n").append(indentation).append("}");

	 return stringBuf.toString();
    }  

    /**
     * This method returns the String representation of the key for this value object.
     * The String is of the following format
     * [^keyField1:value^keyField2:value ...] 
     *
     * @return a String representation of the key for this value object
     */
    public final String getKeyString() {
	 FEBAStringBuilder stringBuf = new FEBAStringBuilder(3);

	 stringBuf.append("[^");

	 stringBuf.append("]");

	 return stringBuf.toString();
    }  
    
    /**
     * This method creates a clone of 'this' value object 
     * and returns it.
     * 
     * @return a CustomUserSearchDetailsVO representing a copy of 'this' value object.
     * @throws FEBATypeSystemException
     */
    public final CustomUserSearchDetailsVO getClone() throws FEBATypeSystemException {
		return clone();
    }

    public final String getFieldName(IFEBAType febaType){
	    if(febaType == null){
	      return null;
	    }
    
    	 if(mobileNumber == febaType) {
		return "mobileNumber";
	 }	 if(emailId == febaType) {
		return "emailId";
	 }	 if(userId == febaType) {
		return "userId";
	 }	 if(extensionVO == febaType) {
		return "extensionVO";
	 }	 if(componentVO == febaType) {
		return "componentVO";
	 }	 return null;
   
   	
   	}

    public final IFEBAType getFieldByName(String voFieldNameParam){
return getFieldByHashcode(FEBAStringUtility.generateHashCode(voFieldNameParam));   
   	}

    public final IFEBAType getFieldByHashcode(int voFieldNameParam){
	 switch (voFieldNameParam) {

		case 1737348747: 
			return getMobileNumber();
		case -1638015529: 
			return getEmailId();
		case -836030906: 
			return getUserId();
		case -257486024: 
			return getExtensionVO();
		case -985932682: 
			return getComponentVO();
		default : 
		 throw new FEBATypeSystemException("No Field found for the hashcode provided"+voFieldNameParam, ErrorCodes.NO_FIELD_PROVIDED);
	 }   
   	}
    public final void setFieldByName(String voFieldNameParam, IFEBAType param){
setFieldByHashcode(FEBAStringUtility.generateHashCode(voFieldNameParam),param);   
   	}
   	    
    public final void setFieldByHashcode(int voFieldNameParam, IFEBAType param){
	 switch (voFieldNameParam) {

		case 1737348747: 
			 setMobileNumber((FEBAUnboundString)param);
		 break;
		case -1638015529: 
			 setEmailId((FEBAUnboundString)param);
		 break;
		case -836030906: 
			 setUserId((FEBAUnboundString)param);
		 break;
		case -257486024: 
			 setExtensionVO((IFEBAValueObject)param);
		 break;
		case -985932682: 
			 setComponentVO((IFEBAValueObject)param);
		 break;
	default : 
		 throw new FEBATypeSystemException("No Field found for the name provided"+voFieldNameParam, ErrorCodes.NO_FIELD_PROVIDED);
	}   
   	}   	    
    


    /**
     * This method copies value of FEBAUnboundString param object
     * object passed to it to the member variable 'mobileNumber' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public final void setMobileNumber(FEBAUnboundString param) throws FEBATypeSystemException {
        if(param == null){
            throw new FEBATypeSystemException("Invalid null value passed to be set.",ErrorCodes.INVALID_NULL_VALUE);
        } else if(mobileNumber == null){
            			this.mobileNumber = (FEBAUnboundString) param.clone();                             
				
        } else {
        this.mobileNumber.set(param);
        }
    }
    
    /**
     * This method copies value of String param object
     * object passed to it to the member variable 'mobileNumber' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public final void setMobileNumber(String param) throws FEBATypeSystemException {
        if(param == null){
            throw new FEBATypeSystemException("Invalid null value passed to be set.",ErrorCodes.INVALID_NULL_VALUE);
        } else if(mobileNumber == null){
            this.mobileNumber = new FEBAUnboundString(param);                             
        } else {        
            this.mobileNumber.set(param);
        }
    }

 
    /**
     * This method gets value of the member variable 'mobileNumber'
     * of this object.   
     */
    public final FEBAUnboundString getMobileNumber () {
    
	if(mobileNumber== null){
		mobileNumber = new FEBAUnboundString();

	}
	return this.mobileNumber;
     }
    


    /**
     * This method copies value of FEBAUnboundString param object
     * object passed to it to the member variable 'emailId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public final void setEmailId(FEBAUnboundString param) throws FEBATypeSystemException {
        if(param == null){
            throw new FEBATypeSystemException("Invalid null value passed to be set.",ErrorCodes.INVALID_NULL_VALUE);
        } else if(emailId == null){
            			this.emailId = (FEBAUnboundString) param.clone();                             
				
        } else {
        this.emailId.set(param);
        }
    }
    
    /**
     * This method copies value of String param object
     * object passed to it to the member variable 'emailId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public final void setEmailId(String param) throws FEBATypeSystemException {
        if(param == null){
            throw new FEBATypeSystemException("Invalid null value passed to be set.",ErrorCodes.INVALID_NULL_VALUE);
        } else if(emailId == null){
            this.emailId = new FEBAUnboundString(param);                             
        } else {        
            this.emailId.set(param);
        }
    }

 
    /**
     * This method gets value of the member variable 'emailId'
     * of this object.   
     */
    public final FEBAUnboundString getEmailId () {
    
	if(emailId== null){
		emailId = new FEBAUnboundString();

	}
	return this.emailId;
     }
    


    /**
     * This method copies value of FEBAUnboundString param object
     * object passed to it to the member variable 'userId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public final void setUserId(FEBAUnboundString param) throws FEBATypeSystemException {
        if(param == null){
            throw new FEBATypeSystemException("Invalid null value passed to be set.",ErrorCodes.INVALID_NULL_VALUE);
        } else if(userId == null){
            			this.userId = (FEBAUnboundString) param.clone();                             
				
        } else {
        this.userId.set(param);
        }
    }
    
    /**
     * This method copies value of String param object
     * object passed to it to the member variable 'userId' of this object.
     * 
     * @param param an object of FEBAUnboundString class.
     * @throws FEBATypeSystemException     
     */
    public final void setUserId(String param) throws FEBATypeSystemException {
        if(param == null){
            throw new FEBATypeSystemException("Invalid null value passed to be set.",ErrorCodes.INVALID_NULL_VALUE);
        } else if(userId == null){
            this.userId = new FEBAUnboundString(param);                             
        } else {        
            this.userId.set(param);
        }
    }

 
    /**
     * This method gets value of the member variable 'userId'
     * of this object.   
     */
    public final FEBAUnboundString getUserId () {
    
	if(userId== null){
		userId = new FEBAUnboundString();

	}
	return this.userId;
     }
        
  	 /**
     * This method copies value of IFEBAValueObject param object
     * passed to it to the member variable 'extensionVO' of this object.
     * 
     * @param param an object of IFEBAValueObject class.
     * @throws FEBATypeSystemException     
     */
    public final void setExtensionVO(IFEBAValueObject param) throws FEBATypeSystemException {
        if(param == null){
            this.extensionVO=null;
        } else if(extensionVO == null){
            FEBAVOUtility.validateInputExtensionVO(extensionMetaInfo,param);
            this.extensionVO = (IFEBAValueObject) param.clone();                             
        } else {
            FEBAVOUtility.validateInputExtensionVO(extensionMetaInfo,param);
            this.extensionVO.set(param);
        }
    }

 	 /**
     * This method gets value of the member variable 'extensionVO'
     * of this object.   
     */
 	
    public final IFEBAValueObject getExtensionVO() {
        return this.extensionVO;
    }

        
  	 /**
     * This method copies value of IFEBAValueObject param object
     * passed to it to the member variable 'componentVO' of this object.
     * 
     * @param param an object of IFEBAValueObject class.
     * @throws FEBATypeSystemException     
     */
    public final void setComponentVO(IFEBAValueObject param) throws FEBATypeSystemException {
        if(param == null){
            this.componentVO=null;
        } else if(componentVO == null){
            FEBAVOUtility.validateInputComponentVO(componentMetaInfo,param);
            this.componentVO = (IFEBAValueObject) param.clone();                             
        } else {
            FEBAVOUtility.validateInputComponentVO(componentMetaInfo,param);
            this.componentVO.set(param);
        }
    }

 	 /**
     * This method gets value of the member variable 'componentVO'
     * of this object.   
     */
 	
    public final IFEBAValueObject getComponentVO() {
        return this.componentVO;
    }

    
     /**
     * This method gets the VO Definition.   
     */
 	
    public FEBAVODefinition getDefinition() {

	if(voDefinition == null){
		FEBAVODefinitionUtility.VODefinitionBuilder builder = new FEBAVODefinitionUtility.VODefinitionBuilder("mobileNumber",new VOFieldPrimitiveMetaInfo("com.infosys.feba.framework.types.primitives.FEBAUnboundString",""));
			builder.putMetaInfo("emailId",new VOFieldPrimitiveMetaInfo("com.infosys.feba.framework.types.primitives.FEBAUnboundString",""));
			builder.putMetaInfo("userId",new VOFieldPrimitiveMetaInfo("com.infosys.feba.framework.types.primitives.FEBAUnboundString",""));
			voDefinition = builder.build();
		}
    	return this.voDefinition;
    }
    
    
}
