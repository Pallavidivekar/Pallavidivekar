package com.infosys.ebanking.service;

import com.infosys.feba.framework.common.exception.*;
import com.infosys.feba.framework.transaction.pattern.AbstractLocalListInquiryTran;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.feba.framework.dal.QueryOperator;
import com.infosys.feba.framework.valengine.FEBAValItem;

import com.infosys.ebanking.types.valueobjects.CustomUserSearchCriteriaVO;
import com.infosys.ebanking.types.valueobjects.CustomUserSearchEnquiryVO;

public class CustomUserSearchServiceSearchUsersImpl extends
		AbstractLocalListInquiryTran {

	public FEBAValItem[] prepareValidationsList(FEBATransactionContext arg0,
			IFEBAValueObject arg1, IFEBAValueObject arg2)
			throws BusinessException, BusinessConfirmation, CriticalException {

		return null;

	}

	public void associateQueryParameters(FEBATransactionContext arg0,
			IFEBAValueObject arg1, IFEBAValueObject arg2, QueryOperator arg3)
			throws CriticalException {

		CustomUserSearchCriteriaVO ucCritVO = (CustomUserSearchCriteriaVO) arg1;
		arg3.associate("userId", ucCritVO.getUserId());

	}

	public String getQueryIdentifier(FEBATransactionContext arg0,
			IFEBAValueObject arg1, IFEBAValueObject arg2) {
		return "CustomUserSearchDAL";
	}

	protected void executeQuery(FEBATransactionContext arg0,
			IFEBAValueObject arg1, IFEBAValueObject arg2)
			throws BusinessException, BusinessConfirmation, CriticalException {

		CustomUserSearchEnquiryVO ucVO = (CustomUserSearchEnquiryVO) arg1;
		super.executeQuery(arg0, ucVO, arg2);
	}
}