package com.infosys.ebanking.service;

import com.infosys.ebanking.common.EBTransactionContext;
import com.infosys.ebanking.common.EBankingErrorCodes;
import com.infosys.ebanking.tao.UCDTTAO;
import com.infosys.ebanking.types.valueobjects.CustomUserContactAddVO;
import com.infosys.feba.framework.common.exception.BusinessConfirmation;
import com.infosys.feba.framework.common.exception.BusinessException;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.tao.FEBATableOperatorException;
import com.infosys.feba.framework.transaction.pattern.AbstractLocalUpdateTran;
import com.infosys.feba.framework.types.primitives.FEBAUnboundInt;
import com.infosys.feba.framework.types.primitives.FEBAUnboundString;
import com.infosys.feba.framework.types.valueobjects.IFEBAValueObject;
import com.infosys.feba.framework.valengine.FEBAValItem;


public class CustomUserContactAddServiceAddUserImpl extends AbstractLocalUpdateTran {

	public FEBAValItem[] prepareValidationsList(FEBATransactionContext arg0,
			IFEBAValueObject arg1, IFEBAValueObject arg2)
			throws BusinessException, BusinessConfirmation, CriticalException {

		return null;

	}

	public void process(FEBATransactionContext objContext,
			IFEBAValueObject objInputOutput, IFEBAValueObject objTxnWM)
			throws BusinessException, BusinessConfirmation, CriticalException {

		// Type cast the objInputOutput
		CustomUserContactAddVO ucVO = (CustomUserContactAddVO) objInputOutput;
		// Type cast the context object
		EBTransactionContext ebContext = (EBTransactionContext) objContext;
		final UCDTTAO UCDTTAO = new UCDTTAO(ebContext);
		UCDTTAO.associateUserId(ucVO.getUserId());
		UCDTTAO.associateMobNum(ucVO.getMobNum());
		UCDTTAO.associateEmailId(ucVO.getEmailId());
		try {
			UCDTTAO.insert(ebContext);
		} catch (FEBATableOperatorException e) {
			throw new BusinessException(objContext,
			"RQSTSV0007",
					"Error during insertion into UCDT table",50198, e);

		}
		objContext.addBusinessInfo(new FEBAUnboundInt(
				EBankingErrorCodes.CAFW_INSERT_SUCCESS), new FEBAUnboundString(
				"Insert Successful"), new FEBAUnboundString(
				"Record Inserted Successfully"));
				
	}

}