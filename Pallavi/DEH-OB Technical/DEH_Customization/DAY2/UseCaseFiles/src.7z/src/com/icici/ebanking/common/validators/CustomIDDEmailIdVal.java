/**
 * CustomSREmailIdVal.java
 * COPYRIGHT NOTICE:
 * Copyright (c) 2007 Infosys Technologies Limited, Electronic City,
 * Hosur Road, Bangalore - 560 100, India.
 * All Rights Reserved.
 * This software is the confidential and proprietary information of
 * Infosys Technologies Ltd. ("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with Infosys.
 */
package com.icici.ebanking.common.validators;

import com.icici.ebanking.common.CustomEBIncidenceCodes;

import com.icici.ebanking.common.CustomEBankingErrorCodes;
import com.infosys.ebanking.common.EBankingErrorCodes;
import com.infosys.ebanking.common.EBankingPatternConstants;
import com.infosys.feba.framework.common.exception.BusinessException;
import com.infosys.feba.framework.common.exception.CriticalException;
import com.infosys.feba.framework.commontran.context.FEBATransactionContext;
import com.infosys.feba.framework.types.IFEBAType;
import com.infosys.feba.framework.valengine.IFEBAStandardValidator;
import com.infosys.feba.utils.FEBAStringUtility;

/**
 * This class is an implementation of IFEBAStandardValidator, to validate the
 * user entered Email ID is valid or not and to check the length of the input
 * 
 * @author Sachin_Malpani
 * @version 1.0
 * @see com.infosys.feba.framework.valengine.IFEBAStandardValidator;
 * @since FEBA 2.0
 */
public class CustomIDDEmailIdVal implements IFEBAStandardValidator {

	public void validate(FEBATransactionContext tc,
			IFEBAType objectToBeValidated) throws BusinessException,
			CriticalException {

		final String emailID = objectToBeValidated.toString();

		if (emailID.length() > 50) {
			throw new BusinessException(
					true,
					tc,
					CustomEBIncidenceCodes.EMAIL_LENGTH_CANNOT_EXCEED_50_CHARACTERS,
					"Length of email Id should not be greater than 50 characters",
					"FormManagementFG.userField38",
					CustomEBankingErrorCodes.EMAILID_LENGTH_EXCEEDED, null);
		}

		if (emailID != null
				&& !FEBAStringUtility.validate(emailID,
						EBankingPatternConstants.IS_EMAIL_ID)) {
			throw new BusinessException(tc,
					CustomEBIncidenceCodes.INVALID_EMAILID, "Invalid Email Id",
					"FormManagementFG.userField38",
					EBankingErrorCodes.INVALID_EMAIL_ID, null);
		}
	}
}
