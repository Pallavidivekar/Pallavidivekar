package com.custom.ebanking.users.api.retail.v2.pojo;



import java.util.List;

import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author Nidhi
 * This is the VO which holds the input fields for the user details.
 *
 */
@ApiModel(value="User Details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)

public class CustomAddUserInputVO {

	
	@ApiModelProperty(value="Specifies the user id")
	@Size(min=0,max=32)
	private String userName;
	
	@ApiModelProperty(value="Specifies the mobile number")
	@Size(min=0,max=32)
	private String mobNum;
	
	@ApiModelProperty(value="Specifies the email ID")
	@Size(min=0,max=32)
	private String emailId;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMobNum() {
		return mobNum;
	}

	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

}

